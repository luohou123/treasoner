/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import Enums.NodeType;
import RuleGraph.RuleGraph;
import RuleGraph.RuleNode;

/**
 *
 * @author 1
 */
public class TwoSidedAxiom
{
    private int left, right;

    public TwoSidedAxiom(int lft, int rgt)
    {
        left = lft;
        right = rgt;
    }

    public int getSub()
    {
        return left;
    }

    public int getSuper()
    {
        return right;
    }
    
    public int ABS(int x)
    {
        if(x < 0) return -x;
        return x;
    }

    public void addSuperConcept(int another_super, RuleGraph rg)
    {
        if(rg.getNode(ABS(right)).getNodeType() != NodeType.ntAND)
        {
            int cur = rg.addNode2RuleTree(new RuleNode(NodeType.ntAND));                                
            rg.getNode(cur).getChildren().add(right);
            rg.getNode(cur).getChildren().add(another_super);
            right = cur;
        } else
        {
            rg.getNode(ABS(right)).addChild(another_super);
        }
    }
}