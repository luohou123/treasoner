/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import Enums.RoleChar;
import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author 1
 */
public class SimpleRole {
    
    private int range = 1; //TOP
    private int domain = 1; //TOP
    private String name;
    private int characteristics = 0; //have no characteristics
    private boolean is_data_role = false;
    private int id = -1;
    
    private HashSet<Integer> super_roles = new HashSet<Integer>();
    private HashSet<Integer> sub_roles = new HashSet<Integer>();
    private HashSet<Integer> eqv_roles = new HashSet<Integer>();
    private HashSet<Integer> dsj_roles = new HashSet<Integer>();
    private HashSet<Integer> inv_roles = new HashSet<Integer>();
    private ArrayList<ArrayList<Integer>> sub_chains = new ArrayList<ArrayList<Integer>>();
    
    //0 bit - Functional
    //1 bit - InverseFunctional
    //2 bit - Transitive
    //3 bit - Symmetric
    //4 bit - Asymmetric
    //5 bit - Reflexive
    //6 bit - Irreflexive
    
    public ArrayList<ArrayList<Integer>> getChains()
    {
        return sub_chains;
    }
    
    public SimpleRole(String S)
    {
        name = S;
    }    
    
    public int getID()
    {
        return id;
    }
    
    public HashSet<Integer> getSubRoles()
    {
        return sub_roles;
    }
    
    public HashSet<Integer> getSuperRoles()
    {
        return super_roles;
    }
    
    public HashSet<Integer> getEqvRoles()
    {
        return eqv_roles;
    }
    
    public HashSet<Integer> getDsjRoles()
    {
        return dsj_roles;
    }
    
    public HashSet<Integer> getInvRoles()
    {
        return inv_roles;
    }
        
    public void setRange(int new_range)
    {
        range = new_range;
    }
    
    public int getRange()
    {
        return range;
    }
    
    public void setDomain(int new_domain)
    {
        domain = new_domain;
    }
    
    public int getDomain()
    {
        return domain;
    }
    
    public void addSubChain(ArrayList<Integer> new_sub_chain)
    {
        sub_chains.add(new_sub_chain);
    }
    
    public void addInverseRoleIndex(int inverse_role_id)
    {
        inv_roles.add(inverse_role_id);
    }
    
    public void setCharacteristic(RoleChar new_characteristic)
    {
        switch (new_characteristic)
        {
            case drFUNC: characteristics |= 1; break;
            case drINVFUNC: characteristics |= (1 << 1); break;
            case drTRANS: characteristics |= (1 << 2); break;
            case drSYMM: characteristics |= (1 << 3); break;
            case drASYMM: characteristics |= (1 << 4); break;
            case drREF: characteristics |= (1 << 5); break;
            case drIRREF: characteristics |= (1 << 6); break;
        }
    }
    
    public boolean isFunctional()
    {
        return (characteristics & 1) > 0;
    }
    
    public boolean isInverseFunctional()
    {
        return (characteristics & (1 << 1)) > 0;
    }
    
    public boolean isTransitive()
    {
        return (characteristics & (1 << 2)) > 0;
    }
    
    public boolean isSymmetric()
    {
        return (characteristics & (1 << 3)) > 0;
    }
    
    public boolean isAsymmetric()
    {
        return (characteristics & (1 << 4)) > 0;
    }
    
    public boolean isReflexive()
    {
        return (characteristics & (1 << 5)) > 0;
    }
    
    public boolean isIrreflexive()
    {
        return (characteristics & (1 << 6)) > 0;
    }
    
    public String getName()
    {
        return name;
    }
    
    public void setName(String S)
    {
        name = S;
    }
    
    public void setDataRole()
    {
        is_data_role = true;
    }
    
    public boolean isDataRole()
    {
        return is_data_role;
    }
    
}
