/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import java.util.Arrays;

/**
 *
 * @author 1
 */
public class IntArray {
    
    private int MaxSize = 16;
    private int[] a = new int[MaxSize];
    private int size = 0;
    
    private void IncreaseSize()
    {
        int[] old = a;
        MaxSize = MaxSize * 3 / 2;
        a = new int[MaxSize];
        
        for(int i = 0; i < size; i++)
            a[i] = old[i];
        
        old = null;
    }
    
    public IntArray()
    {
    }
    
    public void sort()
    {
        Arrays.sort(a, 0, size);
    }
    
    public void reverse()
    {
        for(int i = 0; i < size / 2; i++)
        {
            int h = a[i];
            a[i] = a[size - i - 1];
            a[size - i - 1] = h;
        }
    }
    
    public void delete(int x)
    {
        for(int i = 0; i < size; i++)
        {
            if(a[i] == x)
            {
                for(int j = i; j < size - 1; j++)
                    a[j] = a[j + 1];

                size--; i--;
                //return;
            }
        }
    }
    
    public boolean contain(int x)
    {
        for(int i = 0; i < size; i++)
            if(a[i] == x) return true;
        return false;
    }
            
    public boolean contain(IntArray x)
    {
        int ind1 = 0;
        int ind2 = 0;
        while(ind1 < size && ind2 < x.size())
        {
            if(a[ind1] == x.get(ind2))
            {
                ind1++;
                ind2++;
            } else
            {
                ind1++;
            }
            if(a[ind1] > x.get(ind2) && ind1 < size && ind2 < x.size()) return false;
            
        }
        if(ind2 < x.size()) return false;
        return true;
    }
    
    /*public boolean contain(IntArray x)
    {
        for(int i = 0; i < x.size(); i++)
        {
            boolean fnd = false;
            for(int j = 0; j < size; j++)
            {
                if(a[j] == x.get(i))
                {
                    fnd = true;
                    break;
                }
            }
            if(!fnd) return false;
        }
        return true;
    }*/
    
    public void add(int x)
    {
        if(size == MaxSize - 1) IncreaseSize();
        a[size++] = x;
    }
    
    public void addOnce(int x) //specail for taxonomy builder
    {
        if(contain(x)) return;
        add(x);
    }
    
    public void add(IntArray x)
    {
        for(int i = 0; i < x.size(); i++)
        {
            add(x.get(i));
        }
    }
    
    public void addOnce(IntArray x)
    {
        for(int i = 0; i < x.size(); i++)
        {
            addOnce(x.get(i));
        }
    }
    
    public int get(int x)
    {
        return a[x];
    }
    
    public int size()
    {
        return size;
    }
    
    public void clear()
    {
        size = 0;
    }

    public int pop()
    {
        size--;
        return a[size];
    }
    
}
