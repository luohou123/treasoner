/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

/**
 *
 * @author 1
 */
public class depend
{
    private int MaxSize = 1024;
    public int[] x = new int[MaxSize];
    public int[] y = new int[MaxSize];
    public int size = 0;

    public boolean contain(int xx, int yy)
    {
        for(int i = 0; i < size; i++)
        {
            if(x[i] == xx && y[i] == yy) return true;
        }
        return false;
    }

    private void inc()
    {
        int[] old_x = x;
        int[] old_y = y;

        MaxSize = 3 * (MaxSize / 2);
        x = new int[MaxSize];
        y = new int[MaxSize];

        for(int i = 0; i < size; i++)
        {
            x[i] = old_x[i];
            y[i] = old_y[i];
        }
        old_x = null;
        old_y = null;
    }

    public depend()
    {
    }

    public depend(depend d)
    {
        for(int i = 0; i < d.size; i++)
            add(d.x[i], d.y[i]);
    }

    public void clear()
    {
        size = 0;
    }
    
    public void merge(depend d)
    {
        for(int i = 0; i < d.size; i++)
            add(d.x[i], d.y[i]);
    }

    public void add(int a, int b)
    {
        if(size == MaxSize - 1)
            inc();

        x[size] = a;
        y[size] = b;
        size++;
    }

}