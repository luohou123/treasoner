/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

/**
 *
 * @author 1
 */
public class Statistics {
    
    private int countOfAnd = 0;
    private int countOfIndivids = 0;
    private int countOfOr = 0;
    private int countOfAll = 0;
    private int countOfSome = 0;
    private int countOfMin = 0;
    private int countOfMax = 0;
    private int countOfExact = 0;
    private int countOfChoose = 0;
    private int countOfNominal = 0;
    private int countOfConcepts = 0;
    private int restoreCount = 0;
    
    public void clear()
    {
        countOfIndivids = 0;
        countOfAnd = 0;
        countOfOr = 0;
        countOfAll = 0;
        countOfSome = 0;
        countOfMin = 0;
        countOfMax = 0;
        countOfExact = 0;
        countOfChoose = 0;
        countOfNominal = 0;
        countOfConcepts = 0;
        restoreCount = 0;
    }
    
    public Statistics()
    {
    }
    
    public void conceptAdd() {
        countOfConcepts++;
    }
    
    public void andAdd() {
        countOfAnd++;
    }
    
    public void orAdd() {
        countOfOr++;
    }
    
    public void allAdd() {
        countOfAll++;
    }
    
    public void someAdd() {
        countOfSome++;
    }
    
    public void minAdd() {
        countOfMin++;
    }
    
    public void maxAdd() {
        countOfMax++;
    }
    
    public void exactAdd() {
        countOfExact++;
    }
    
    public void chooseAdd() {
        countOfChoose++;
    }
    
    public void nominalAdd() {
        countOfNominal++;
    }
    
    public void individAdd()
    {
        countOfIndivids++;
    }
    
    public void restoreCountAdd()
    {
        restoreCount++;
    }
    
    public int getRestoreCount()
    {
        return restoreCount;
    }
    
    public void printStats()
    {
        System.out.printf("+=================+==========+\n");
        System.out.printf("|    Operation    | count    |\n");
        System.out.printf("+=================+==========+\n");
        System.out.printf("|AND:             | %8d |\n", countOfAnd);
        System.out.printf("+=================+==========+\n");
        System.out.printf("|OR:              | %8d |\n", countOfOr);
        System.out.printf("+=================+==========+\n");
        System.out.printf("|ALL:             | %8d |\n", countOfAll);
        System.out.printf("+=================+==========+\n");
        System.out.printf("|SOME:            | %8d |\n", countOfSome);
        System.out.printf("+=================+==========+\n");
        System.out.printf("|CONCEPTS:        | %8d |\n", countOfConcepts);
        System.out.printf("+=================+==========+\n");
        System.out.printf("|INDIVIDS:        | %8d |\n", countOfIndivids);
        System.out.printf("+=================+==========+\n");
        System.out.printf("|RESTORES:        | %8d |\n", restoreCount);
        System.out.printf("+=================+==========+\n");
    }
    
}
