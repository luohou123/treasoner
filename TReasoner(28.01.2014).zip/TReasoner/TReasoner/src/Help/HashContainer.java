/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import java.util.HashSet;

/**
 *
 * @author 1
 */
public class HashContainer {

    public HashSet<Integer> base = new HashSet<Integer>();
    
    public HashContainer()
    {
    }
    
    public boolean contain(int x)
    {
        return base.contains(x);
    }
    
    public void add(int x)
    {
        base.add(x);
    }
    
    public void add(HashSet<Integer> hsi)
    {
        base.addAll(hsi);
    }
    
    public void clear()
    {
        base.clear();
    }
    
}
