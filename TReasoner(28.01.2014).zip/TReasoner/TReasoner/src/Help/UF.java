/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import java.util.ArrayList;

/**
 *
 * @author 1
 */
public class UF {
    
    static public int ABS(int x)
    {
        if(x < 0) return -x;
        return x;
    }    
    
    static public int Sign(int x)
    {
        if(x < 0) return 1;
        if(x > 0) return 2;
        return 0;
    }
    
    static public String skipDels(String s)    
    {
        String ret = "";
        boolean bl = false;
        for(int i = 0; i < s.length(); i++)
        {
            if(!isSkippedSymbol(s.charAt(i))) bl = true;
            if(bl) ret += s.charAt(i);
        }
        return ret;
    }
    
    static public String getToken(String s, int index)
    {
        return getTokens(s)[index - 1];
    }
    
    static public boolean isSkippedSymbol(char ch)
    {
        return ch == ' ' || ch == '\n' || ch == '\t';
    }
    
    static public String[] getTokens(String expr)
    {
        expr = skipDels(expr);
        ArrayList<String> as = new ArrayList<String>();
        
        int l = 0;
        int r = expr.length();
        while(l < r)
        {
            while(isSkippedSymbol(expr.charAt(l))) l++;
            int balance = 0;
            String token = "";
            while(l < r)
            {
                if(expr.charAt(l) == '(') balance++;
                if(expr.charAt(l) == ')') balance--;
                if(isSkippedSymbol(expr.charAt(l)) && balance == 0) break;
                token += expr.charAt(l);
                l++;
            }
            as.add(token);
        }
        
        String[] ret = new String[as.size()];
        for(int i = 0; i < as.size(); i++)
            ret[i] = as.get(i);

        return ret;
    }
}
