/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import Interpretation.InterpretationNode;
import RuleGraph.RuleGraph;

/**
 *
 * @author 1
 */
public class TCache {
    
    private int MaxSize = 1 << 13;
    private IntArray[] cac = new IntArray[MaxSize];
    private int size = 0;
    private RuleGraph tree = null;

    IntArray temp = new IntArray();
    
    public TCache(RuleGraph t)
    {
        tree = t;
        for(int i = 0; i < MaxSize; i++)
            cac[i] = new IntArray();
        size = 0;
    }
    
    public void setRuleGraph(RuleGraph t)
    {
        tree = t;
    }
    
    public void merge(TCache cache)
    {
        for(int i = 0; i < cache.getSize(); i++)
        {
            if(size == MaxSize) return;
            cac[size++] = cache.getCache(i);
        }
    }
    
    public IntArray getCache(int x)
    {
        return cac[x];
    }
    
    public int getSize()
    {
        return size;
    }
    
    public void clear()
    {
        temp.clear();
        for(int i = 0; i < size; i++)
            cac[i].clear();
        size = 0;
    }
    
    public void add(InterpretationNode node)
    {
        if(size == MaxSize) return;
        if(!find(node))
        {
            for(int i = 0; i < temp.size(); i++)
            {
                cac[size].add(temp.get(i));
            }
            size++;
        }
    }
    
    public boolean neg_add(InterpretationNode node)
    {
        if(size == MaxSize) return false;
        if(!neg_find(node))
        {
            for(int i = 0; i < temp.size(); i++)
            {
                cac[size].add(temp.get(i));
            }
            size++;
            return true;
        }
        return false;
    }
    
    public boolean neg_find(InterpretationNode node)
    {
        temp.clear();
        for(int i = 0; i < node.getToDoSize(); i++)
        {
            int v = tree.getNode(UF.ABS(node.getToDo()[i])).getCacheClass();
            if(node.getToDo()[i] < 0) v = -v;
            if(v == 0) v = node.getToDo()[i];
            temp.add(v);
        }
        temp.sort();
        
        for(int i = 0; i < size; i++)
        {
            if(temp.contain(cac[i])) return true;
        }
        return false;
    }
 
    public boolean find(InterpretationNode node)
    {
        temp.clear();
        for(int i = 0; i < node.getToDoSize(); i++)
        {
            int v = tree.getNode(UF.ABS(node.getToDo()[i])).getCacheClass();
            if(node.getToDo()[i] < 0) v = -v;
            if(v == 0) v = node.getToDo()[i];
            temp.add(v);
        }
        temp.sort();
        
        for(int i = 0; i < size; i++)
        {
            if(cac[i].contain(temp)) return true;
        }
        return false;
    }
}
