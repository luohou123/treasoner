/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import Interpretation.InterpretationNode;
import java.util.ArrayList;

/**
 *
 * @author 1
 */
public final class Couple {
    private InterpretationNode node; //index of child
    private ArrayList<Integer> roles = new ArrayList<Integer>(); //index of role
            
    public Couple(InterpretationNode new_node, int new_role_index)
    {
        node = new_node;
        roles.add(new_role_index);
    }
    
    public Couple(Couple c)
    {
        node = c.getNode();
        roles.addAll(c.getRoles());
    }
    
    @Override
    public boolean equals(Object obj)
    {
        Couple t = (Couple) obj;
        return (node.equals(t.node) && roles.containsAll(t.roles));
    }
    
    public InterpretationNode getNode()
    {
        return node;
    }
    
    public ArrayList<Integer> getRoles()
    {
        return roles;
    }
    
}