/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import Enums.NodeType;
import RuleGraph.RuleGraph;
import RuleGraph.RuleNode;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

/**
 *
 * @author 1
 */
public class Automorphism {

    class NodeWithDepth
    {
        public int d;
        public RuleNode r;
        public NodeWithDepth(RuleNode rn, int depth)
        {
            r = rn;
            d = depth;
        }
    }
    
    class NwDComp implements Comparator<NodeWithDepth>
    {
        public NwDComp() 
        {
        }

        public int compare(NodeWithDepth o1, NodeWithDepth o2) 
        {
            if(o1.d < o2.d)
            {
                return -1;
            }
            if(o1.d > o2.d)
            {
                return 1;
            }
            return 0;
        }

    }
    
    private RuleGraph tree;
    private String label[] = null;
    private NodeWithDepth nodes[] = null;
    private int height[] = null;
    int n = 0;
    
    HashMap<RuleNode, Integer> hm = null;
    HashSet<String> hs = null;
    
    HashMap<RuleNode, String> lab = null;
    
    public Automorphism(RuleGraph t)
    {
        tree = t;
    }

    public void setRuleGraph(RuleGraph t)
    {
        tree = t;
    }
    
    int f[];
    private int DFS(int x)
    {
        f[UF.ABS(x)] = 1;
        RuleNode rn = tree.getNode(UF.ABS(x));
        int max = 0;
        for(int i = 0; i < rn.getChildren().size(); i++)
        {
            if(f[UF.ABS(rn.getChildren().get(i))] == 1)
            {
                if( max < height[UF.ABS(rn.getChildren().get(i))] + 1)
                {
                    max = height[UF.ABS(rn.getChildren().get(i))] + 1;
                }
                continue;
            }
            int m = DFS(UF.ABS(rn.getChildren().get(i)));
            if( max < m + 1)
            {
                max = m + 1;
            }
        }
        nodes[n] = new NodeWithDepth(tree.getNode(UF.ABS(x)), max);
        height[UF.ABS(x)] = max;
        n++;
        return max;
    }
    
    private int getID(RuleNode rn)
    {
        return hm.get(rn);
    }
    
    private void sort(int node_index)
    {
        f = new int[tree.getNodesCount()];
        height = new int[tree.getNodesCount()];
        nodes = new NodeWithDepth[tree.getNodesCount()];
        n = 0;
        DFS(node_index);
        
        hm = new HashMap<RuleNode, Integer>();
        hs = new HashSet<String>();
        lab = new HashMap<RuleNode, String>();
        
        Arrays.sort(nodes, 0, n, new NwDComp());

        for(int i = 0; i < n; i++)
        {
            if(nodes[i] == null)
            {
                int kor = 123;
            }
            hm.put(nodes[i].r, i);
        }
        
        for(int i = 0; i < n; i++)
        {
            //System.out.print(nodes[i].r.getNodeType());
            //System.out.print(" ");
            //System.out.println(nodes[i].d);
        }
    }
    
    public void labelTree(int node_index)
    {
        label = new String[tree.getNodesCount()];
        sort(node_index);
        for(int i = 0; i < n; i++)
        {
            nodes[i].r.clearParent();
        }

        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < nodes[i].r.getChildren().size(); j++)
            {
                RuleNode rn = tree.getNode(UF.ABS(nodes[i].r.getChildren().get(j)));
                if(nodes[i].r.getChildren().get(j) < 0)
                {
                    rn.addParent(-i);
                } else
                {
                    rn.addParent(i);
                }
            }
        }
        
        //go to down top direction
        for(int i = 0; i < n; i++)
        {
            //Sorting working labels on same depth and determining label of vertice
            if(i > 0)
            {
                if(nodes[i].d != nodes[i - 1].d)
                {
                    //System.out.println();
                    String temp_labels[] = new String[i];
                    int m = 0;
                    hs.clear();
                    for(int j = i - 1; j >= 0; j--)
                    {
                        if(nodes[j].d != nodes[i - 1].d) break;
                        hs.add(label[j]);
                    }
                    
                    for(String s: hs)
                    {
                        temp_labels[m++] = s;
                    }
                    Arrays.sort(temp_labels, 0, m);
                    
                    for(int j = i - 1; j >= 0; j--)
                    {
                        if(nodes[j].d != nodes[i - 1].d) break;
                        int num = 0;
                        for(int k = 0; k < m; k++)
                        {
                            if(label[j].equals(temp_labels[k]))
                            {
                                num = k + 1; break;
                            }
                        }
                        label[j] = String.valueOf(num);
                    }
                }
            }
            //Determing working label
            String current_label = "";
            if(nodes[i].r.getNodeType() == NodeType.ntAND)
            {
                current_label = "2";
            } else
            if(nodes[i].r.getNodeType() == NodeType.ntOR)
            {
                current_label = "3";
            } else
            if(nodes[i].r.getNodeType() == NodeType.ntSOME)
            {
                current_label = "4";
            } else
            if(nodes[i].r.getNodeType() == NodeType.ntALL)
            {
                current_label = "5";
            } else
            if(nodes[i].r.getNodeType() == NodeType.ntNOT)
            {
                current_label = "6";
            } else
            {
                current_label = "1";
            }
            
            String labels[] = new String[nodes[i].r.getChildren().size()];
            for(int j = 0; j < nodes[i].r.getChildren().size(); j++)
            {
                labels[j] = "";
                int ind = nodes[i].r.getChildren().get(j); 
                if(ind < 0) labels[j] = "-";
                ind = UF.ABS(ind);
                labels[j] = labels[j] + label[getID(tree.getNode(ind))];
            }
            Arrays.sort(labels, 0, nodes[i].r.getChildren().size());
            for(int j = 0; j < nodes[i].r.getChildren().size(); j++)
            {
                current_label = current_label + labels[j];
            }
            label[i] = current_label;
            //System.out.print(nodes[i].r.getNodeType() + " " + nodes[i].r.getName() + " " + current_label + "\n");
        }
        
        String temp_labels[] = new String[n];
        int m = 0;
        hs.clear();
        for(int j = n - 1; j >= 0; j--)
        {
            if(nodes[j].d != nodes[n - 1].d) break;
            hs.add(label[j]);
        }

        for(String s: hs)
        {
            temp_labels[m++] = s;
        }
        Arrays.sort(temp_labels, 0, m);

        for(int j = n - 1; j >= 0; j--)
        {
            if(nodes[j].d != nodes[n - 1].d) break;
            int num = 0;
            for(int k = 0; k < m; k++)
            {
                if(label[j].equals(temp_labels[k]))
                {
                    num = k + 1; break;
                }
            }
            label[j] = String.valueOf(num);
        }
        
        //go to top down direction
        //System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        String j_label[] = new String[tree.getNodesCount()];
        for(int i = n - 1; i >= 0; i--)
        {
            if(i < n - 1)
            {
                if(nodes[i].d != nodes[i + 1].d)
                {
                    //System.out.println();
                    String j_temp_labels[] = new String[n - i + 1];
                    int mm = 0;
                    hs.clear();
                    for(int j = i + 1; j < n; j++)
                    {
                        if(nodes[j].d != nodes[i + 1].d) break;
                        hs.add(j_label[j]);
                    }
                    for(String s: hs)
                    {
                        j_temp_labels[mm++] = s;
                    }
                    Arrays.sort(j_temp_labels, 0, mm);
                    for(int j = i + 1; j < n; j++)
                    {
                        if(nodes[j].d != nodes[i + 1].d) break;
                        int nnum = 0;
                        for(int k = 0; k < mm; k++)
                        {
                            if(j_temp_labels[k].equals(j_label[j]))
                            {
                                nnum = k + 1; break;
                            }
                        }
                        j_label[j] = String.valueOf(nnum);
                    }
                }
            }            
            String current_label = label[i];
            String labels[] = new String[nodes[i].r.getParents().size()];
            for(int j = 0; j < nodes[i].r.getParents().size(); j++)
            {
                labels[j] = "";
                int ind = nodes[i].r.getParents().get(j);
                if(ind < 0)
                {
                    labels[j] = "-";
                }
                ind = UF.ABS(ind);
                labels[j] = labels[j] + j_label[ind];
            }
            Arrays.sort(labels, 0, nodes[i].r.getParents().size());
            for(int j = 0; j < nodes[i].r.getParents().size(); j++)
            {
                current_label = current_label + labels[j];
            }
            j_label[i] = current_label;
            //System.out.print(nodes[i].r.getNodeType() + " " + nodes[i].r.getName() + " " + current_label + "\n");
        }
        
        String j_temp_labels[] = new String[n];
        int mm = 0;
        hs.clear();
        for(int j = 0; j < n; j++)
        {
            if(nodes[j].d != nodes[0].d) break;
            hs.add(j_label[j]);
        }
        for(String s: hs)
        {
            j_temp_labels[mm++] = s;
        }
        Arrays.sort(j_temp_labels, 0, mm);
        for(int j = 0; j < n; j++)
        {
            if(nodes[j].d != nodes[0].d) break;
            int nnum = 0;
            for(int k = 0; k < mm; k++)
            {
                if(j_temp_labels[k].equals(j_label[j]))
                {
                    nnum = k + 1; break;
                }
            }
            j_label[j] = String.valueOf(nnum);
        }

        int[] flag = new int[nodes.length];
        Arrays.fill(flag, 0);
        //System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        for(int i = 0; i < n - 1; i++)
        {
            if(flag[i] == 1) continue;
            //System.out.print(nodes[i].r.getNodeType() + " ");
            int class_id = i + 100000;
            nodes[i].r.setCacheClass(class_id);
            for(int j = i + 1; nodes[j].d == nodes[i].d; j++)
            {
                if(j_label[i].equals(j_label[j]))
                {
                    nodes[j].r.setCacheClass(class_id);
                    flag[j] = 1;
                    //System.out.print(nodes[j].r.getNodeType() + " ");
                }
            }
            //System.out.println();
        }
    }
}