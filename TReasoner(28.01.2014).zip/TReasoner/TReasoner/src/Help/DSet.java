/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

/**
 *
 * @author 1
 */
public class DSet {

    int MaxSize = 4;
    private int[] ar = new int[MaxSize];
    int Size = 0;
    
    public DSet()
    {
        
    }
    
    public void clear()
    {
        Size = 0;
    }
    
    public void pop()
    {
        Size--;
    }
    
    public int size()
    {
        return Size;
    }
    
    public void increase()
    {
        int[] old = ar;
        MaxSize = (MaxSize * 3) / 2 + 1;
        
        ar = new int[MaxSize];
        for(int i = 0; i < Size; i++)
            ar[i] = old[i];
    }
    
    public void add(int x)
    {
        if(Size == MaxSize - 1)
        {
            increase();
        }
        
        ar[Size] = x;
        Size++;
    }
            
    public DSet(DSet d)
    {
        if(d == null) return;
        for(int i = 0; i < d.getValues().length; i++)
            add(d.getValues()[i]);
    }
    
    public void addValue(int x)
    {
        if(x == 0) return;
        if(Size == MaxSize - 1)
        {
            increase();
        }
        
        for(int i = 0; i < Size - 1; i++)
            if(ar[i] <= x && x <= ar[i + 1])
            {
                if(ar[i] == x || ar[i + 1] == x) return; //not add x if this is already exists
                for(int j = Size; j > i + 1; j--)
                {
                    ar[j] = ar[j - 1];
                }
                ar[i + 1] = x;
                Size++;
                return;
            }

        ar[Size] = x;
        Size++;
    }
    
    public int[] getValues()
    {
        int[] b = new int[Size];
        for(int i = 0; i < Size; i++)
            b[i] = ar[i];
        
        return b;
    }
    
    public void mergeWith(DSet d)
    {
        if(d == null) return;
        int[] a1 = new int[Size];
        for(int i = 0; i < Size; i++)
            a1[i] = ar[i];

        int[] a2 = d.getValues();
        
        int[] a3 = new int[a1.length + a2.length];
        
        int it1 = 0;
        int it2 = 0;
        int it3 = 0;
        
        while(it1 < a1.length && it2 < a2.length)
        {
            if(a1[it1] < a2[it2])
            {
                a3[it3] = a1[it1];
                it1++; it3++;
            } else
            if(a1[it1] > a2[it2])
            {
                a3[it3] = a2[it2];
                it2++; it3++;
            } else
            {
                a3[it3] = a1[it1];
                it1++; it2++; it3++;
            }
        }

        for(; it1 < a1.length; it1++)
        {
            a3[it3++] = a1[it1];
        }
        
        for(; it2 < a2.length; it2++)
        {
            a3[it3++] = a2[it2];
        }

        Size = 0;
        for(int i = 0; i < it3; i++)
        {
            if(i > 0) if(a3[i] == a3[i - 1]) continue;
            if(Size == MaxSize - 1)
            {
                increase();
            }
            ar[Size] = a3[i];
            Size++;
        }
    }
    
}
