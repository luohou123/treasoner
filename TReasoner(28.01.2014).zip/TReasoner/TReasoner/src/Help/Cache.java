/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import Enums.NodeType;
import KB.RBox;
import KB.TBox;

/**
 *
 * @author Boris
 */
public class Cache {
    
    int MaxSize = 32;
    int[] a = new int[MaxSize];
    int size = 0;
    
    private void increase()
    {
        int[] old_a = a;
        MaxSize = MaxSize * 3 / 2;
        a = new int[MaxSize];
        for(int i = 0; i < size; i++)
            a[i] = old_a[i];
        
        old_a = null;
    }
    
    public Cache()
    {
    }
    
    public int getSize()
    {
        return size;
    }
    
    public void setSize(int new_size)
    {
        size = new_size;
    }
    
    public int[] getCache()
    {
        return a;
    }
    
    public void clear()
    {
        size = 0;
    }
    
    public boolean canMerge(Cache ctm, RBox r_box, TBox t, Cache[][] cache)
    {
        //return false;
        int xx = 0, yy = 0;
        int cnt = 0;
        if(ctm.getSize() == -1 || size == -1) return false;
        for(int j = 0; j < size; j++)
        {
            for(int i = 0; i < ctm.getSize(); i++)
            {
                int x = ctm.getCache()[i];
                if(a[j] == -x) return false;
                if(a[j] == x) continue;
                
                if( t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntINDIVID || 
                    t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntINDIVID) return false;
                
                int sm1 = 0, al1 = 0, sm2 = 0, al2 = 0;
                int mx1 = 0, mn1 = 0, mx2 = 0, mn2 = 0;
                int rt1 = 0, rt2 = -1;
                
                rt1 = t.getRuleGraph().getNode(UF.ABS(a[j])).getRoleType();
                rt2 = t.getRuleGraph().getNode(UF.ABS(x)).getRoleType();
                
                if(t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntSOME && a[j] > 0 ||
                   t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntALL && a[j] < 0) sm1 = 1;
                
                if(t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntMINCARD && a[j] > 0 ||
                   t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntMAXCARD && a[j] < 0) mn1 = 1;
                
                if(t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntALL && a[j] > 0 ||
                   t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntSOME && a[j] < 0) al1 = 1;
                
                if(t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntMAXCARD && a[j] > 0 ||
                   t.getRuleGraph().getNode(UF.ABS(a[j])).getNodeType() == NodeType.ntMINCARD && a[j] < 0) mx1 = 1;
                
                if(t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntSOME && x > 0 ||
                   t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntALL && x < 0) sm2 = 1;
                
                if(t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntMINCARD && x > 0 ||
                   t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntMAXCARD && x < 0) mn2 = 1;
                
                if(t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntALL && x > 0 ||
                   t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntSOME && x < 0) al2 = 1;
                
                if(t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntMAXCARD && x > 0 ||
                   t.getRuleGraph().getNode(UF.ABS(x)).getNodeType() == NodeType.ntMINCARD && x < 0) mx2 = 1;
                
                if((((mn1 == 1 || sm1 == 1) && al2 == 1) || ((mn2 == 1 || sm2 == 1) && al1 == 1)) && (
                        r_box.isSubOrEqual(rt1, rt2) || 
                        r_box.isSubOrEqual(rt2, rt1) || 
                        r_box.isReverseSubOrEqual(rt1, rt2) ||
                        r_box.isReverseSubOrEqual(rt2, rt1)))
                {
                    xx = x;
                    yy = a[j];
                    cnt++;
                }
                
                if(((mn1 == 1 || sm1 == 1) && (mn2 == 1 || sm2 == 1)) && (
                        r_box.isSubOrEqual(rt1, rt2) || 
                        r_box.isSubOrEqual(rt2, rt1) || 
                        r_box.isReverseSubOrEqual(rt1, rt2) ||
                        r_box.isReverseSubOrEqual(rt2, rt1)) && (r_box.getRoleByIndex(rt1).isFunctional() || r_box.getRoleByIndex(rt2).isFunctional()))
                {
                    return false;
                }

                if((mx1 == 1 && mn2 == 1 || mn1 == 1 && mx2 == 1) && (
                        r_box.isSubOrEqual(rt1, rt2) || 
                        r_box.isSubOrEqual(rt2, rt1) || 
                        r_box.isReverseSubOrEqual(rt1, rt2) ||
                        r_box.isReverseSubOrEqual(rt2, rt1)))
                {
                    return false;
                }
            }
        }
        if(cnt > 1) return false;
        if(cnt > 0)
        {
            int xc = t.getRuleGraph().getNode(UF.ABS(xx)).getChildren().get(0);
            int yc = t.getRuleGraph().getNode(UF.ABS(yy)).getChildren().get(0);
            if( t.getRuleGraph().getNode(UF.ABS(xc)).getNodeType() == NodeType.ntTHING && 
                t.getRuleGraph().getNode(UF.ABS(yc)).getNodeType() == NodeType.ntCONCEPT)
            {
                int n2 = 0;
                if(yy < 0) yc *= -1;
                if(yc < 0) n2 = 1;
                int conc_id2 = t.getRuleGraph().getConcepts().indexOf(t.getRuleGraph().getNode(UF.ABS(yc)).getName());
                return cache[n2][conc_id2].getSize() != -1;
            }
            if( t.getRuleGraph().getNode(UF.ABS(xc)).getNodeType() == NodeType.ntCONCEPT && 
                t.getRuleGraph().getNode(UF.ABS(yc)).getNodeType() == NodeType.ntTHING)
            {
                int n1 = 0;
                if(xx < 0) xc *= -1;
                if(xc < 0) n1 = 1;
                int conc_id1 = t.getRuleGraph().getConcepts().indexOf(t.getRuleGraph().getNode(UF.ABS(xc)).getName());
                return cache[n1][conc_id1].getSize() != -1;
            }
            if( t.getRuleGraph().getNode(UF.ABS(xc)).getNodeType() == NodeType.ntCONCEPT && 
                t.getRuleGraph().getNode(UF.ABS(yc)).getNodeType() == NodeType.ntCONCEPT)
            {
                int n1 = 0, n2 = 0;
                if(xx < 0) xc *= -1;
                if(yy < 0) yc *= -1;
                if(xc < 0) n1 = 1;
                if(yc < 0) n2 = 1;
                int conc_id1 = t.getRuleGraph().getConcepts().indexOf(t.getRuleGraph().getNode(UF.ABS(xc)).getName());
                int conc_id2 = t.getRuleGraph().getConcepts().indexOf(t.getRuleGraph().getNode(UF.ABS(yc)).getName());
                return cache[n1][conc_id1].canMerge(cache[n2][conc_id2], r_box, t, cache);
            } else
            {
                return false;
            }
        }
        return true;
    }
    
    public void show()
    {
        if(size == 0) System.out.println("CACHE IS EMPTY. CONCEPT IS UNSATISFIABLE!");
        for(int i = 0; i < size; i++)
        {
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }
    
    public void add(int x)
    {
        if(size == MaxSize - 1) increase();
        a[size++] = x;
    }
    
}
