/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Help;

import Enums.NodeType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author Boris
 */
public class SHash {
    
    private class HashE
    {
        public HashE next;
        public int hf1, hf2, n, hf3, hf4;
        public HashE(int _hf1, int _hf2, int _hf3, int _hf4, int _n)
        {
            hf1 = _hf1;
            hf2 = _hf2;
            hf3 = _hf3;
            hf4 = _hf4;
            n = _n;
            next = null;
        }
    }
    
    private class Pair
    {
        public int x, y;
        public Pair(int _x, int _y)
        {
            x = _x; y = _y;
        }
    }
    
    private class PairComparer implements Comparator<Pair>
    {

        @Override
        public int compare(Pair o1, Pair o2) {
            if(o1.x == o2.x)
            {
                if(o1.y < o2.y) return -1;
                if(o1.y > o2.y) return 1;
                return 0;
            }
            if (o1.x < o2.x) {
                return -1;
            }
            if (o1.x > o2.x) {
                return 1;
            }
            return 0;
        }
        
    }
    
    final int hC1 = 107;
    final int hC2 = 1051;
    final int hSize = (1 << 12);
    private HashE[] table = new HashE[hSize];
    final int hModul = (1 << 21);
    
    public SHash()
    {
    }
    
    private int Inv(int x)
    {
        if(x == 0) return 2;
        if(x == 2) return 0;
        if(x == 3) return 4;
        if(x == 4) return 3;
        return 1;
    }
    
    public int add(ArrayList<Integer> al, int n, int type, int role)
    {
        int pow1 = 1, pow2 = 1;
        int hf1 = 0, hf2 = 0, hf3 = 0, hf4 = 0;
        Pair[] p = new Pair[al.size()];
        for(int i = 0; i < al.size(); i++)
        {
            p[i] = new Pair(UF.ABS(al.get(i)), UF.Sign(al.get(i)));
        }
        Arrays.sort(p, new PairComparer());
        
        hf1 = (hf1 + pow1 * type) % hModul;
        pow1 = (pow1 * hC1) % hModul;
        
        hf1 = (hf1 + pow1 * role) % hModul;
        pow1 = (pow1 * hC1) % hModul;
        
        pow1 = 1;
        hf3 = (hf3 + pow1 * role) % hModul;
        hf4 = (hf4 + pow1 * role) % hModul;
        
        pow1 = (pow1 * hC1) % hModul;
        hf3 = (hf3 + pow1 * type) % hModul;
        hf4 = (hf4 + pow1 * Inv(type)) % hModul;
        
        for(int i = 0; i < al.size(); i++)
        {
            hf1 = (hf1 + pow1 * p[i].x) % hModul;
            hf2 = (hf2 + pow2 * p[i].x) % hModul;
            
            int inv = p[i].y;
            if(inv == 1) inv = 2; else
                if(inv == 2) inv = 1;
            
            hf3 = (hf3 + pow1 * p[i].y) % hModul;
            hf4 = (hf4 + pow1 * inv) % hModul;
            
            pow1 = (pow1 * hC1) % hModul;
            pow2 = (pow2 * hC2) % hModul;
        }
        
        hf1 %= hSize;
        while(hf1 < 0) hf1 += hSize;
        HashE element = new HashE(hf1, hf2, hf3, hf4, n);
        if(table[hf1] == null)
        {
            table[hf1] = element;
        } else
        {
            for(HashE el = table[hf1]; el != null; el = el.next)
            {
                if(el.hf1 == hf1 && el.hf2 == hf2)
                {
                    if(el.hf3 == hf3) return el.n;
                    if(el.hf3 == hf4) return -el.n;
                }
            }

            element.next = table[hf1];
            table[hf1] = element;
        }
        return 0;
    }
    
    public int countOfElements()
    {
        int ret = 0;
        for(int i = 0; i < hSize; i++)
        {
            for(HashE el = table[i]; el != null; el = el.next)
                ret++;
        }
        return ret;
    }
    
}
