/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Automata;

import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author 1
 */
public class ATrans {
    
    private int from, to;
    private HashSet<Integer> label = null;
    
    public ATrans(int pfrom, int pto)
    {
        from = pfrom;
        to = pto;
    }
    
    public void setFrom(int pfrom)
    {
        from = pfrom;
    }
    
    public void setTo(int pto)
    {
        to = pto;
    }
    
    public int getFrom()
    {
        return from;
    }
    
    public int getTo()
    {
        return to;
    }
    
    public void addRole(int role_index)
    {
        if(role_index < 0) return;
        if(label == null)
        {
            label = new HashSet<Integer>();
        }
        label.add(role_index);
    }
    
    public HashSet<Integer> getLabel()
    {
        return label;
    }
    
}
