/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Automata;

import KB.RBox;
import java.util.ArrayList;

/**
 *
 * @author 1
 */
public class Automaton {
    
    private ArrayList<AState> states;
    private int role_index;
    
    public Automaton(int pindex)
    {
        role_index = pindex;
        states = new ArrayList<AState>();
        states.add(new AState( true, 0));
        states.add(new AState(false, 1));
        states.get(0).addTransit(new ATrans(0, 1));
    }
    
    public void setIndex(int pindex)
    {
        role_index = pindex;
    }
    
    public int getIndex()
    {
        return role_index;
    }
    
    public ArrayList<AState> getStates()
    {
        return states;
    }
    
    public void makeAR()
    {
        
    }
    
    private void addSubAutomaton(Automaton a, int from, int to)
    {
        int[] map = new int[a.getStates().size()];
        for(int i = 0; i < a.getStates().size(); i++)
        {
            map[i] = states.size();
            states.add(new AState(true, i));
        }
        
        for(int i = 0; i < a.getStates().size(); i++)
        {
            ArrayList<ATrans> atr = a.getStates().get(i).getTransits();
            for(int j = 0; j < atr.size(); j++)
            {
                ATrans at = new ATrans(map[i], map[atr.get(j).getTo()]);
                for(int k: atr.get(j).getLabel())
                {
                    at.addRole(k);
                }
                
                states.get(map[i]).addTransit(at);
            }
        }
        
        states.get(0).addTransit(new ATrans(0, map[0]));
        states.get(0).addTransit(new ATrans(map[1], 1));
    }
    
    public void addChain(ArrayList<Integer> ch, RBox r)
    {
        int from = 0;
        int to = 1;
                
        int st = 0;
        int fn = ch.size();
        
        if(ch.get(st) == role_index) //R R1 R2 ... Rn [= R
        {
            st++;
            from = 1;
        }
        
        if(ch.get(fn - 1) == role_index) //R1 R2 ... Rn - 1 R [= R
        {
            fn++;
            to = 0;
        }
        
        int lab = -1; //e-transition
        int last_state = states.size();
        for(int i = st; i < fn; i++)
        {
            AState as = new AState(true, ch.size());
            states.add(as);
            
            ATrans at = new ATrans(from, ch.size() - 1);
            at.addRole(lab);
            as.addTransit(at);
            
            lab = ch.get(i);
            from = ch.size() - 1;
        }
        ATrans at = new ATrans(from, to);
        states.get(states.size() - 1).addTransit(at);
        //you must to THINK!
        /*
        for(int i = last_state; i < states.size(); i++)
        {
            ArrayList<ATrans> atr = states.get(i).getTransits();
            if(atr == null) continue;
            for(int j = 0; j < atr.size(); j++)
            {
                if(atr.get(j).getLabel() == null) continue;
                for(int k: atr.get(j).getLabel())
                {
                    addSubAutomaton(r.getAutomaton(k), atr.get(j).getFrom(), atr.get(j).getTo());
                }
            }
        }*/
        
    }
    
}
