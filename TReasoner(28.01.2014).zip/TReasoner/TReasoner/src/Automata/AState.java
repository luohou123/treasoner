/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Automata;

import java.util.ArrayList;

/**
 *
 * @author 1
 */
public class AState {
    
    private boolean initial;
    private ArrayList<ATrans> transits = null;
    private int index;
    
    public AState(boolean is_initial, int pindex)
    {
        initial = is_initial;
        index = pindex;
    }
    
    public void setIndex(int pindex)
    {
        index = pindex;
    }
    
    public int getIndex()
    {
        return index;
    }
    
    public boolean isInitial()
    {
        return initial;
    }
    
    public void addTransit(ATrans at)
    {
        if(transits == null)
            transits = new ArrayList<ATrans>();
        
        transits.add(at);
    }
    
    public ArrayList<ATrans> getTransits()
    {
        return transits;
    }
    
}
