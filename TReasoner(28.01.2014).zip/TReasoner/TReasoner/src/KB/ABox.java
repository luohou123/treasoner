/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KB;

import Help.DSet;
import Help.IntArray;
import Help.IntPair;
import Interpretation.InterpretationNode;
import java.util.ArrayList;
import java.util.HashMap;
import org.semanticweb.owlapi.model.OWLIndividual;

/**
 *
 * @author 1
 */
public class ABox {

    private class Edges
    {
        public ArrayList<IntPair> a = new ArrayList<IntPair>();
    }
    
    final int MaxCount = 1024 * 128;
    private String[] names = new String[MaxCount];
    private InterpretationNode[] nodes = new InterpretationNode[MaxCount];
    private IntArray[] a = new IntArray[MaxCount];
    private Edges[] E = new Edges[MaxCount];
    
    int names_count = 0;
    private HashMap<String, Integer> name_set = new HashMap<String, Integer>();
    
    public ABox()
    {
        for(int i = 0; i < MaxCount; i++)
        {
            a[i] = new IntArray();
            E[i] = new Edges();
        }
        names_count = 0;
    }
    
    public void clear(ArrayList<String> als)
    {
        for(int i = 0; i < als.size(); i++)
        {
            nodes[find(als.get(i))] = null;
        }
    }
    
    public void clearNodes()
    {
        for(int i = 0; i < MaxCount; i++)
        {
            if(nodes[i] != null)
                nodes[i].clear();
            nodes[i] = null;
        }
    }
    
    public int getCount()
    {
        return names_count;
    }
    
    public String getName(int x)
    {
        return names[x];
    }
    
    public void setNode(int x, InterpretationNode nod)
    {
        nodes[x] = nod;
    }
    
    public int find(OWLIndividual individ)
    {
        String name = "";
        if(individ.isNamed())
        {
            name = individ.asOWLNamedIndividual().toStringID();
        } else
        {
            name = individ.asOWLAnonymousIndividual().toStringID();
        }
        
        if(name_set.containsKey(name)) return name_set.get(name);
        names[names_count++] = name;
        name_set.put(name, names_count - 1);
        return names_count - 1;
    }
        
    public InterpretationNode findNode(String name)
    {
        if(name_set.containsKey(name))
        {
            if(nodes[name_set.get(name)] != null) if(nodes[name_set.get(name)].indexInQueue < 0) return null;
            return nodes[name_set.get(name)];
        }
        return null;
    }
        
    public int find(String name)
    {
        if(name_set.containsKey(name)) return name_set.get(name);
        names[names_count++] = name;
        name_set.put(name, names_count - 1);
        return names_count - 1;
    }
    
    public void add(OWLIndividual individ, int toDoEntry)
    {
        if(individ.isNamed())
        {
            a[find(individ)].add(toDoEntry);
        } else
        {
            a[find(individ)].add(toDoEntry);
        }
    }
    
    public void add(String individ, int toDoEntry)
    {
        //System.out.println("INDIVID LOADED FROM AKB");
        a[find(individ)].add(toDoEntry);
    }
    
    public InterpretationNode createNode(String name, DSet dd, InterpretationNode ret, TBox t_box)
    {
        int hl = ret.indexInQueue;
        ret.clear();
        ret.indexInQueue = hl;
        int x = find(name);
        for(int i = 0; i < a[x].size(); i++)
        {
            DSet D = new DSet();
            D.mergeWith(dd);
            ret.addToDo(a[x].get(i), D, 0, t_box);
        }
        nodes[x] = ret;
        nodes[x].addIndivid(name, 0);//when is 0
        return ret;
    }
    
    public InterpretationNode createNodeFast(int id, InterpretationNode ret)
    {
        int hl = ret.indexInQueue;
        ret.clear();
        ret.indexInQueue = hl;
        for(int i = 0; i < a[id].size(); i++)
        {
            ret.addToDo(a[id].get(i), new DSet(), 0, null);
        }
        nodes[id] = ret;
        nodes[id].addIndivid(names[id], 0);
        return ret;
    }
    
    ArrayList<String> q = new ArrayList<String>();
    public ArrayList<String> getExpandedNodes(String name) //too slow
    {
        q.clear();
        expandNodes(name);
        return q;
    }
    
    public ArrayList<String> getNodesByConcept(int concept_id) //too slow
    {
        q.clear();
        for(int i = 0; i < names_count; i++)
        {
            if(a[i].contain(concept_id))
            {
                q.add(names[i]);
            }
        }
        return q;
    }
    
    private void expandNodes(String name) //too slow
    {
        if(q.contains(name)) return;
        q.add(name);
        int x = find(name);
        for(int j = 0; j < E[x].a.size(); j++)
        {
            expandNodes(names[E[x].a.get(j).x]);
        }
        for(int i = 0; i < names_count; i++)
        {
            for(int j = 0; j < E[i].a.size(); j++)
            {
                if(names[E[i].a.get(j).x].equals(name))
                {
                    expandNodes(names[i]);
                }
            }
        }
    }
    
    public void show(RBox r_box)
    {
        for(int i = 0; i < names_count; i++)
        {
            System.out.println(names[i] + ":");
            for(int j = 0; j < E[i].a.size(); j++)
            {
                System.out.println("    " + r_box.getRoleByIndex(E[i].a.get(j).y).getName() + 
                        " " + names[E[i].a.get(j).x]);
            }
        }
    }
    
    public InterpretationNode getNode(int x)
    {
        return nodes[x];
    }
    
    public void realizeRelations(RBox r_box, int when)
    {
        for(int i = 0; i < names_count; i++)
        {
            for(int j = 0; j < E[i].a.size(); j++)
            {
                if((nodes[i] == null || nodes[E[i].a.get(j).x] == null) ||
                   (nodes[i].indexInQueue < 0 || nodes[E[i].a.get(j).x].indexInQueue < 0)) continue;
                
                nodes[i].addChild(getNode(E[i].a.get(j).x), E[i].a.get(j).y, when);
                nodes[E[i].a.get(j).x].addParent(getNode(i), E[i].a.get(j).y, when, r_box);
                nodes[E[i].a.get(j).x].updateParents(E[i].a.get(j).y, when, r_box);
                //add domain
                nodes[i].addToDo(r_box.getRoleByIndex(E[i].a.get(j).y).getDomain(), new DSet(), when, null);
                //add range
                nodes[E[i].a.get(j).x].addToDo(r_box.getRoleByIndex(E[i].a.get(j).y).getRange(), new DSet(), when, null);
            }
        }
    }
    
    public void addRelation(int individId1, int individId2, int roleType)
    {
        E[individId1].a.add(new IntPair(individId2, roleType));
    }
    
    public void addRelation(OWLIndividual ind1, OWLIndividual ind2, int role_type)
    {
        int individId1 = find(ind1);
        int individId2 = find(ind2);
        //System.out.println(ind1.asOWLNamedIndividual().getIRI().getFragment() + " " + role_type + " " + ind2.asOWLNamedIndividual().getIRI().getFragment());
        E[individId1].a.add(new IntPair(individId2, role_type));
    }
    
    public void clearIndivid(String name)
    {
        nodes[find(name)] = null;
    }
    
}