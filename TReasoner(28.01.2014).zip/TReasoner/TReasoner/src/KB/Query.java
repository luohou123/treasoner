/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KB;

import Help.IntPair;

/**
 *
 * @author 1
 */
public class Query {
    
    final int MaxSize = 128;
    int ii_size = 0;
    private IntPair[] ii = new IntPair[MaxSize];
    
    public Query()
    {
        for(int i = 0; i < MaxSize; i++)
        {
            ii[i] = new IntPair(0, 0);
        }
    }
    
    public void addIndividualInstance(int individId, int conceptId)
    {
        ii[ii_size].x = individId;
        ii[ii_size].y = conceptId;
        ii_size++;
    }
    
    public int getIndividualInstanceSize()
    {
        return ii_size;
    }
    
    public IntPair getIndividualInstance(int x)
    {
        return ii[x];
    }
    
}
