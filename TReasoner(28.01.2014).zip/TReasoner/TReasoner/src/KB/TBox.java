/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KB;

import Enums.NodeType;
import Help.IntArray;
import Help.TwoSidedAxiom;
import Help.UF;
import RuleGraph.RuleGraph;
import RuleGraph.RuleNode;
import java.util.ArrayList;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;

/**
 *
 * @author 1
 */
public class TBox {
            
    private RuleGraph rg = new RuleGraph();
    private IntArray order = null;
    private int[] f = null;
   
    private ArrayList<TwoSidedAxiom> EquivalenceAxioms = new ArrayList<TwoSidedAxiom>();
    private ArrayList<TwoSidedAxiom> GCIs = new ArrayList<TwoSidedAxiom>();

    private RBox r_box;
    
    private int meta_constraint = 1;
    
    public TBox(RBox rb)
    {
        clear();
        rg.setTBox(this);
        rg.setRBox(rb);
        r_box = rb;
    }
    
    public void outToOWL(String file_name) throws OWLOntologyCreationException, OWLOntologyStorageException
    {
        rg.printToOWL(file_name);
    }
    
    final public void clear()
    {
        EquivalenceAxioms.clear();
        GCIs.clear();
    }
    
    public void setRBox(RBox new_r_box)
    {
        r_box = new_r_box;
    }
    
    public RBox getRBox()
    {
        return r_box;
    }
    
    public RuleGraph getRuleGraph()
    {
        return rg;
    }
        
    public ArrayList<TwoSidedAxiom> getGCI()
    {
        return GCIs;
    }
    
    public ArrayList<TwoSidedAxiom> getEquivalenceAxiom()
    {
        return EquivalenceAxioms;
    }
    
    //axioms like C [= D (C is subsumed by D)
    public void addGCI(int sub_concept, int super_concept)
    {
        boolean is_exist = false;
        //С is a simple concept
        if(rg.getNode(UF.ABS(sub_concept)).getNodeType() == NodeType.ntCONCEPT)
            for(TwoSidedAxiom gci: GCIs)
                if(gci.getSub() == sub_concept)
                {
                    is_exist = true;
                    gci.addSuperConcept(super_concept, rg);
                    break;
                }
        
        if(!is_exist)
            GCIs.add(new TwoSidedAxiom(sub_concept, super_concept));            
    }

    //axioms like C = D, where C and D are composite concepts
    public void addEquivalenceAxiom(int left_side, int right_side)
    {
        boolean is_exist = false;
        //С is a simple concept
        //if(rg.getNode(left_side).getName().equals(""))
        if(right_side > 0) rg.getNode(right_side).setDescription(left_side);
        if(rg.getNode(UF.ABS(left_side)).getNodeType() == NodeType.ntCONCEPT)
            for(TwoSidedAxiom eq: EquivalenceAxioms)
                if(eq.getSub() == left_side)
                {
                    is_exist = true;
                    eq.addSuperConcept(right_side, rg);
                    break;
                }
        
        if(!is_exist)
            EquivalenceAxioms.add(new TwoSidedAxiom(left_side, right_side));
    }
    
    public void normalize()
    {
        //if concept C is a simple concept, then put D into description of C from equivalence C = D
        for(int i = 0; i < EquivalenceAxioms.size(); i++)
        {
            TwoSidedAxiom eq = EquivalenceAxioms.get(i);
            if(eq.getSub() > 0)
                if(rg.getNode(eq.getSub()).getNodeType() == NodeType.ntCONCEPT)
                {
                    rg.getNode(eq.getSub()).setDescription(eq.getSuper());
                    rg.getNode(eq.getSub()).setNamed(true);
                    EquivalenceAxioms.remove(i); i--;
                }
        }
        
        //if concept C is a simple concept, then put D into description of C from GCI C [= D
        for(int i = 0; i < GCIs.size(); i++)
        {
            TwoSidedAxiom gci = GCIs.get(i);
            if(gci.getSub() > 0)
                if(rg.getNode(gci.getSub()).getNodeType() == NodeType.ntCONCEPT)
                {
                    rg.getNode(gci.getSub()).setSubDescription(gci.getSuper());
                    GCIs.remove(i);
                    i--;
                }
        }
        
    }
    
    private void TopSort(int x, boolean isConcept)
    {
        int old_x = x;
        int sds_x = -1;
        if(isConcept)
        {
            f[x] = 1;
            sds_x = UF.ABS(rg.getNode(rg.findConcept(rg.getConcepts().get(x))).getSubDescription());
            x = UF.ABS(rg.getNode(rg.findConcept(rg.getConcepts().get(x))).getDescription());
        }
        ArrayList<Integer> ch = rg.getNode(UF.ABS(x)).getChildren();
        if(ch.size() > 0)
        {
            for(int i = 0; i < ch.size(); i++)
            {
                if(rg.getNode(UF.ABS(ch.get(i))).getNodeType() == NodeType.ntCONCEPT)
                {
                    if(f[rg.getConceptID(rg.getNode(UF.ABS(ch.get(i))).getName())] == 0)
                        TopSort(rg.getConceptID(rg.getNode(UF.ABS(ch.get(i))).getName()), true);
                } else
                {
                    TopSort(UF.ABS(ch.get(i)), false);
                }
            }
        } else
        if(sds_x > 0 && rg.getNode(UF.ABS(sds_x)).getChildren().size() > 0)
        {
            ch = rg.getNode(UF.ABS(sds_x)).getChildren();
            for(int i = 0; i < ch.size(); i++)
            {
                if(rg.getNode(UF.ABS(ch.get(i))).getNodeType() == NodeType.ntCONCEPT)
                {
                    if(f[rg.getConceptID(rg.getNode(UF.ABS(ch.get(i))).getName())] == 0)
                        TopSort(rg.getConceptID(rg.getNode(UF.ABS(ch.get(i))).getName()), true);
                } else
                {
                    TopSort(UF.ABS(ch.get(i)), false);
                }
            }            
        } else
        if(x != 0 && x != 1 && rg.getNode(UF.ABS(x)).getName() != null)
        {
            x = rg.getConceptID(rg.getNode(UF.ABS(x)).getName());
            if(f[x] == 0)
                TopSort(x, true);
        }
        if(isConcept)
        {
            order.add(old_x);
        }
        
    }
    
    public IntArray getOrder()
    {
        return order;
    }
    
    private void makeOrder()
    {
        if(order == null)
        {
            order = new IntArray();
            f = new int[2 * rg.getConcepts().size()];
        }
        for(int i = 0; i < rg.getConcepts().size(); i++)
        {
            if(f[i] == 0)
            {
                TopSort(i, true);
            }
        }
        //order.reverse();
    }
    
    private void absorb()
    {
        //part for adding only C [= D where C is atomic positive
        for(int i = 0; i < GCIs.size(); i++)
        {
            boolean removed = false;
            if(GCIs.get(i).getSuper() < 0) continue;
            if(rg.getNode(GCIs.get(i).getSuper()).getNodeType() == NodeType.ntOR) //this is C [= D1 or D2 or ... not Di ... or Dn
            {
                RuleNode tmp_n = rg.getNode(GCIs.get(i).getSuper());
                for(int j = 0; j < tmp_n.getChildren().size(); j++)
                {
                    if(tmp_n.getChildren().get(j) < 0)
                    {
                        RuleNode tmp_m = rg.getNode(-tmp_n.getChildren().get(j));
                        if(tmp_m.getNodeType() == NodeType.ntCONCEPT) //this is negative concept vertice
                        {
                            RuleNode nrn = new RuleNode(NodeType.ntOR);
                            nrn.addChild(-GCIs.get(i).getSub()); //add not C
                            for(int k = 0; k < tmp_n.getChildren().size(); k++)
                            {
                                if(j == k) continue;
                                nrn.addChild(tmp_n.getChildren().get(k)); //add Di
                            }
                            if(tmp_m.getSubDescription() == 0)
                            {
                                tmp_m.setSubDescription(rg.addNode2RuleTree(nrn));
                            } else
                            {
                                if(rg.getNode(tmp_m.getSubDescription()).getNodeType() == NodeType.ntAND)
                                {
                                    rg.getNode(tmp_m.getSubDescription()).addChild(rg.addNode2RuleTree(nrn));
                                } else
                                {
                                    RuleNode and_node = new RuleNode(NodeType.ntAND);
                                    and_node.addChild(rg.addNode2RuleTree(nrn));
                                    and_node.addChild(tmp_m.getSubDescription());                                    
                                    tmp_m.setSubDescription(rg.addNode2RuleTree(and_node));
                                }
                            }
                            removed = true;                            
                        }
                    }
                }
            }
            
            if(rg.getNode(GCIs.get(i).getSub()).getNodeType() == NodeType.ntAND && !removed) //this is C1 and C2 and ... and Cn [= D
            {
                RuleNode tmp_n = rg.getNode(GCIs.get(i).getSub());                
                for(int j = 0; j < tmp_n.getChildren().size(); j++)
                {
                    if(tmp_n.getChildren().get(j) > 0)
                    {
                        RuleNode tmp_m = rg.getNode(tmp_n.getChildren().get(j));
                        if(tmp_m.getNodeType() == NodeType.ntCONCEPT) //this is positive concept vertice
                        {
                            RuleNode nrn = new RuleNode(NodeType.ntOR);
                            nrn.addChild(GCIs.get(i).getSuper()); //add D
                            for(int k = 0; k < tmp_n.getChildren().size(); k++)
                            {
                                if(j == k) continue;
                                nrn.addChild(-tmp_n.getChildren().get(k)); //add not Ci
                            }
                            if(tmp_m.getSubDescription() == 0)
                            {
                                tmp_m.setSubDescription(rg.addNode2RuleTree(nrn));
                            } else
                            {
                                if(rg.getNode(tmp_m.getSubDescription()).getNodeType() == NodeType.ntAND)
                                {
                                    rg.getNode(tmp_m.getSubDescription()).addChild(rg.addNode2RuleTree(nrn));
                                } else
                                {
                                    RuleNode and_node = new RuleNode(NodeType.ntAND);
                                    and_node.addChild(rg.addNode2RuleTree(nrn));
                                    and_node.addChild(tmp_m.getSubDescription());                                    
                                    tmp_m.setSubDescription(rg.addNode2RuleTree(and_node));
                                }
                            }
                            removed = true;
                        }
                    }
                }
            }
            if(GCIs.get(i).getSuper() < 0) if(rg.getNode(-GCIs.get(i).getSuper()).getNodeType() == NodeType.ntCONCEPT && !removed)
            {
                RuleNode tmp_m = rg.getNode(-GCIs.get(i).getSuper());
                if(tmp_m.getSubDescription() == 0)
                {
                    tmp_m.setSubDescription(-GCIs.get(i).getSub());
                } else
                {
                    if(rg.getNode(tmp_m.getSubDescription()).getNodeType() == NodeType.ntAND)
                    {
                        rg.getNode(tmp_m.getSubDescription()).addChild(-GCIs.get(i).getSub());
                    } else
                    {
                        RuleNode and_node = new RuleNode(NodeType.ntAND);
                        and_node.addChild(-GCIs.get(i).getSub());
                        and_node.addChild(tmp_m.getSubDescription());                                    
                        tmp_m.setSubDescription(rg.addNode2RuleTree(and_node));
                    }
                }
                removed = true;                
            }
            if(removed)
            {
                GCIs.remove(i);
                i--;
            }
        }
        
        //Just UnComment!
        //part for adding only C [= D where C is atomic negative
        /*for(int i = 0; i < GCIs.size(); i++)
        {
            boolean removed = false;
            if(rg.getNode(GCIs.get(i).getSuper()).getNodeType() == NodeType.ntOR) //this is C [= D1 or D2 or ... or Dn
            {
                RuleNode tmp_n = rg.getNode(GCIs.get(i).getSuper());
                for(int j = 0; j < tmp_n.getChildren().size(); j++)
                {
                    if(tmp_n.getChildren().get(j) > 0)
                    {
                        RuleNode tmp_m = rg.getNode(tmp_n.getChildren().get(j));
                        if(tmp_m.getNodeType() == NodeType.ntCONCEPT) //this is positive concept vertice
                        {
                            RuleNode nrn = new RuleNode(NodeType.ntOR);
                            nrn.addChild(-GCIs.get(i).getSub()); //add not C
                            for(int k = 0; k < tmp_n.getChildren().size(); k++)
                            {
                                if(j == k) continue;
                                nrn.addChild(tmp_n.getChildren().get(k)); //add Di
                            }
                            if(tmp_m.getNegativeDescription() == 0)
                            {
                                tmp_m.setNegativeDescription(rg.addNode2RuleTree(nrn));
                            } else
                            {
                                if(rg.getNode(tmp_m.getNegativeDescription()).getNodeType() == NodeType.ntAND)
                                {
                                    rg.getNode(tmp_m.getNegativeDescription()).addChild(rg.addNode2RuleTree(nrn));
                                } else
                                {
                                    RuleNode and_node = new RuleNode(NodeType.ntAND);
                                    and_node.addChild(rg.addNode2RuleTree(nrn));
                                    and_node.addChild(tmp_m.getNegativeDescription());                                    
                                    tmp_m.setNegativeDescription(rg.addNode2RuleTree(and_node));
                                }
                            }
                            removed = true;                            
                        }
                    }
                }
            }
            
            if(rg.getNode(GCIs.get(i).getSub()).getNodeType() == NodeType.ntAND && !removed) //this is C1 and C2 and ... not Ci ... and Cn [= D
            {
                RuleNode tmp_n = rg.getNode(GCIs.get(i).getSub());                
                for(int j = 0; j < tmp_n.getChildren().size(); j++)
                {
                    if(tmp_n.getChildren().get(j) < 0)
                    {
                        RuleNode tmp_m = rg.getNode(-tmp_n.getChildren().get(j));
                        if(tmp_m.getNodeType() == NodeType.ntCONCEPT) //this is negative concept vertice
                        {
                            RuleNode nrn = new RuleNode(NodeType.ntOR);
                            nrn.addChild(GCIs.get(i).getSuper()); //add D
                            for(int k = 0; k < tmp_n.getChildren().size(); k++)
                            {
                                if(j == k) continue;
                                nrn.addChild(-tmp_n.getChildren().get(k)); //add not Ci
                            }
                            if(tmp_m.getNegativeDescription() == 0)
                            {
                                tmp_m.setNegativeDescription(rg.addNode2RuleTree(nrn));
                            } else
                            {
                                if(rg.getNode(tmp_m.getNegativeDescription()).getNodeType() == NodeType.ntAND)
                                {
                                    rg.getNode(tmp_m.getNegativeDescription()).addChild(rg.addNode2RuleTree(nrn));
                                } else
                                {
                                    RuleNode and_node = new RuleNode(NodeType.ntAND);
                                    and_node.addChild(rg.addNode2RuleTree(nrn));
                                    and_node.addChild(tmp_m.getNegativeDescription());                                    
                                    tmp_m.setNegativeDescription(rg.addNode2RuleTree(and_node));
                                }
                            }
                            removed = true;
                        }
                    }
                }
            }
            if(GCIs.get(i).getSuper() > 0) if(rg.getNode(-GCIs.get(i).getSuper()).getNodeType() == NodeType.ntCONCEPT && !removed)
            {
                RuleNode tmp_m = rg.getNode(GCIs.get(i).getSuper());
                if(tmp_m.getNegativeDescription() == 0)
                {
                    tmp_m.setNegativeDescription(-GCIs.get(i).getSub());
                } else
                {
                    if(rg.getNode(tmp_m.getNegativeDescription()).getNodeType() == NodeType.ntAND)
                    {
                        rg.getNode(tmp_m.getNegativeDescription()).addChild(-GCIs.get(i).getSub());
                    } else
                    {
                        RuleNode and_node = new RuleNode(NodeType.ntAND);
                        and_node.addChild(-GCIs.get(i).getSub());
                        and_node.addChild(tmp_m.getNegativeDescription());                                    
                        tmp_m.setNegativeDescription(rg.addNode2RuleTree(and_node));
                    }
                }
                removed = true;                
            }
            if(removed)
            {
                GCIs.remove(i);
                i--;
            }
        }*/
        RuleNode mc = new RuleNode(NodeType.ntAND);
        for(int i = 0; i < GCIs.size(); i++)
        {
            RuleNode mc1 = new RuleNode(NodeType.ntOR);
            mc1.addChild(-GCIs.get(i).getSub());
            mc1.addChild(GCIs.get(i).getSuper());
            mc.addChild(rg.addNode2RuleTree(mc1));
        }
            
        for(int i = 0; i < EquivalenceAxioms.size(); i++)
        {
            RuleNode emc1 = new RuleNode(NodeType.ntOR);
            emc1.addChild(-EquivalenceAxioms.get(i).getSub());
            emc1.addChild(EquivalenceAxioms.get(i).getSuper());

            RuleNode emc2 = new RuleNode(NodeType.ntOR);
            emc2.addChild(EquivalenceAxioms.get(i).getSub());
            emc2.addChild(-EquivalenceAxioms.get(i).getSuper());
            
            mc.addChild(rg.addNode2RuleTree(emc1));
            mc.addChild(rg.addNode2RuleTree(emc2));
        }

        if(GCIs.size() + EquivalenceAxioms.size() > 0)
            meta_constraint = rg.addNode2RuleTree(mc);            
    }
    
    public void preProcess()
    {
        normalize();
        rg.normalizeGraph();
        absorb();
        rg.makeDAG(); //was maked only for ALC (not N or Q!!!)
        rg.delOnes();
        rg.EqvDescriptionProcess();
        makeOrder();
        
    }
    
    public void showAxioms()
    {
        //Show all equivalences
        for(TwoSidedAxiom it: EquivalenceAxioms)
        {
            rg.showTree(it.getSub(), "");
            System.out.println(" EQV");
            rg.showTree(it.getSuper(), "");
            System.out.println();
        }

        //Show all GCIs
        for(TwoSidedAxiom gci: GCIs)
        {
            rg.showTree(gci.getSub(), "");
            System.out.println(" SUB");
            rg.showTree(gci.getSuper(), "");
            System.out.println();
            System.out.flush();
        }     
    }
    
    public int getMetaConstraint()
    {
        return meta_constraint;
    }
    
    public void showConceptDescription(String concept)
    {
        rg.showTree(rg.getNode(rg.findConcept(concept)).getDescription(), "");
    }
    
    public void showConceptsDescriptions()
    {
        rg.showCD();
    }
    
    Integer[] trans_roles = null;
    public void processTransitive()
    {
        for(int i = 0; i < rg.getNodesCount(); i++)
        {
            if((rg.getNode(i).getNodeType() == NodeType.ntALL || rg.getNode(i).getNodeType() == NodeType.ntSOME) && (r_box.getRoleByIndex(rg.getNode(i).getRoleType()).isTransitive()))
            {
                trans_roles = r_box.getSubAndEqvRoles(rg.getNode(i).getRoleType());
                for(int j = 0; j < trans_roles.length; j++)
                {
                    RuleNode nrn = new RuleNode(rg.getNode(i).getNodeType(), trans_roles[j]);
                    nrn.addChild(rg.getNode(i).getChildren().get(0));
                    int x = rg.addNode2RuleTree(nrn);
                    rg.getNode(i).addTrans(x);
                }
            }
        }
    }
}