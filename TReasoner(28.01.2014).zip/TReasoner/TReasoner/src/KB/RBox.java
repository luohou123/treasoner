/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package KB;

import Automata.Automaton;
import Enums.RoleChar;
import Help.SimpleRole;
import Help.UF;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;

/**
 *
 * @author 1
 */
public class RBox {
    
    private ArrayList<SimpleRole> roles;
    private HashMap<String, Integer> role2int;
    private ArrayList<Automaton> autos;
    
    public RBox()
    {
        roles = new ArrayList<SimpleRole>();
        role2int = new HashMap<String, Integer>();
        autos = new ArrayList<Automaton>();
    }
    
    public int getRoleSize()
    {
        return roles.size();
    }
        
    public SimpleRole getRoleByIndex(int role_index)
    {
        return roles.get(role_index);
    }
    
    public int getIntRole(String role)
    {
        if(role2int.containsKey(role)) return role2int.get(role);
        System.out.println("ERROR: Can't find role: " + role);
        return -1;
    }
    
    public int findRole(OWLObjectPropertyExpression role_expr)
    {
        return findRole(role_expr.asOWLObjectProperty().getIRI().getFragment());
    }
    
    public int findRole(OWLDataPropertyExpression data_role_expr)
    {
        return findRole(data_role_expr.asOWLDataProperty().getIRI().getFragment());
    }
    
    public int findRole(String role_name)
    {
        if(role2int.containsKey(role_name)) return role2int.get(role_name);
        roles.add(new SimpleRole(role_name));
        role2int.put(role_name, roles.size() - 1);
        return roles.size() - 1;
    }
    
    public void setInverseRoles(OWLObjectPropertyExpression role_name1, OWLObjectPropertyExpression role_name2)
    {
        int index_of_role_name1 = findRole(role_name1);
        int index_of_role_name2 = findRole(role_name2);
        roles.get(index_of_role_name1).addInverseRoleIndex(index_of_role_name2);
        //roles.get(index_of_role_name2).addInverseRoleIndex(index_of_role_name1);
    }
    
    public void setRoleCharacteristic(OWLObjectPropertyExpression role_name, RoleChar role_characteristics)
    {
        int index_of_current_role = findRole(role_name);
        roles.get(index_of_current_role).setCharacteristic(role_characteristics);
    }
    
    public void setDataRoleCharacteristic(OWLDataPropertyExpression data_role_name, RoleChar role_characteristics)
    {
        int index_of_current_data_role = findRole(data_role_name);
        roles.get(index_of_current_data_role).setCharacteristic(role_characteristics);
    }
    
    //Subroles
    public void subDataRoles(OWLDataPropertyExpression sub_role, OWLDataPropertyExpression super_role)
    {
        int index = findRole(super_role);
        roles.get(index).getSubRoles().add(findRole(sub_role));
    }
    
    public void subRoles(OWLObjectPropertyExpression sub_role, OWLObjectPropertyExpression super_role)
    {
        int index1 = findRole(super_role);
        int index2 = findRole(sub_role);
        roles.get(index1).getSubRoles().add(index2);
        roles.get(index2).getSuperRoles().add(index1);
    }
    
    //Equivalent roles
    public void eqvRoles(OWLObjectPropertyExpression first_property, OWLObjectPropertyExpression second_property)
    {
        int first_index = findRole(first_property);
        int second_index = findRole(second_property);
        
        roles.get(first_index).getEqvRoles().add(second_index);
        //roles.get(second_index).getEqvRoles().add(first_index);
    }

    public void eqvDataRoles(OWLDataPropertyExpression first_property, OWLDataPropertyExpression second_property)
    {
        int first_index = findRole(first_property);
        int second_index = findRole(second_property);
        
        roles.get(first_index).getEqvRoles().add(second_index);
        //roles.get(second_index).getEqvRoles().add(first_index);
    }
    
    //Role range
    public void setRangeToRole(OWLObjectPropertyExpression role, int range)
    {
        int index = findRole(role);
        roles.get(index).setRange(range);
    }
    
    public void setRangeToDataRole(OWLDataPropertyExpression role, int range)
    {
        int index = findRole(role);
        roles.get(index).setRange(range);
    }
    
    //Role domain
    public void setDomainToRole(OWLObjectPropertyExpression role, int domain)
    {
        int index = findRole(role);
        roles.get(index).setDomain(domain);
    }
    
    public void setDomainToDataRole(OWLDataPropertyExpression role, int domain)
    {
        int index = findRole(role);
        roles.get(index).setDomain(domain);
    }
    
    //Disjoint Roles
    public void addDisjointRole(OWLObjectPropertyExpression first_role, OWLObjectPropertyExpression second_role)
    {
        int index1 = findRole(first_role);
        int index2 = findRole(second_role);
        roles.get(index1).getDsjRoles().add(index2);
        //roles.get(index2).getDsjRoles().add(index1);
    }
    
    public void addDisjointDataRole(OWLDataPropertyExpression first_role, OWLDataPropertyExpression second_role)
    {
        int index1 = findRole(first_role);
        int index2 = findRole(second_role);
        roles.get(index1).getDsjRoles().add(index2);
        //roles.get(index2).getDsjRoles().add(index1);
    }

    /////////////////chain of roles is subsumed by other role///////////////////
    public void addSubChainOf(OWLObjectPropertyExpression role, List<OWLObjectPropertyExpression> chain)
    {
        ArrayList<Integer> temp = new ArrayList<Integer>();
        for(OWLObjectPropertyExpression link: chain)
        {
            temp.add(findRole(link));
        }
        roles.get(findRole(role)).addSubChain(temp);
    }
    ////////////////////////////////////////////////////////////////////////////
    
    public boolean isDisjoint(int role1, int role2)
    {
        if(role1 < 0 || role2 < 0)
        {
            System.out.println("ERROR: Negative role index");
        }
        if(role1 == role2) return false;
        return roles.get(role1).getDsjRoles().contains(role2) || roles.get(role2).getDsjRoles().contains(role1);
    }
    
    ///////////////////////////////
    public boolean hasCommonFuncAllRoles(ArrayList<Integer> ari, int x)
    {
        if(f == null);
            f = new int[roles.size() + 4];
        Arrays.fill(f, 0);
        for(int i = 0; i < ari.size(); i++)
        {
            markRoles(ari.get(i));
        }
        return hasFunc(x);
    }
    
    private void markRoles(int x)
    {
        if(f[x] == 1) return;
        f[x] = 1;
        for(int it: getRoleByIndex(x).getSuperRoles())
        {
            markRoles(it);
        }
    }
    
    private boolean hasFunc(int x)
    {
        if(f[x] == 1 && getRoleByIndex(x).isFunctional()) return true;
        for(int it: getRoleByIndex(x).getSuperRoles())
        {
            if(hasFunc(it)) return true;
        }
        return false;
    }
    
    int f[] = null;
    public boolean hasCommonFuncAnc(int role1, int role2)
    {
        if(f == null);
            f = new int[roles.size() + 4];
        Arrays.fill(f, 0);
        markRoles(role1);
        return hasFunc(role2);
    }
    /////////////////////////////////
    
    public boolean isSubOrEqual(int sub_role, int super_role) //sub or equal role
    {
        return isSub(sub_role, super_role) || isEqual(sub_role, super_role);
    }
    
    public boolean isSub(int sub_role, int super_role)
    {
        return roles.get(super_role).getSubRoles().contains(sub_role);
    }
    
    public boolean isEqual(int sub_role, int super_role)
    {
        return roles.get(super_role).getEqvRoles().contains(sub_role) || sub_role == super_role;
    }
    
    public boolean isSubOrEqualAll(ArrayList<Integer> sub_roles, int super_role)
    {
        for(int i = 0; i < sub_roles.size(); i++)
            if(isSubOrEqual(sub_roles.get(i), super_role)) return true;

        return false;
    }
    
    public boolean isReverseSubOrEqual(int sub_role, int super_role) //sub or equal reverse role
    {
        for(int it: roles.get(sub_role).getInvRoles())
        {
            if (roles.get(UF.ABS(super_role)).getSubRoles().contains(it) || 
                roles.get(UF.ABS(super_role)).getEqvRoles().contains(it) || it == super_role) return true;
        }
        //get all reverse roles of sub_role and check it with super_role on subsumption
        return false;
    }
    
    public boolean isReverseSubOrEqualAll(ArrayList<Integer> sub_roles, int super_role)
    {
        for(int i = 0; i < sub_roles.size(); i++)
            if(isReverseSubOrEqual(sub_roles.get(i), super_role)) return true;

        return false;
    }
    
    public boolean haveDisjoint(ArrayList<Integer> ar1, ArrayList<Integer> ar2)
    {
        for(int i = 0; i < ar1.size(); i++)
            for(int j = 0; j < ar2.size(); j++)
                if(isDisjoint(ar1.get(i), ar2.get(j))) return true;
        return false;
    }
    
    public void showRoles()
    {
    }
    
    public boolean[] is_builded;
    
    public Automaton getAutomaton(int index)
    {
        return autos.get(index);
    }
    
    private void buildAuto(int role_index)
    {
        if(is_builded[role_index])
            return;

        is_builded[role_index] = true;
        for(int i = 0; i < roles.get(role_index).getChains().size(); i++)
        {
            ArrayList<Integer> arr = roles.get(role_index).getChains().get(i);
            for(int j = 0; j < arr.size(); i++)
                buildAuto(arr.get(j));

            autos.get(role_index).addChain(arr, this);
        }
    }
    
    public void buildAllAutos()
    {
        for(int i = 0; i < roles.size(); i++)
            autos.add(new Automaton(i));
        
        is_builded = new boolean[roles.size() + 1];
        Arrays.fill(is_builded, false);
        
        for(int i = 0; i < roles.size(); i++)
            if(!is_builded[i])
            {
                buildAuto(i);
            }

    }
    
    public Integer[] getSubAndEqvRoles(int r)
    {
        Integer[] ret = new Integer[roles.get(r).getSubRoles().size()/* + roles.get(r).getEqvRoles().size()*/];
        roles.get(r).getSubRoles().toArray(ret);
        /*int i = 0;
        for(int it :roles.get(r).getEqvRoles())
        {
            ret[roles.get(r).getSubRoles().size() + i] = it;
            i++;
        }*/
        return ret;
    }
    
}