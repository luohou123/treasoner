/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Interpretation;

import Enums.NodeType;
import Help.DSet;
import Help.Couple;
import Help.UF;
import KB.RBox;
import KB.TBox;
import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author 1
 */
public class InterpretationNode {

    private int StandMaxSize = 4;
    public int origToDoWhen = 0; //переменная которая нужна для того чтобы определить минимальный набор ToDo
    public boolean isDataTypeVertice = false;
    
    private int ChildMaxSize = StandMaxSize;
    private Couple[] children = new Couple[ChildMaxSize];
    private int[] whchild = new int[ChildMaxSize];
    private int ChildSize = 0;
    
    private int ParentMaxSize = StandMaxSize;
    private Couple[] parents = new Couple[ParentMaxSize];
    private int[] whparent = new int[ParentMaxSize];
    private int ParentSize = 0;
    
    int ToDoMaxSize = StandMaxSize;
    private int[] ToDo = new int[ToDoMaxSize];
    private int[] whToDo = new int[ToDoMaxSize];
    private DSet[] ToDoDSet = new DSet[ToDoMaxSize];
    private int ToDoSize = 0;
    
    int MQfdMaxSize = StandMaxSize;
    private int[] MQfd = new int[MQfdMaxSize];
    private int[] whMQfd = new int[MQfdMaxSize];
    private DSet[] MQfdDSet = new DSet[MQfdMaxSize];
    private int MQfdSize = 0;

    int SomeMaxSize = StandMaxSize;
    private int[] Some = new int[SomeMaxSize];
    private int[] whSome = new int[SomeMaxSize];
    private int SomeSize = 0;
        
    int FAllMaxSize = StandMaxSize;
    private int[] FAll = new int[FAllMaxSize];
    private int[] whFAll = new int[FAllMaxSize];
    private int FAllSize = 0;
    
    int IndsMaxSize = StandMaxSize;
    private String[] inds = new String[IndsMaxSize];
    private int[] whInds = new int[IndsMaxSize];
    private int IndsSize = 0;
    
    public boolean toDoPerform = true;
    public int currentToDo = 0;
    public int currentMQfd = 0;
    public int currentFAll = 0;
    public int indexInQueue = 0;
    
    private boolean skip = false; //skip means that this vertice merged to another
    private int block = -1;
    
    private ArrayList<InterpretationNode> toRet = new ArrayList<InterpretationNode>();
    HashSet<InterpretationNode> flag = new HashSet<InterpretationNode>();
    
    HashSet<Integer> toDoSet = new HashSet<Integer>();
    
    public boolean done = false;
    
    public InterpretationNode()
    {
        
    }

    public void clear()
    {
        isDataTypeVertice = false;
        indexInQueue = 0;
        currentToDo = 0;
        currentFAll = 0;
        toDoSet.clear();
        done = false;
        toDoPerform = true;
        skip = false;
        block = -1;
        ParentSize = 0;
        ChildSize = 0;
        ToDoSize = 0;
        MQfdSize = 0;
        SomeSize = 0;
        FAllSize = 0;
        currentMQfd = 0;
        IndsSize = 0;
        
        for(int i = 0; i < ToDoSize; i++)
        {
            whToDo[i] = 0;
            ToDoDSet[i].clear();
            ToDoDSet[i] = null;
        }
        
        for(int i = 0; i < MQfdSize; i++)
        {
            whMQfd[i] = 0;
            MQfdDSet[i] = null;
        }
    }
    
    public int getToDoSize() {
        return ToDoSize;
    }
    
    public int getMQfdSize() {
        return MQfdSize;
    }
    
    public int getSomeSize() {
        return SomeSize;
    }
    
    public int getFAllSize() {
        return FAllSize;
    }
    
    public int getChildSize() {
        return ChildSize;
    }
    
    public int getParentSize() {
        return ParentSize;
    }
    
    public int getIndsSize() {
        return IndsSize;
    }
    
    private void increaseToDo()
    {
        int[] oldToDo = ToDo;
        int[] oldWhToDo = whToDo;
        DSet[] oldToDoDSet = ToDoDSet;
        ToDoMaxSize = (ToDoMaxSize * 3) / 2 + 1; //increase in 1.5
        
        ToDo = new int[ToDoMaxSize];
        whToDo = new int[ToDoMaxSize];
        ToDoDSet = new DSet[ToDoMaxSize];
        
        for(int i = 0; i < ToDoSize; i++)
        {
            ToDo[i] = oldToDo[i];
            whToDo[i] = oldWhToDo[i];
            ToDoDSet[i] = oldToDoDSet[i];
            
            oldToDoDSet[i] = null;
        }
        
        oldToDo = null;
        oldToDoDSet = null;
        oldWhToDo = null;
    }
    
    private void increaseMQfd()
    {
        int[] oldMQfd = MQfd;
        int[] oldWhMqfd = whMQfd;
        DSet[] oldMqfdDSet = MQfdDSet;
        MQfdMaxSize = (MQfdMaxSize * 3) / 2 + 1;
        
        MQfd = new int[MQfdMaxSize];
        whMQfd = new int[MQfdMaxSize];
        MQfdDSet = new DSet[MQfdMaxSize];
        
        for(int i = 0; i < MQfdSize; i++)
        {
            MQfd[i] = oldMQfd[i];
            whMQfd[i] = oldWhMqfd[i];
            MQfdDSet[i] = oldMqfdDSet[i];
        }
    }
    
    private void increaseSome()
    {
        int[] oldSome = Some;
        int[] oldWhSome = whSome;
        SomeMaxSize = (SomeMaxSize * 3) / 2 + 1;
        
        Some = new int[SomeMaxSize];
        whSome = new int[SomeMaxSize];
        
        for(int i = 0; i < SomeSize; i++)
        {
            Some[i] = oldSome[i];
            whSome[i] = oldWhSome[i];
        }
    }

    private void increaseFAll()
    {
        int[] oldFAll = FAll;
        int[] oldWhFAll = whFAll;
        FAllMaxSize = (FAllMaxSize * 3) / 2 + 1;
        
        FAll = new int[FAllMaxSize];
        whFAll = new int[FAllMaxSize];
        
        for(int i = 0; i < FAllSize; i++)
        {
            FAll[i] = oldFAll[i];
            whFAll[i] = oldWhFAll[i];
        }
        
        oldFAll = null;
        oldWhFAll = null;
    }
    
    private void increaseChild()
    {
        Couple[] oldChildren = children;
        int[] oldWhChild = whchild;
        ChildMaxSize = (ChildMaxSize * 3) / 2 + 1;
        
        children = new Couple[ChildMaxSize];
        whchild = new int[ChildMaxSize];
        
        for(int i = 0; i < ChildSize; i++)
        {
            children[i] = oldChildren[i];
            whchild[i] = oldWhChild[i];
            oldChildren[i] = null;
        }
        oldChildren = null;
        oldWhChild = null;
    }
    
    private void increaseParent()
    {
        Couple[] oldParents = parents;
        int[] oldWhParents = whparent;
        ParentMaxSize = (ParentMaxSize * 3) / 2 + 1;
        
        parents = new Couple[ParentMaxSize];
        whparent = new int[ParentMaxSize];
        
        for(int i = 0; i < ParentSize; i++)
        {
            parents[i] = oldParents[i];
            whparent[i] = oldWhParents[i];
            oldParents[i] = null;
        }
        oldParents = null;
        oldWhParents = null;
    }
    
    private void increaseInds()
    {
        String[] oldInds = inds;
        int[] oldWhInds = whInds;
        IndsMaxSize = (IndsMaxSize * 3) / 2 + 1;
        
        inds = new String[IndsMaxSize];
        whInds = new int[IndsMaxSize];
        for(int i = 0; i < IndsSize; i++)
        {
            inds[i] = oldInds[i];
            whInds[i] = oldWhInds[i];
        }
    }
    
    public void restore(boolean toDoPerf, int when, int _curToDo, int _curMQfd, int _curFAll, boolean isDTV)
    {
        toDoPerform = toDoPerf;
        
        currentToDo = _curToDo;
        currentFAll = _curFAll;
        currentMQfd = _curMQfd;
        isDataTypeVertice = isDTV;
        
        while(ParentSize > 0 && whparent[ParentSize - 1] >= when) ParentSize--;
        
        while(ChildSize > 0 && whchild[ChildSize - 1] >= when) ChildSize--;

        while(ToDoSize > 0 && whToDo[ToDoSize - 1] >= when)
        {
            ToDoSize--;
            toDoSet.remove(ToDo[ToDoSize]);
            ToDoDSet[ToDoSize] = null;
        }
        
        //restore To Do List
        int curSize = 0;
        int[] oldToDo = new int[ToDoMaxSize];
        int[] oldWhToDo = new int[ToDoMaxSize];
        DSet[] oldToDoDSet = new DSet[ToDoMaxSize];
        for(int i = 0; i < ToDoSize; i++)
        {
            if(whToDo[i] < when)
            {
                oldToDo[curSize] = ToDo[i];
                oldWhToDo[curSize] = whToDo[i];
                oldToDoDSet[curSize] = ToDoDSet[i];
                curSize++;
            } else
            {
                toDoSet.remove(ToDo[i]);
                ToDoDSet[i] = null;
            }
        }
        ToDoSize = curSize;
        ToDo = oldToDo;
        whToDo = oldWhToDo;
        ToDoDSet = oldToDoDSet;
         
        while(SomeSize > 0 && whSome[SomeSize - 1] >= when) SomeSize--;

        while(FAllSize > 0 && whFAll[FAllSize - 1] >= when) FAllSize--;
        
        while(MQfdSize > 0 && whMQfd[MQfdSize - 1] >= when) MQfdSize--;
                
        while(IndsSize > 0 && whInds[IndsSize - 1] >= when) IndsSize--;

    }
    
    private ArrayList<String> ids = new ArrayList<String>();
    public ArrayList<String> getRemovedIndivids(int when)
    {
        ids.clear();
        for(int i = IndsSize - 1; i >= 0; i--)
        {
            if(whInds[i] >= when)
                ids.add(inds[i]);
        }
        return ids;
    }
    
    public void addChild(InterpretationNode child, int role, int when)
    {
        if(child.indexInQueue < 0)
        {
            int kor = 123;
        }
        if(ChildSize == ChildMaxSize - 1)
        {
            increaseChild();
        }
        
        boolean added = false;
        for(int i = 0; i < ChildSize; i++)
        {
            if(children[i].getNode() == child)
                if(children[i].getRoles().contains(role)) return; else
                {
                    children[i].getRoles().add(role);
                    added = true; break;
                }
        }
        
        if(!added)
        {
            children[ChildSize] = new Couple(child, role);
            whchild[ChildSize] = when;
            ChildSize++;
        }
    }
    
    public void updateParents(int role, int when, RBox r_box) //if there is some parent with transitive role - add it
    {
        if(r_box.getRoleByIndex(role).isTransitive())
        {
            for(int i = 0; i < ParentSize; i++)
            {
                if(!r_box.isSubOrEqualAll(parents[i].getRoles(), role)) continue;
                for(int k = 0; k < parents[i].getNode().getParentSize(); k++)
                {
                    Couple pr = parents[i].getNode().getParents()[k];
                    for(int j = 0; j < pr.getRoles().size(); j++)
                    {
                        if(r_box.isSubOrEqual(pr.getRoles().get(j), role))
                        {
                            addParent(pr.getNode(), role, when, r_box);
                            pr.getNode().addChild(this, role, when);
                        }
                    }
                }
            }
        }
    }
    
    public void addParent(InterpretationNode parent, int role, int when, RBox r_box)
    {
        if(ParentSize == ParentMaxSize - 1)
        {
            increaseParent();
        }
        
        boolean added = false;
        for(int i = 0; i < ParentSize; i++)
        {
            if(parents[i].getNode() == parent)
            {
                if(parents[i].getRoles().contains(role))
                {
                    return;
                } else
                {
                    parents[i].getRoles().add(role);
                    added = true; break;
                }
            }
        }
        
        if(!added)
        {
            parents[ParentSize] = new Couple(parent, role);
            whparent[ParentSize] = when;
            ParentSize++;
        }
        
        //updateParents(role, when, r_box);
        
    }

    public int getNeighboursCount(int role, int concept, RBox r_box, InterpretationNode n1, InterpretationNode n2) //uses only for canMerge procedure
    {
        int ans = 0;
        boolean isn1 = false, isn2 = false; //need to check whether n1 and n2 both are neighbours
        for(int i = 0; i < ChildSize; i++)
        {
            if(children[i].getNode().isSkipped()) continue;
            if(r_box.isSubOrEqualAll(children[i].getRoles(), role))
                if(children[i].getNode().isContain(concept) || concept == 1)
                {
                    if(children[i].getNode().indexInQueue == n1.indexInQueue)
                    {
                        isn1 = true;
                    }
                    if(children[i].getNode().indexInQueue == n2.indexInQueue)
                    {
                        isn2 = true;
                    }
                    ans++;
                }
        }
        
        for(int i = 0; i < ParentSize; i++)
        {
            if(parents[i].getNode().isSkipped()) continue;
            if(r_box.isReverseSubOrEqualAll(parents[i].getRoles(), role))
                if(parents[i].getNode().isContain(concept) || concept == 1)
                {
                    if(parents[i].getNode().indexInQueue == n1.indexInQueue)
                    {
                        isn1 = true;
                    }
                    if(parents[i].getNode().indexInQueue == n2.indexInQueue)
                    {
                        isn2 = true;
                    }
                    ans++;
                }
        }
        if(isn1 && isn2) //if n1 and n2 both are neighbours then count of its decreases by 1
        {
            ans--;
        }
        return ans;
    }
        
    public ArrayList<InterpretationNode> getNeighboursByRole(int role, RBox r_box)
    {
        toRet = new ArrayList<InterpretationNode>();
        for(int i = 0; i < ChildSize; i++)
        {
            if(children[i].getNode().isSkipped()) continue;
            for(int j = 0; j < children[i].getRoles().size(); j++)
            {
                if(r_box.isSubOrEqual(children[i].getRoles().get(j), role))
                {
                    if(!toRet.contains(children[i].getNode()))
                    {
                        toRet.add(children[i].getNode());
                    }
                }
            }
        }
        
        for(int i = 0; i < ParentSize; i++)
        {
            if(parents[i].getNode().isSkipped()) continue;
            for(int j = 0; j < parents[i].getRoles().size(); j++)
            {
                if(r_box.isReverseSubOrEqual(parents[i].getRoles().get(j), role))
                {
                    if(!toRet.contains(parents[i].getNode()))
                    {
                        toRet.add(parents[i].getNode());
                    }
                }
            }
        }
        
        return toRet;
    }
    
    public int findInToDo(int x)
    {
        for(int i = 0; i < ToDoSize; i++)
            if(ToDo[i] == x) return i;
        return -1;
    }
    
    public boolean isConflict(int toDoEntry)
    {
        return isContain(-toDoEntry);
    }
    
    public DSet getConflictDSet(int concept_id)
    {
        for(int i = 0; i < ToDoSize; i++)
            if(concept_id == -ToDo[i]) return ToDoDSet[i];
        return null;
    }
    
    public boolean isContain(int toDoEntry)
    {
        boolean contains = false;
        for(int i = 0; i < ToDoSize; i++)
            if(ToDo[i] == toDoEntry)
            {
                contains = true;
                break;
            }
        return contains;
        //return toDoSet.contains(toDoEntry);
    }
    
    public boolean addIndivid(String abn, int when)
    {
        for(int i = 0; i < IndsSize; i++)
        {
            if(abn.equals(inds[i])) return false;
        }

        if(IndsSize == IndsMaxSize - 1)
        {
            increaseInds();
        }
        
        inds[IndsSize] = abn;
        whInds[IndsSize] = when;
        IndsSize++;
        return true;
    }
    
    public Couple[] getChildren()
    {
        return children;
    }
    
    public Couple[] getParents()
    {
        return parents;
    }
    
    public void setBlock(int new_block)
    {
        block = new_block;
    }
    
    public int getBlock()
    {
        return block;
    }
    
    public boolean isBlocked()
    {
        return block == 1;
    }
    
    public void setSkip(boolean new_skip)
    {
        skip = new_skip;
    }
    
    public boolean isSkipped() //seems this means that this vertice merged to another
    {
        return skip;
    }
    
    public int[] getToDo()
    {
        return ToDo;
    }
    
    public DSet[] getToDoDSet()
    {
        return ToDoDSet;
    }
    
    public int[] getToDoWhen()
    {
        return whToDo;
    }
    
    public DSet getDSet(int concept_id)
    {
        for(int i = 0; i < ToDoSize; i++)
        {
            if(concept_id == ToDo[i]) return ToDoDSet[i];
        }
        return null;
    }
    
    public DSet[] getMxQfDSet()
    {
        return MQfdDSet;
    }
    
    public String[] getInds()
    {
        return inds;
    }
    
    public void popToDo()
    {
        if(ToDoSize > 0) ToDoSize--;
    }
    
    public boolean addToDo(Integer new_to_do, DSet d, int when, TBox t_box)
    {
        if(new_to_do == 1) return false; // if new_to_do is TOP
        if(isContain(new_to_do)) return false;
        if(ToDoSize == ToDoMaxSize - 1)
        {
            increaseToDo();
        }
        
        toDoPerform = true;
        toDoSet.add(new_to_do);
        ToDo[ToDoSize] = new_to_do;
        ToDoDSet[ToDoSize] = d;
        whToDo[ToDoSize] = when;
        ToDoSize++;
        return true;
    }
    
    public boolean addToDoPos(int new_to_do, DSet d, int when, int pos) //return true only iff new_to_do was added to the toDoList
    {
        //addToDo(new_to_do, d, when); if(true) return true;
        if(new_to_do == 1) return false; // if new_to_do is TOP
        if(isContain(new_to_do)) return false;
        if(ToDoSize == ToDoMaxSize - 1)
        {
            increaseToDo();
        }
        
        for(int i = ToDoSize; i > pos; i--)
        {
            int h = ToDo[i];            
            ToDo[i] = ToDo[i - 1];
            ToDo[i - 1] = h;
            
            h = whToDo[i];            
            whToDo[i] = whToDo[i - 1];
            whToDo[i - 1] = h;
            
            DSet dh = ToDoDSet[i];
            ToDoDSet[i] = ToDoDSet[i - 1];
            ToDoDSet[i - 1] = dh;
        }
        toDoSet.add(new_to_do);        
        ToDo[pos] = new_to_do;
        ToDoDSet[pos] = d;
        whToDo[pos] = when;
        
        ToDoSize++;
        return true;
    }
    
    public int[] getFAll()
    {
        return FAll;
    }
    
    public void addFAll(int new_to_do, int when)
    {
        if(FAllSize == FAllMaxSize - 1)
        {
            increaseFAll();
        }
        FAll[FAllSize] = new_to_do;
        whFAll[FAllSize] = when;
        FAllSize++;
    }
        
    public int[] getMQfd()
    {
        return MQfd;
    }
    
    public void addMQfd(int new_to_do, DSet d, int when)
    {
        if(MQfdSize == MQfdMaxSize - 1) increaseMQfd();
        MQfd[MQfdSize] = new_to_do;
        MQfdDSet[MQfdSize] = d;
        whMQfd[MQfdSize] = when;
        MQfdSize++;
    }
    
    public void addIncr(int new_to_do, int when)
    {
        if(SomeSize == SomeMaxSize - 1)
        {
            increaseSome();
        }
        Some[SomeSize] = new_to_do;
        whSome[SomeSize] = when;
        SomeSize++;
    }
    
    public int[] getIncr()
    {
        return Some;
    }
    
    public void delete()
    {
        for(Couple it: parents)
            it.getNode().deleteChild(this);
        for(Couple it: children)
            it.getNode().deleteParent(this);
    }
    
    public void deleteChild(InterpretationNode child)
    {
        int index = -1;
        for(int i = 0; i < ChildSize; i++)
            if(children[i].getNode().equals(child)) index = i;

        if(index == -1)
            System.out.printf("Can not find the child!");
        else
        {
            ChildSize--;
        }
    }
    
    public void deleteParent(InterpretationNode parent)
    {
        int index = -1;
        for(int i = 0; i < ParentSize; i++)
            if(parents[i].getNode().equals(parent)) index = i;

        if(index == -1)
            System.out.printf("Can not find the parent!");
        else
        {
            ParentSize--;
        }
    }
    
    public void DownTree(InterpretationNode node, String spaces, RBox r_box, TBox t_box, int gl)
    {
        if(node.skip)
        {
            System.out.println("SKIPPED!");
        }
        
        System.out.print(spaces);
        for(int i = 0; i < node.getToDoSize(); i++)
        {
            System.out.print(node.getToDo()[i] + " ");
        }
        System.out.println();
        
        System.out.println(spaces + node.indexInQueue);
        System.out.print(spaces);
        for(int i = 0; i < node.getIndsSize(); i++)
        {
            System.out.print(node.getInds()[i] + " ");
        }
        System.out.println();
        for(int i = 0; i < node.getToDoSize(); i++)
        {
            int it = node.getToDo()[i];
            if(t_box.getRuleGraph().getNode(UF.ABS(it)).getChildren().size() > 0)
            {
                int chld = t_box.getRuleGraph().getNode(UF.ABS(it)).getChildren().get(0);
                if(t_box.getRuleGraph().getNode(UF.ABS(chld)).getName() != null)
                {
                    if(t_box.getRuleGraph().getNode(UF.ABS(chld)).getName().indexOf("Cycle") != -1)
                    {
                        //System.out.println(spaces + "CYCLE: " + it + " " + r_box.getRoleByIndex(t_box.getRuleGraph().getNode(UF.ABS(it)).getRoleType()).getName());
                        int kor = 123;
                    }
                }
            }
            if(t_box.getRuleGraph().getNode(UF.ABS(it)).getNodeType() != NodeType.ntCONCEPT) continue;
            if(it < 0)
            {
                System.out.println(spaces + "NOT " + t_box.getRuleGraph().getNode(UF.ABS(it)).getName());
            } else
            {
                System.out.println(spaces + t_box.getRuleGraph().getNode(UF.ABS(it)).getName());
            }
            //System.out.print(" ");
            //System.out.print(node.getToDoDSet()[i].size());
            //System.out.println();
        }
        flag.add(node);
        for(int i = 0; i < node.getChildSize(); i++)
        {
            if(node.getChildren()[i].getNode().isSkipped()) continue;
            System.out.print(spaces);
            for(int j = 0; j < node.getChildren()[i].getRoles().size(); j++)
                System.out.println(r_box.getRoleByIndex(node.getChildren()[i].getRoles().get(j)).getName());
             
            if(!flag.contains(node.getChildren()[i].getNode()))
            {
                DownTree(node.getChildren()[i].getNode(), spaces + " ", r_box, t_box, gl);
            } else
            {
                System.out.println(spaces + " " + node.getChildren()[i].getNode().indexInQueue);
            }
        }
    }
    
    private boolean DFS(InterpretationNode x)
    {
        if(x.getChildSize() == 0)
        {
            return x.done;
        }
        for(int i = 0; i < x.getChildSize(); i++)
        {
            if(!DFS(x.getChildren()[i].getNode())) return false;
        }
        return x.done;
    }
    
    public boolean isDone()
    {
        return DFS(this);
    }
    
    public void showToDo(TBox t_box)
    {
        System.out.print(" ");
        for(int i = 0; i < getToDoSize(); i++)
        {
            System.out.print(getToDo()[i]);
            System.out.print(" ");
        }
        System.out.println();
    }
    
    public void show(RBox r_box, TBox t_box)
    {
        System.out.println();
        flag.clear();
        DownTree(this, "", r_box, t_box, 0);
        System.out.println();
    }
}