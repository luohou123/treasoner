/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Interpretation;

import Help.Couple;
import KB.RBox;
import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author 1
 */
public class Interpretation {
    
    private RBox r_box = null;
    private ArrayList<InterpretationNode> roots = new ArrayList<InterpretationNode>();
    
    public Interpretation(RBox new_r_box)
    {
        r_box = new_r_box;
    }
    
    public void setRBox(RBox new_r_box)
    {
        r_box = new_r_box;
    }
        
    public InterpretationNode addNode(InterpretationNode parent_node, InterpretationNode new_node, int role, int when)
    {
        if(parent_node == null)
        {
            roots.add(new_node);
        } else
        {
            new_node.addParent(parent_node, role, when, r_box);
            new_node.updateParents(role, when, r_box);
            for(int it: r_box.getRoleByIndex(role).getEqvRoles()) //add all equivalent roles
            {
                new_node.getParents()[new_node.getParentSize() - 1].getRoles().add(it);
            }
            
            if(r_box.getRoleByIndex(role).isTransitive())
            {
                for(int i = 0; i < parent_node.getParentSize(); i++)
                    for(int j = 0; j < parent_node.getParents()[i].getRoles().size(); j++)
                        if(r_box.isSubOrEqual(role, parent_node.getParents()[i].getRoles().get(j)))
                        {
                            new_node.addParent(parent_node.getParents()[i].getNode(), role, when, r_box);
                            new_node.updateParents(role, when, r_box);
                            parent_node.getParents()[i].getNode().addChild(new_node, role, when);
                        }
            }

            parent_node.addChild(new_node, role, when);
        }
        return new_node;
    }
    
    public ArrayList<InterpretationNode> getRoots()
    {
        return roots;
    }
        
    public boolean deleteNode(InterpretationNode current_node)
    {
        return true;
    }
    
    private boolean blocking(InterpretationNode super_a_node, InterpretationNode sub_a_node)
    {
        for(int i = 0; i < sub_a_node.getToDoSize(); i++)
            if(!super_a_node.isContain(sub_a_node.getToDo()[i]))
            {
                return false;
            }

        for(int i = 0; i < sub_a_node.getIndsSize(); i++)
        {
            boolean same_found = false;
            for(int j = 0; j < super_a_node.getIndsSize(); j++)
            {
                if(super_a_node.getInds()[j].equals(sub_a_node.getInds()[i]))
                {
                    same_found = true;
                    break;
                }
            }
            if(!same_found) return false;
        }
        
        return true;
    }
    
    private boolean isDone(InterpretationNode node)
    {
        if(!(node.currentToDo >= node.getToDoSize() && node.currentMQfd >= node.getMQfdSize()))
        {
            return false;
        }
        /*for(int i = 0; i < node.getParentSize(); i++)
        {
            if(!(node.getParents()[i].getNode().currentToDo >= node.getParents()[i].getNode().getToDoSize() && 
                 node.getParents()[i].getNode().currentMQfd >= node.getParents()[i].getNode().getMQfdSize()))
            {
                return false;
            }
        }*/
        return true;
    }
    
    private boolean generalBlocking(InterpretationNode super_node, InterpretationNode sub_node)
    {
        //if(!isDone(super_node)) return false;
        if(!blocking(super_node, sub_node)) return false;
        //    else return true;
        
        for(int i = 0; i < super_node.getParentSize(); i++)
            for(int j = 0; j < sub_node.getParentSize(); j++)
                if(blocking(super_node.getParents()[i].getNode(), sub_node.getParents()[j].getNode()))
                {
                    if(super_node.getParents()[i].getRoles().containsAll(sub_node.getParents()[j].getRoles()))
                        return true;
                }

        return false;
    }

    HashSet<InterpretationNode> flag = new HashSet<InterpretationNode>();
    private boolean upToTree(InterpretationNode current_node, InterpretationNode check_node)
    {
        if(generalBlocking(current_node, check_node)) return true;
        flag.add(current_node);
        for(int i = 0; i < current_node.getParentSize(); i++)
        {
            Couple it = current_node.getParents()[i];
            if(!flag.contains(it.getNode()))
                if(upToTree(it.getNode(), check_node)) return true;
        }

        return false;
    }
    
    public boolean makeBlocked(InterpretationNode current_node, InterpretationNode[] Q, int QS)
    {
        if(current_node.getBlock() == 1) return current_node.isBlocked();
        //if(current_node.getBlock() != -1) return current_node.isBlocked();
        flag.clear();
        flag.add(current_node);
        
        for(int i = 0; i < QS; i++)
        {
            if(generalBlocking(Q[i], current_node)) return true;
        }
        
        /*for(int i = 0; i < current_node.getParentSize(); i++)
        {
            Couple it = current_node.getParents()[i];
            if(upToTree(it.getNode(), current_node))
            {
                current_node.setBlock(1);
                for(int j = 0; j < current_node.getChildSize(); j++)
                {
                    Couple jt = current_node.getChildren()[j];
                    jt.getNode().setSkip(true);
                }
                return true;
            }
        }*/
        
        current_node.setBlock(0);
        return false;
    }
    
    public void unBlock(InterpretationNode current_node)
    {
        current_node.setBlock(-1);
        current_node.setSkip(false);
        for(int i = 0; i < current_node.getChildSize(); i++)
        {
            current_node.getChildren()[i].getNode().setSkip(false);
        }
    }
 
}
