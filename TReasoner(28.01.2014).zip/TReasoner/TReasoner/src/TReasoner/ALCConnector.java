/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TReasoner;

import KB.ABox;
import KB.RBox;
import KB.TBox;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author 1
 */
public class ALCConnector {
    
    private TBox t_box;
    private RBox r_box;
    private ABox a_box;
    
    public ALCConnector(String string_filename, int how_many) throws FileNotFoundException
    {
        a_box = new ABox();
        r_box = new RBox();
        t_box = new TBox(r_box);
        
        t_box.setRBox(r_box);
        int concept_count = 0;
        String concept_string = "";
        
        Scanner S = new Scanner(new File(string_filename));
        System.out.print("LOADING FILES: ");
        while(S.hasNextLine())
        {
            String s = S.nextLine();
            if(s.charAt(0) == ';')
            {
                if(concept_string.length() == 0) continue;
                System.out.print(concept_count + 1);
                System.out.print(" ");
                
                int sub = t_box.getRuleGraph().addExpr2Graph("MyConcept" + (concept_count + 1));
                int sup = t_box.getRuleGraph().addExpr2Graph(concept_string);
                t_box.addEquivalenceAxiom(sub, sup);
                
                concept_string = "";
                concept_count++;
                if(how_many > 0)
                    if(concept_count == how_many) break;
                continue;
            }
            
            for(int i = 0; i < s.length(); i++)
            {
                concept_string += s.charAt(i);
            }
        }
        
        if(concept_string.length() > 0)
        {
            System.out.println(concept_count + 1);
            int sub = t_box.getRuleGraph().addExpr2Graph("MyConcept" + (concept_count + 1));
            int sup = t_box.getRuleGraph().addExpr2Graph(concept_string);
            t_box.addEquivalenceAxiom(sub, sup);
            concept_string = "";
            concept_count++;
        } else
        {
            System.out.println();
        }
    }
    
    public TBox getTBox()
    {
        return t_box;
    }
    
    public RBox getRBox()
    {
        return r_box;
    }
    
    public ABox getABox()
    {
        return a_box;
    }    
        
}
