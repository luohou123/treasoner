/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TReasoner;

import Enums.RoleChar;
import KB.ABox;
import KB.RBox;
import KB.TBox;
import java.io.File;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAnnotationAssertionAxiom;
import org.semanticweb.owlapi.model.OWLAnnotationPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLAnnotationPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLAsymmetricObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLAxiomVisitor;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassAssertionAxiom;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLDataPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLDataPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLDatatypeDefinitionAxiom;
import org.semanticweb.owlapi.model.OWLDeclarationAxiom;
import org.semanticweb.owlapi.model.OWLDifferentIndividualsAxiom;
import org.semanticweb.owlapi.model.OWLDisjointClassesAxiom;
import org.semanticweb.owlapi.model.OWLDisjointDataPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLDisjointObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLDisjointUnionAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentClassesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentDataPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLEquivalentObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLFunctionalDataPropertyAxiom;
import org.semanticweb.owlapi.model.OWLFunctionalObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLHasKeyAxiom;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLInverseFunctionalObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLInverseObjectPropertiesAxiom;
import org.semanticweb.owlapi.model.OWLIrreflexiveObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLLogicalAxiom;
import org.semanticweb.owlapi.model.OWLNegativeDataPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLNegativeObjectPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyAssertionAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyDomainAxiom;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.model.OWLObjectPropertyRangeAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLReflexiveObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLSameIndividualAxiom;
import org.semanticweb.owlapi.model.OWLSubAnnotationPropertyOfAxiom;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.model.OWLSubDataPropertyOfAxiom;
import org.semanticweb.owlapi.model.OWLSubObjectPropertyOfAxiom;
import org.semanticweb.owlapi.model.OWLSubPropertyChainOfAxiom;
import org.semanticweb.owlapi.model.OWLSymmetricObjectPropertyAxiom;
import org.semanticweb.owlapi.model.OWLTransitiveObjectPropertyAxiom;
import org.semanticweb.owlapi.model.SWRLRule;

/**
 *
 * @author 1
 */

public class OWLConnector {
    
    private OWLOntology Ontology;
    private AxiomTransformer axiom_transformer;
    
    public OWLConnector(String RES)
    {
        try {
            OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
            //manager.loadOntologyFromOntologyDocument(new File(RES));
            IRI iri = IRI.create(RES);
            Ontology = manager.loadOntologyFromOntologyDocument(iri);
            axiom_transformer = new AxiomTransformer();
        } catch (OWLOntologyCreationException ex) {
            Logger.getLogger(OWLConnector.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public OWLConnector(String FileName, int x)
    {
        try {
            OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
            Ontology = manager.loadOntologyFromOntologyDocument(new File(FileName));
            axiom_transformer = new AxiomTransformer();
        } catch (OWLException ex) {
            Logger.getLogger(OWLConnector.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String getLogicString()
    {
        String ret = "";
        if(axiom_transformer.bl_S) ret += "S";
        if(axiom_transformer.bl_R) ret += "R"; else 
            if(axiom_transformer.bl_H) ret += "H";
        if(axiom_transformer.bl_I) ret += "I";
        if(axiom_transformer.bl_F) ret += "F";
        return ret;
    }
    
    private void processAxioms()
    {
        Set<OWLClass> soc = Ontology.getClassesInSignature();
        for(OWLClass cl: soc)
        {
            if(cl.isOWLThing() || cl.isOWLNothing()) continue;
            axiom_transformer.getTBox().getRuleGraph().findConcept(cl.getIRI().toString());
        }
        Set<OWLLogicalAxiom> set_of_LogicalAxioms = Ontology.getLogicalAxioms();
        for(OWLLogicalAxiom logical_axiom: set_of_LogicalAxioms)
        {
            logical_axiom.accept(axiom_transformer);
        }
    }
    
    public TBox getTBox()
    {
        processAxioms();
        axiom_transformer.getTBox().processTransitive();
        return axiom_transformer.getTBox();
    }

    public ABox getABox()
    {
        return axiom_transformer.getABox();
    }
    
    public RBox getRBox()
    {
        return axiom_transformer.getRBox();
    }

    private class AxiomTransformer implements OWLAxiomVisitor
    {
        private TBox t_box;
        private RBox r_box;
        private ABox a_box;
        
        public boolean bl_F = false;
        public boolean bl_S = false;
        public boolean bl_R = false;
        public boolean bl_H = false;
        public boolean bl_I = false;
        
        public AxiomTransformer()
        {
            a_box = new ABox();
            r_box = new RBox();
            t_box = new TBox(r_box);
            
            t_box.setRBox(r_box);
        }
        
        public TBox getTBox()
        {
            return t_box;
        }
        
        public ABox getABox()
        {
            return a_box;
        }
        
        public RBox getRBox()
        {
            return r_box;
        }
        
        @Override
        public void visit(OWLDeclarationAxiom owlda) {
            //skip
        }

        @Override
        public void visit(OWLSubClassOfAxiom owlsc) {
            if(owlsc.getSuperClass().isOWLThing())
            {
                int sub = t_box.getRuleGraph().addExpr2Graph(owlsc.getSubClass());
                t_box.addGCI(sub, 1);
                return;
            }
            if(owlsc.getSubClass().isOWLNothing())
            {
                int sub = t_box.getRuleGraph().addExpr2Graph(owlsc.getSubClass());
                t_box.addGCI(sub, -1);
                return;
            }
            
            int sub = t_box.getRuleGraph().addExpr2Graph(owlsc.getSubClass());
            int sup = t_box.getRuleGraph().addExpr2Graph(owlsc.getSuperClass());
            t_box.addGCI(sub, sup);
        }

        @Override
        public void visit(OWLNegativeObjectPropertyAssertionAxiom owlnp) {
            //a_box.addRole(owlnp.getProperty(), owlnp.getSubject(), owlnp.getObject(), 1);            
        }

        @Override
        public void visit(OWLAsymmetricObjectPropertyAxiom owlp) {
            r_box.setRoleCharacteristic(owlp.getProperty().asOWLObjectProperty(), RoleChar.drASYMM);          
        }

        @Override
        public void visit(OWLReflexiveObjectPropertyAxiom owlrp) {
            r_box.setRoleCharacteristic(owlrp.getProperty().asOWLObjectProperty(), RoleChar.drREF);            
        }

        @Override
        public void visit(OWLDisjointClassesAxiom owldca) {
            for(OWLSubClassOfAxiom cur_axiom : owldca.asOWLSubClassOfAxioms())
                cur_axiom.accept(this);
        }

        @Override
        public void visit(OWLDataPropertyDomainAxiom owldpd) {
            int cur = t_box.getRuleGraph().addExpr2Graph(owldpd.getDomain());
            r_box.setDomainToDataRole(owldpd.getProperty(), cur);
        }

        @Override
        public void visit(OWLObjectPropertyDomainAxiom owlpd) {
            int cur = t_box.getRuleGraph().addExpr2Graph(owlpd.getDomain());
            r_box.setDomainToRole(owlpd.getProperty(), cur);
        }

        @Override
        public void visit(OWLEquivalentObjectPropertiesAxiom owlp) {
            for(OWLObjectPropertyExpression first_iterator: owlp.getProperties())
            {
                for(OWLObjectPropertyExpression second_iterator: owlp.getProperties())
                {
                    if(first_iterator == second_iterator) continue;
                    r_box.eqvRoles(first_iterator, second_iterator);
                }
            }
        }

        @Override
        public void visit(OWLNegativeDataPropertyAssertionAxiom owlndp) {
            //a_box.addDataRole(owlndp.getProperty(), owlndp.getSubject(), owlndp.getObject(), 1);            
        }

        @Override
        public void visit(OWLDifferentIndividualsAxiom owldia) {
            for(OWLIndividual individ1: owldia.getIndividualsAsList())
            {
                for(OWLIndividual individ2: owldia.getIndividualsAsList())
                {
                        if(individ1 == individ2) continue;
                        //a_box.addDiff(individ1, individ2);
                }
            }
        }

        @Override
        public void visit(OWLDisjointDataPropertiesAxiom owldp) {
            for(OWLDataPropertyExpression expr1: owldp.getProperties())
                for(OWLDataPropertyExpression expr2: owldp.getProperties())
                {
                    if(expr1 == expr2) continue;
                    r_box.addDisjointDataRole(expr1, expr2);
                }                
        }

        @Override
        public void visit(OWLDisjointObjectPropertiesAxiom owldp) {
            for(OWLObjectPropertyExpression expr1: owldp.getProperties())
                for(OWLObjectPropertyExpression expr2: owldp.getProperties())
                {
                    if(expr1 == expr2) continue;
                    r_box.addDisjointRole(expr1, expr2);
                }                
        }

        @Override
        public void visit(OWLObjectPropertyRangeAxiom owlpr) {
            int cur = t_box.getRuleGraph().addExpr2Graph(owlpr.getRange());
            r_box.setRangeToRole(owlpr.getProperty(), cur);
        }

        @Override
        public void visit(OWLObjectPropertyAssertionAxiom owlp) {
            a_box.addRelation(owlp.getSubject(), owlp.getObject(), r_box.findRole(owlp.getProperty()));
        }

        @Override
        public void visit(OWLFunctionalObjectPropertyAxiom owlfp) {
            r_box.setRoleCharacteristic(owlfp.getProperty(), RoleChar.drFUNC);       
            bl_F = true;
        }

        @Override
        public void visit(OWLSubObjectPropertyOfAxiom owlsp) {
            r_box.subRoles(owlsp.getSubProperty(), owlsp.getSuperProperty());
            bl_H = true;
        }

        @Override
        public void visit(OWLDisjointUnionAxiom owldua) {
            owldua.getOWLDisjointClassesAxiom().accept(this);
            owldua.getOWLEquivalentClassesAxiom().accept(this);
        }

        @Override
        public void visit(OWLSymmetricObjectPropertyAxiom owlsp) {
            r_box.setRoleCharacteristic(owlsp.getProperty(), RoleChar.drSYMM);       
        }

        @Override
        public void visit(OWLDataPropertyRangeAxiom owldpr) {
            int cur = t_box.getRuleGraph().addDataExpr2Graph(owldpr.getRange());
            r_box.setRangeToDataRole(owldpr.getProperty(), cur);
        }

        @Override
        public void visit(OWLFunctionalDataPropertyAxiom owlfdp) {
            r_box.setDataRoleCharacteristic(owlfdp.getProperty(), RoleChar.drFUNC);
            bl_F = true;
        }

        @Override
        public void visit(OWLEquivalentDataPropertiesAxiom owldp) {
            for(OWLDataPropertyExpression first_iterator: owldp.getProperties())
            {
                for(OWLDataPropertyExpression second_iterator: owldp.getProperties())
                {
                    if(first_iterator == second_iterator) continue;
                    r_box.eqvDataRoles(first_iterator, second_iterator);
                }
            }
        }

        @Override
        public void visit(OWLClassAssertionAxiom owlcaa) {
            int x = t_box.getRuleGraph().addExpr2Graph(owlcaa.getClassExpression());
            int y = t_box.getRuleGraph().findIndivid(owlcaa.getIndividual());
            a_box.add(owlcaa.getIndividual(), x);
            a_box.add(owlcaa.getIndividual(), y);
        }

        @Override
        public void visit(OWLEquivalentClassesAxiom owleca) {
            int left_operand = 0;
            int right_operand = 0;
                            
            Set<OWLClassExpression> set_of_owleca = owleca.getClassExpressions();
            int k = 1;
            for(OWLClassExpression axiom: set_of_owleca)
            {
                k = 1 - k;
                if(k == 1)
                {
                    right_operand = t_box.getRuleGraph().addExpr2Graph(axiom);
                    if(right_operand > 0)
                    {
                        if(t_box.getRuleGraph().getNode(right_operand).getName() != null)
                        {
                            t_box.addEquivalenceAxiom(right_operand, left_operand);
                            if(left_operand > 0)
                                if(t_box.getRuleGraph().getNode(left_operand).getName() != null)
                                {
                                    t_box.addEquivalenceAxiom(left_operand, right_operand);
                                    //t_box.addGCI(left_operand, right_operand);
                                    //t_box.addGCI(right_operand, left_operand);
                                }
                        } else
                        {
                            t_box.addEquivalenceAxiom(left_operand, right_operand);
                            //t_box.addGCI(left_operand, right_operand);
                            //t_box.addGCI(right_operand, left_operand);
                        }
                    } else
                    {
                        t_box.addEquivalenceAxiom(left_operand, right_operand);                            
                        //t_box.addGCI(left_operand, right_operand);
                        //t_box.addGCI(right_operand, left_operand);
                    }
                } else
                {
                    left_operand = t_box.getRuleGraph().addExpr2Graph(axiom);
                }
            }
        }

        @Override
        public void visit(OWLDataPropertyAssertionAxiom owldp) {
            //a_box.addDataRole(owldp.getProperty(), owldp.getSubject(), owldp.getObject(), 0);
        }

        @Override
        public void visit(OWLTransitiveObjectPropertyAxiom owltp) {
            r_box.setRoleCharacteristic(owltp.getProperty(), RoleChar.drTRANS);       
            bl_S = true;
        }

        @Override
        public void visit(OWLIrreflexiveObjectPropertyAxiom owlp) {
            r_box.setRoleCharacteristic(owlp.getProperty(), RoleChar.drIRREF);       
        }

        @Override
        public void visit(OWLSubDataPropertyOfAxiom owlsdp) {
            r_box.subDataRoles(owlsdp.getSubProperty(), owlsdp.getSuperProperty());
        }

        @Override
        public void visit(OWLInverseFunctionalObjectPropertyAxiom owlfp) {
            r_box.setRoleCharacteristic(owlfp.getProperty(), RoleChar.drINVFUNC);       
        }

        @Override
        public void visit(OWLSameIndividualAxiom owlsia) {
            for(OWLIndividual individ1: owlsia.getIndividualsAsList())
            {
                for(OWLIndividual individ2: owlsia.getIndividualsAsList())
                {
                        if(individ1 == individ2) continue;
                        //a_box.addSame(individ1, individ2);
                }
            }
        }

        @Override
        public void visit(OWLSubPropertyChainOfAxiom owlspc) {
            r_box.addSubChainOf(owlspc.getSuperProperty(), owlspc.getPropertyChain());
            bl_R = true;
        }

        @Override
        public void visit(OWLInverseObjectPropertiesAxiom owlp) {
            r_box.setInverseRoles(owlp.getFirstProperty(), owlp.getSecondProperty());
            bl_I = true;
        }

        @Override
        public void visit(OWLHasKeyAxiom owlhka) {
            //unsupported yet
        }

        @Override
        public void visit(OWLDatatypeDefinitionAxiom owldda) {
            //r_box.findRole();
        }

        @Override
        public void visit(SWRLRule swrlr) {
            //skip
        }

        @Override
        public void visit(OWLAnnotationAssertionAxiom owlaaa) {            
            //skip
        }

        @Override
        public void visit(OWLSubAnnotationPropertyOfAxiom owlsp) {
            //skip
        }

        @Override
        public void visit(OWLAnnotationPropertyDomainAxiom owlpd) {
            //skip
        }

        @Override
        public void visit(OWLAnnotationPropertyRangeAxiom owlpr) {
            //skip
        }   
    }
}
