/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TReasoner;

import Help.UF;
import KB.ABox;
import KB.RBox;
import KB.TBox;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

/**
 *
 * @author 1
 */
public class TKBConnector {
    
    private int N = 0;
    private char[] a = new char[1024 * 1024 * 8];
    
    private TBox[] t_boxes = new TBox[32];
    private RBox[] r_boxes = new RBox[32];
    private ABox[] a_boxes = new ABox[32];
    
    ABox a_box = null;
    RBox r_box = null;
    TBox t_box = null;
    
    int tBoxCount = 0;

    private char[] buf = new char[1024 * 1024 * 8];
    
    public TKBConnector(String string_filename) throws FileNotFoundException, IOException
    {
        Reader R = new FileReader(string_filename);
        R.read(buf);
        
        int C = 0;
        while(buf[C] != 0) C++;
        
        boolean hasOneTBox = false;
        boolean isComment = false;
        int skcnt = 0;
        for(int i = 0; i < C; i ++)
        {
            if(buf[i] == ';')
            {
                isComment = true;
                continue;
            }
            if(buf[i] == '\n') isComment = false;
            if(isComment) continue;
            if(buf[i] == '(') skcnt++;
            if(skcnt == 2) 
            {
                hasOneTBox = false; break;
            }
            if(UF.isSkippedSymbol(buf[i]) || buf[i] == '(') continue;
            hasOneTBox = true; break;
        }
        
        if(hasOneTBox)
        {
            buf[C] = ')'; C++;
            for(int i = C; i > 0; i--)
            {
                buf[i] = buf[i - 1];
            }
            buf[0] = '(';
            C++;
        }
        
        int l = 0;
        while(buf[l] != '(') l++;
        
        int balance = 0;
        //System.out.print("LOADED: ");
        for(int i = l; i < C; i++)
        {
            if(buf[i] == '(') balance++;
            if(buf[i] == ')') balance--;
            a[N++] = buf[i];
            if(balance == 0 && N > 0)
            {
                //System.out.print(tBoxCount + 1 + " ");
                //System.out.flush();
                a_box = new ABox();
                r_box = new RBox();
                t_box = new TBox(r_box);
                processAxioms();
                t_boxes[tBoxCount] = t_box;
                a_boxes[tBoxCount] = a_box;
                r_boxes[tBoxCount] = r_box;
                tBoxCount++;
                N = 0;
                while(buf[i] != '(')
                {
                    i++; if(i >= C) break;
                } 
                i--;
            }
        }
        //System.out.println();
    }
    
    public TBox getTBox(int x)
    {
        return t_boxes[x];
    }
    
    public RBox getRBox(int x)
    {
        return r_boxes[x];
    }
    
    public ABox getABox(int x)
    {
        return a_boxes[x];
    }
    
    public TBox[] getTBoxes()
    {
        return t_boxes;
    }
    
    public RBox[] getRBoxes()
    {
        return r_boxes;
    }
    
    public ABox[] getABoxes()
    {
        return a_boxes;
    }
    
    public int getTBoxesCount()
    {
        return tBoxCount;
    }
    
    public void processAxioms()
    {
        a_box = new ABox();
        r_box = new RBox();
        t_box = new TBox(r_box);
        t_box.setRBox(r_box);
        
        int i = 0;
        
        while(a[i] != '(') i++; i++;
        while(a[N - 1] != ')' && N > 0) N--; N--;

        for(; i < N; i++)
        {
            int l = i;
            while((a[l] != '(') && l < N) l++;
            
            int r = l + 1;
            int balance = 1;
            while(balance > 0 && r < N)
            {
                if(a[r] == ')') balance--;
                if(a[r] == '(') balance++;
                r++;
            }
            
            processString(l + 1, r - 1);
            
            i = r;
        }
    }
    
    public void processString(int l, int r)
    {
        String token = "";
        for(int i = l; i < r; i++)
        {
            if(a[i] == ' ')
            {
                l = i + 1;
                break;
            } else
            {
                token += a[i];
            }
            l = i + 1;
        }
        
        String concept_name = "";
        while(a[l] == ' ') l++;
        
        for(int i = l; i < r; i++)
        {
            if(a[i] == ' ')
            {
                l = i + 1;
                break;
            } else
            {
                concept_name += a[i];
            }
            l = i + 1;
        }
        
        String desc = "";
        for(int i = l; i < r; i++)
            desc += a[i];
        
        if(token.equalsIgnoreCase("define-concept"))
        {
            if(desc.length() > 0)
            {
                int sub = t_box.getRuleGraph().addExpr2Graph(concept_name);
                int sup = t_box.getRuleGraph().addExpr2Graph(desc);
                t_box.addEquivalenceAxiom(sub, sup);
            } else
            {
                t_box.getRuleGraph().findConcept(concept_name);
            }
        } else
        if(token.equalsIgnoreCase("define-primitive-concept"))
        {
            if(desc.length() > 0)
            {
                int sub = t_box.getRuleGraph().addExpr2Graph(concept_name);
                int sup = t_box.getRuleGraph().addExpr2Graph(desc);
                t_box.addGCI(sub, sup);
            } else
            {
                t_box.getRuleGraph().findConcept(concept_name);
            }
        } else
        if(token.equalsIgnoreCase("define-disjoint-primitive-concept"))
        {
            if(desc.length() > 0)
            {
                //System.out.println("!" + concept_name + "! !" + desc + "!");
                int sub = t_box.getRuleGraph().addExpr2Graph(concept_name);
                
                String disj = ""; 
                int bal = 0, it;
                for(it = 0; it < desc.length(); it++)
                    if(!UF.isSkippedSymbol(desc.charAt(it))) break;

                for(; it < desc.length(); it++)
                {
                    if(desc.charAt(it) == '(') bal++;
                    if(desc.charAt(it) == ')') bal--;
                    disj += desc.charAt(it);
                    if(bal == 0) break;
                }
                desc = desc.substring(it + 1, desc.length());
                
                //System.out.println("!" + concept_name + "! !" + disj + "! !" + desc + "!");
                int sup = t_box.getRuleGraph().addExpr2Graph(desc);
                t_box.addGCI(sub, sup);
            } else
            {
                t_box.getRuleGraph().findConcept(concept_name);
            }
        } else
        if(token.equalsIgnoreCase("define-primitive-role"))
        {
            r_box.findRole(concept_name);
            //System.out.println("!" + concept_name + "! !" + desc + "!");
        } else
        if(token.equalsIgnoreCase("define-role"))
        {
            r_box.findRole(concept_name);
            //System.out.println("!" + concept_name + "! !" + desc + "!");
        } else
        {
            //System.out.println(token);
        }
        
    }
    
}