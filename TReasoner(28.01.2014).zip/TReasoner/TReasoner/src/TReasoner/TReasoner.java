/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TReasoner;

import Checker.SatChecker;
import Help.Automorphism;
import KB.ABox;
import KB.Query;
import KB.RBox;
import KB.TBox;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
/**
 *
 * @author 1
 */

public class TReasoner {

    /**
     * @param args the command line arguments
     */
    
    private SatChecker s_checker = null;
    
    private TBox t_box = null;
    private RBox r_box = null;
    private ABox a_box = null;
    private Query query = null;
    
    private TBox[] t_boxes = null;
    private RBox[] r_boxes = null;
    private ABox[] a_boxes = null;
    private int tBoxesCount = 0;
    
    private long timeLimit = 0;
    
    
    private void loadFromAKB(String file_name) throws FileNotFoundException
    {
        t_box = null; a_box = null; r_box = null;
        AKBConnector akb_connect = new AKBConnector(file_name);
        t_box = akb_connect.getTBox();
        r_box = akb_connect.getRBox();
        a_box = akb_connect.getABox();
        query = akb_connect.getQuery();
        t_box.preProcess();
    }
    
    private void loadFromTKB(String file_name) throws FileNotFoundException, IOException
    {
        t_box = null; a_box = null; r_box = null;
        TKBConnector tkb_connect = new TKBConnector(file_name);
        t_boxes = tkb_connect.getTBoxes();
        r_boxes = tkb_connect.getRBoxes();
        a_boxes = tkb_connect.getABoxes();
        tBoxesCount = tkb_connect.getTBoxesCount();
        for(int i = 0; i < tBoxesCount; i++)
        {
            t_boxes[i].preProcess();
        }
    }

    private void loadFromALC(String file_name, int how_many) throws FileNotFoundException
    {
        t_box = null; a_box = null; r_box = null;
        ALCConnector alc_connect = new ALCConnector(file_name, how_many);
        t_box = alc_connect.getTBox();
        r_box = alc_connect.getRBox();
        a_box = alc_connect.getABox();
        t_box.preProcess();
    }
    
    private void loadFromOWL(String file_name)
    {
        t_box = null; a_box = null; r_box = null;
        OWLConnector owl_connect = new OWLConnector(file_name, 1);
        t_box = owl_connect.getTBox();
        r_box = owl_connect.getRBox();
        a_box = owl_connect.getABox();
        t_box.preProcess();
        System.out.println("CONCEPTS: " + t_box.getRuleGraph().getConcepts().size() + " \nROLES: " + r_box.getRoleSize() + " \nINDIVIDS: " + a_box.getCount());
        //System.out.println(owl_connect.getLogicString() + "" + t_box.getRuleGraph().getLogicString());
    }
    
    public void loadKB(String path, String kbType, int howMany, boolean uA, boolean uB, boolean uC, boolean uS, boolean uG, long tL) throws FileNotFoundException, IOException
    {
        timeLimit = tL;
        if(s_checker == null)
            s_checker = new SatChecker(null, r_box, t_box, a_box, uA, uB, uC, uG, uS, tL);
        else
        {
            s_checker.clear();
        }
        if(kbType.equals("ALC"))
        {
            loadFromALC(path, howMany);
            s_checker.setABox(a_box);
            s_checker.setTBox(t_box);
            s_checker.setRBox(r_box);
        }
        if(kbType.equals("TKB"))
        {
            loadFromTKB(path);
        }
        if(kbType.equals("AKB"))
        {
            loadFromAKB(path);
            s_checker.setABox(a_box);
            s_checker.setTBox(t_box);
            s_checker.setRBox(r_box);
        }
    }
    
    public void classifyTBoxes(boolean cohr) throws FileNotFoundException, OWLOntologyCreationException, OWLOntologyStorageException
    {
        int cur_tb = 0;
        int real_size = cur_tb + 1;
        real_size = 21;
        for(int i = cur_tb; (i < tBoxesCount) && (i < real_size); i++)
        {
            long time1 = System.currentTimeMillis();
            s_checker.clear();
            s_checker.setABox(a_boxes[i]);
            s_checker.setTBox(t_boxes[i]);
            s_checker.setRBox(r_boxes[i]);
            if(tBoxesCount > 1)
            {
                System.out.print("TBOX #" + i + " ");
                if(isSat("TEST") != cohr)
                {
                    System.out.println("ERROR!");
                } else
                {
                    System.out.println("IT IS ALL RIGHT!");                    
                }
            }

            if(s_checker.classifyTBox(false, null, timeLimit) == null) break;
            //System.out.println("TOTAL TIME: " + (System.currentTimeMillis() - time1) / 1000.0);
        }
    }
    
    public TReasoner()
    {
        s_checker = null;
    }
    
    public void loadOntology(String path, boolean uA, boolean uB, boolean uC, boolean uS, boolean uG, int tL)
    {
        timeLimit = tL;
        if(s_checker == null)
            s_checker = new SatChecker(null, r_box, t_box, a_box, uA, uB, uC, uG, uS, tL);
        else
            s_checker.clear();

        loadFromOWL(path);
        s_checker.setABox(a_box);
        s_checker.setTBox(t_box);
        s_checker.setRBox(r_box);
    }
    
    public void checkQuery() throws FileNotFoundException, OWLOntologyCreationException, OWLOntologyStorageException
    {
        s_checker.classifyTBox(false, null, timeLimit);
        s_checker.checkQuery(query);
    }
    
    public boolean isSat(String concept_name)
    {
        //t_box.showConceptDescription(conceptName);
        Automorphism aut = new Automorphism(t_box.getRuleGraph());
        int ds = t_box.getRuleGraph().getNode(t_box.getRuleGraph().findConcept(concept_name)).getDescription();
        //aut.labelTree(ds);
        //s_checker.clear();
        if(!s_checker.checkABoxSat(true))
        {
            return false;
        }
        return s_checker.checkSat(concept_name, false, 2, 0);
    }
    
    public void checkALCTBox()
    {
        if(s_checker == null)
            s_checker = new SatChecker(null, r_box, t_box, a_box, true, true, true, true, false, 7000);
        s_checker.checkALCTBoxSat(false, true);
    }
    
    public boolean isConsistent()
    {
        return s_checker.checkABoxSat(true);
    }
    
    public Set<OWLSubClassOfAxiom> classifyOntology(String outfile_path) throws FileNotFoundException, OWLOntologyCreationException, OWLOntologyStorageException
    {
        IRI fil = null; if(outfile_path != null) fil = IRI.create(new File(outfile_path));
        //boolean res = s_checker.checkSat("http://galen.org/galen.owl#Anonymous-93", true, 2, 0);
        //return null;
        //boolean res = s_checker.checkSubsumption("http://cohse.semanticweb.org/ontologies/people#haulagetruckdriver", "http://cohse.semanticweb.org/ontologies/people#driver");
        //boolean res = s_checker.checkSat("http://modelosenegocios.goodglecode.com/svn/trunk/tp3/tp3.owl#TipoFilaAcuerdo", true, 0, 0);
        //System.out.println(res);
        //return null;
        return s_checker.classifyTBox(false, fil, timeLimit);
    }
    
    public void howMany(String inputFile) throws FileNotFoundException
    {
        String prefix = "C:\\Users\\1\\Downloads\\ORE 2013\\ore2013-ontologies-offline\\owlxml\\dl\\";
        File f = new File(inputFile);
        Scanner s = new Scanner(f);
        while(s.hasNext())
        {
            String fn = prefix + s.next();
            File ff = new File(fn);
            if(!ff.exists())
            {
                System.out.println("-"); continue;
            }
            //System.out.println(fn);
            TReasoner t1 = new TReasoner();
            t1.loadFromOWL(fn);
        }
    }
    
    public static void main(String[] args) throws FileNotFoundException, IOException, OWLOntologyCreationException, OWLOntologyStorageException
    {
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_branch_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_d4_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_dum_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_grz_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_lin_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_path_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_ph_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_poly_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_t4p_n.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_branch_p.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_d4_p.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_dum_p.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_grz_p.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_lin_p.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_path_p.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_ph_p.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_poly_p.owl";
        //String fil = "C:\\Users\\1\\Downloads\\DL98\\Data\\T98-sat(owl)\\k_t4p_p.owl";
        //loadOntology(fil, true, true, true, true, false, 7000);
        TReasoner t = new TReasoner();
        String onname = "";
        //onname = "http___protege.stanford.edu_plugins_owl_owl-library_not-galen.owl.txt";
        
        //SOMETHING WRONG: MAX QUALIFIED RULE
        //onname = "dl\\37e5e889-ad29-4d2f-a2e3-106e70a1a3c3_iduals.owl";
        //String conc_name = "http://semanticscience.org/rkb:RKB_000012";
        
        ArrayList<String> totest_files = new ArrayList<String>();
        totest_files.clear();
        totest_files.add("0cd30725-3ae5-4c41-820f-c6a16240e802_-OKB_2.owl");
        totest_files.add("71134246-639b-4ed8-aff8-2261cb41cd4e_tp3.owl");
        totest_files.add("8f298886-1bb7-41b6-810b-ec036ad75fee_2Fchemical");
        totest_files.add("2f4b30e8-2c85-4028-a1d4-1dfb08067dcc_l%2Ffalcon");
        totest_files.add("5657edcf-cec9-4492-a8dd-cfe2d4f5f0d9_owl%2Fcoma");
        totest_files.add("51e460e9-619a-4683-b9ad-ec261e4bf06d_7-0342.owl");
        totest_files.add("8a74f1e5-2162-435f-a7a5-4258d2571681_ndPets.owl");
        totest_files.add("578811f0-41fd-4e88-a580-0cd6fe989d6c_1615.owl");
        totest_files.add("60fb4605-bf17-45a4-9d3f-8e70a871c013_dation.owl");
        totest_files.add("fa1ae516-9f0b-42f1-a66a-708d5a9cf9a0_ets-v1.owl");
        totest_files.add("844f7541-1f1f-4004-ae32-42e5cae21f4a_people.owl");
        totest_files.add("b815b896-e04c-4571-8ce8-e4b25aedcbec_e+petsA.n3");
        totest_files.add("fc156d3b-a0e6-4a8b-9424-79aa5025bed7_people.owl");
        totest_files.add("777a6585-c41f-44bb-b6ca-079c83c1bde3_BpetsA.owl");
        totest_files.add("b7b018d1-0a8b-493e-b506-652630277b51_people.owl");
        totest_files.add("240a6af0-3a59-41b6-afe6-b00648b43315__inst1.owl");
        totest_files.add("00118.owl");
        totest_files.add("1a068e20-c239-47a1-b9dc-40ddbf73b6ec_iesAmI.rdf");
        totest_files.add("a5ac64cb-3d75-48e2-8106-b05277c9e16e_lscale.owl");
        totest_files.add("72db2148-edfc-4c63-a142-52d2a0eb0b9b_inst15.owl");
        totest_files.add("bc1af316-cb50-42ff-9e9d-ea8f309ea42c_people");
        totest_files.add("ca3f25c3-c60d-4bf3-b691-3282c541bf39_people.owl");
        totest_files.add("6126d1bf-ffc8-4a6f-ad9d-b8173f4d99db_ePizza.owl");
        totest_files.add("2182c976-12bd-41ef-9665-0a471049e6f7_e+pets.rdf");
        totest_files.add("00a1118a-5420-46f0-b4b2-a2585165b28a_ePizza.owl");
        totest_files.add("ed702658-c8e0-48bb-af79-34c625fb8039_tology.owl");
        totest_files.add("7dacb73c-7366-4099-aba0-16dac9dda108_pizza.owl");
        totest_files.add("ca9585af-418b-4bdd-9432-2a3aaf49678b_Pizza.owl");
        totest_files.add("95a2df41-085b-41ef-998e-9dc32bd75a30_pizza.owl");
        totest_files.add("26ffd334-3398-4054-993b-f8e22411435c_pizza.owl");
        totest_files.add("bleeding-history-phenotype.1116.owl.xml");
        totest_files.add("6a2afaf6-ea7f-4ce2-936b-62b283e589a8_lscale.owl");
        totest_files.add("2edc955f-295c-4b59-9554-c8ac744c4a54_p-core.owl");
        
        String prefix = "D:\\ORE 2013\\ore2013-ontologies-offline\\owlxml\\dl\\";
        String pstfix = "D:\\ORE 2013\\ans\\";
        
        for(int i = 0; i < totest_files.size(); i++)
        {
            onname = totest_files.get(i);
            System.out.println(prefix + onname);
            t.loadOntology(prefix + onname, true, true, true, false, false, 900000);
            //t.howMany("C:\\Users\\1\\Downloads\\ORE 2013\\ontos_DL2.txt");
            //long ttt = System.currentTimeMillis();
            //System.out.println("STARTED");
            //String conc_name = "http://purl.org/obo/owl/GO#GO_0034573";
            t.classifyOntology(pstfix + onname + "_ans.owl");
            //boolean res = t.isSat(conc_name);
            //System.out.println(res + ": " + (System.currentTimeMillis() - ttt));
        }
    }
}