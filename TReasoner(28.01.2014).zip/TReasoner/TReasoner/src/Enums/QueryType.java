/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Enums;

/**
 *
 * @author 1
 */
public enum QueryType {
    qtConceptSub, qtRoleSub, qtIndividInst, qtIndividRel, qtIndividEq, qtIndividNotEq;
}
