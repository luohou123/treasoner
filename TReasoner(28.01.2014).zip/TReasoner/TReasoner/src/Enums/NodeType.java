/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Enums;

/**
 *
 * @author 1
 */
public enum NodeType {
    ntAND, ntNOT, ntOR, ntALL, ntSOME, ntMINCARD, ntMAXCARD, ntEXTCARD, ntCONCEPT, ntHASSELF, ntTHING, ntNOTHING, ntUNDEF, ntINDIVID, ntDATATYPE, ntLITER;
}
