/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Enums;

/**
 *
 * @author 1
 */
public enum RoleChar {
    drFUNC, drINVFUNC, drTRANS, drSYMM, drASYMM, drREF, drIRREF;
}
