/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Checker;

import Enums.NodeType;
import Help.IntArray;
import Help.UF;
import KB.TBox;
import RuleGraph.RuleNode;
import org.semanticweb.owlapi.model.OWLDatatype;

/**
 *
 * @author Boris
 */
public class DataChecker {
    
    IntArray clause = new IntArray();
    String error_string = "";
    TBox t_box = null;
    
    public DataChecker(TBox t_box)
    {
    }
    
    public void clear()
    {
        t_box = null;
    }
    
    public void setTBox(TBox new_t_box)
    {
        t_box = new_t_box;
    }
    
    static public boolean isNumber(OWLDatatype d)
    {
        return  d.isDouble() || d.isFloat() || d.isInteger() || 
                d.getIRI().toString().equals("http://www.w3.org/2001/XMLSchema#nonNegativeInteger") ||
                d.getIRI().toString().equals("http://www.w3.org/2001/XMLSchema#positiveInteger") ||
                d.getIRI().toString().equals("http://www.w3.org/2001/XMLSchema#long") ||
                d.getIRI().toString().equals("http://www.w3.org/2001/XMLSchema#int") || 
                d.getIRI().toString().equals("http://www.w3.org/2001/XMLSchema#gYear");
    }
    
    static public boolean isString(OWLDatatype d)
    {
        return d.isString() || d.getIRI().toString().equals("http://www.w3.org/2001/XMLSchema#anyURI");
    }
    
    static public boolean isDatatime(OWLDatatype d)
    {
        return d.getIRI().getFragment().equalsIgnoreCase("dateTime");
    }
    
    static public boolean isBoolean(OWLDatatype d)
    {
        return d.isBoolean();
    }
    
    public boolean isUnknown(OWLDatatype d)
    {
        return !isString(d) && !isNumber(d) && !isDatatime(d) && ! isBoolean(d) && !d.isRDFPlainLiteral() && !d.isTopDatatype();
    }
    
    public boolean checkString(IntArray cl, TBox t_box)
    {
        boolean primitive = true;
        for(int i = 0; i < cl.size(); i++)
        {
            RuleNode rn = t_box.getRuleGraph().getNode(UF.ABS(cl.get(i)));
            if(rn.getFacet() != null || rn.getLiter() != null)
            {
                primitive = false; break;
            }
            if(rn.getDatatype() != null && rn.getLiter() != null)
            {
                if(!rn.getDatatype().getBuiltInDatatype().equals(rn.getLiter().getDatatype()))
                {
                    return false;
                }
            }
        }
        if(!primitive)
        {
            //check different liters
            for(int i = 0; i < cl.size(); i++)
            {
                if(t_box.getRuleGraph().getNode(cl.get(i)).getLiter() == null) continue;
                for(int j = 0; j < cl.size(); j++)
                {
                    if(t_box.getRuleGraph().getNode(cl.get(j)).getLiter() == null) continue;
                    String l1 = t_box.getRuleGraph().getNode(cl.get(i)).getLiter().getLiteral();
                    String l2 = t_box.getRuleGraph().getNode(cl.get(j)).getLiter().getLiteral();
                    if(!l1.equalsIgnoreCase(l2))
                    {
                        return false;
                    }
                }
            }
            //check different datatypes
            for(int i = 0; i < cl.size(); i++)
            {
                OWLDatatype dt1 = null;
                if(t_box.getRuleGraph().getNode(cl.get(i)).getLiter() != null)
                    dt1 = t_box.getRuleGraph().getNode(cl.get(i)).getLiter().getDatatype();
                if(dt1 == null)
                    dt1 = t_box.getRuleGraph().getNode(cl.get(i)).getDatatype().asOWLDatatype();
                if(dt1 == null) continue;
                if(dt1.isTopDatatype()) continue;
                for(int j = 0; j < cl.size(); j++)
                {
                    OWLDatatype dt2 = null;
                    if(t_box.getRuleGraph().getNode(cl.get(j)).getLiter() != null)
                        dt2 = t_box.getRuleGraph().getNode(cl.get(j)).getLiter().getDatatype();
                    if(dt1 == null)
                        dt2 = t_box.getRuleGraph().getNode(cl.get(j)).getDatatype().asOWLDatatype();
                    if(dt2 == null) continue;
                    if(dt2.isTopDatatype()) continue;
                    if(!dt1.equals(dt2)) 
                    {
                        return false;
                    }
                }
            }
        } else
        {
            return true;
        }
        return true;
    }
    
    static public boolean checkNumber(IntArray cl, TBox t_box)
    {
        boolean primitive = true;
        for(int i = 0; i < cl.size(); i++)
        {
            RuleNode rn = t_box.getRuleGraph().getNode(UF.ABS(cl.get(i)));
            if(rn.getFacet() != null && rn.getLiter() != null)
            {
                primitive = false; break;
            }
        }
        if(!primitive)
        {
            System.out.println("ERROR: unsupported procedure");
        } else
        {
            return true;
        }
        return false;
    }
    
    static public boolean checkDatetime(IntArray cl, TBox t_box)
    {
        boolean primitive = true;
        for(int i = 0; i < cl.size(); i++)
        {
            RuleNode rn = t_box.getRuleGraph().getNode(UF.ABS(cl.get(i)));
            if(rn.getFacet() != null && rn.getLiter() != null)
            {
                primitive = false; break;
            }
        }
        if(!primitive)
        {
            System.out.println("ERROR: unsupported procedure");
        } else
        {
            return true;
        }
        return false;
    }    
    
    private boolean checkClause()
    {
        int iS = 0, iN = 0, iD = 0, iB = 0;
        int inS = 0, inN = 0, inD = 0, inB = 0;
        for(int i = 0; i < clause.size(); i++)
        {
            for(int j = i + 1; j < clause.size(); j++)
            {
                if(clause.get(i) == -clause.get(j)) return false;
            }
        }
        for(int i = 0; i < clause.size(); i++)
        {
            if(clause.get(i) == 1)
            {
                continue;
            }
            if(t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getDatatype() == null)
            {
                //System.out.println(t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getNodeType() + " " + t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getName());
                return true;
            }
            if(isString(t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getDatatype()))
            {
                if(clause.get(i) != -1)
                    iS = 1; else
                    inS = 1;
            } else
            if(isNumber(t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getDatatype()))
            {
                if(clause.get(i) != -1)
                    iN = 1; else
                    inN = 1;
            } else
            if(isDatatime(t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getDatatype()))
            {
                if(clause.get(i) != -1)
                    iD = 1; else
                    inD = 1;
            } else
            if(isBoolean(t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getDatatype()))
            {
                if(clause.get(i) != -1)
                    iB = 1; else
                    inB = 1;
            }
            
            if(isUnknown(t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getDatatype()))
            {
                System.out.println(t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getDatatype().toStringID());
                OWLDatatype d = t_box.getRuleGraph().getNode(UF.ABS(clause.get(i))).getDatatype();
                error_string = "UnsupportedDatatype";
            }
        }
        if( (iS + iN + iD + iB > 1) || (iS == 1 && inS == 1) || (iB == 1 && inB == 1) ||
            (iN == 1 && inN == 1) || (iD == 1 && inD == 1))
        {
            return false;
        }
        
        if(iS == 1) //this is string clause
        {
            return checkString(clause, t_box);
        }
        
        if(iN == 1) //this is number clause
        {
            return checkNumber(clause, t_box);
        }
        
        if(iD == 1) //this is datatime clause
        {
            return checkDatetime(clause, t_box);
        }
        return true;
    }
    
    public boolean getDataCheck(IntArray data)
    {
        clause.clear();
        return doAllClauses(data, 0);
    }
    
    public boolean doAllClauses(IntArray data, int x)
    {
        //if(true) return true;
        for(int i = x; i < data.size(); i++)
        {
            if(     (data.get(i) > 0 && t_box.getRuleGraph().getNode(UF.ABS(data.get(i))).getNodeType() == NodeType.ntOR) || 
                    (data.get(i) < 0 && t_box.getRuleGraph().getNode(UF.ABS(data.get(i))).getNodeType() == NodeType.ntAND))
            {
                int z = 1;
                if(data.get(i) < 0) z = -1;                
                for(int j = 0; j < t_box.getRuleGraph().getNode(UF.ABS(data.get(i))).getChildren().size(); j++)
                {
                    int clause_old_size = clause.size();
                    int data_old_size = data.size();
                    data.add(z * t_box.getRuleGraph().getNode(UF.ABS(data.get(i))).getChildren().get(j));
                    if(doAllClauses(data, i + 1)) return true;
                    while(clause.size() != clause_old_size) clause.pop();
                    while(data.size() != data_old_size) data.pop();
                }
                return false;
            } else
            if(     (data.get(i) < 0 && t_box.getRuleGraph().getNode(UF.ABS(data.get(i))).getNodeType() == NodeType.ntOR) || 
                    (data.get(i) > 0 && t_box.getRuleGraph().getNode(UF.ABS(data.get(i))).getNodeType() == NodeType.ntAND))                
            {
                int z = 1;
                if(data.get(i) < 0) z = -1;
                for(int j = 0; j < t_box.getRuleGraph().getNode(UF.ABS(data.get(i))).getChildren().size(); j++)
                    data.add(z * t_box.getRuleGraph().getNode(UF.ABS(data.get(i))).getChildren().get(j));
            } else
            {
                clause.add(data.get(i));
            }
        }
        return checkClause();
    }
    
    public String getError()
    {
        return error_string;
    }
        
}
