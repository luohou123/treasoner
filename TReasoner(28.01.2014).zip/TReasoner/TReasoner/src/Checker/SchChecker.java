/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Checker;

import Enums.NodeType;
import Help.UF;
import Help.depend;
import KB.TBox;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;

/**
 *
 * @author Boris
 */
public class SchChecker {
    
    private class HashS
    {
        private class HashE
        {
            public HashE next;
            public int hf1, hf2, n;
            public HashE(int _hf1, int _hf2, int _n)
            {
                hf1 = _hf1;
                hf2 = _hf2;
                n = _n;
                next = null;
            }
        }

        final int hC1 = 107;
        final int hC2 = 1051;
        final int hSize = (1 << 12);
        private HashE[] table = new HashE[hSize];
        final int hModul = (1 << 21);
    
        public HashS()
        {
            
        }
        
        public boolean add(int[] a)
        {
            int n = a.length;
            
            int pow1 = 1, pow2 = 1;
            int hf1 = 0, hf2 = 0;

            for(int i = 0; i < n; i++)
            {
                hf1 = (hf1 + pow1 * a[i]) % hModul;
                hf2 = (hf2 + pow2 * a[i]) % hModul;

                pow1 = (pow1 * hC1) % hModul;
                pow2 = (pow2 * hC2) % hModul;
            }

            hf1 %= hSize;
            while(hf1 < 0) hf1 += hSize;
            HashE element = new HashE(hf1, hf2, n);
            if(table[hf1] == null)
            {
                table[hf1] = element;
            } else
            {
                for(HashE el = table[hf1]; el != null; el = el.next)
                {
                    if(el.hf1 == hf1 && el.hf2 == hf2) return true;
                }

                element.next = table[hf1];
                table[hf1] = element;
            }
            return false;
        }
        
        public boolean contains(int[] a)
        {
            int n = a.length;
            int pow1 = 1, pow2 = 1;
            int hf1 = 0, hf2 = 0;

            for(int i = 0; i < n; i++)
            {
                hf1 = (hf1 + pow1 * a[i]) % hModul;
                hf2 = (hf2 + pow2 * a[i]) % hModul;
                pow1 = (pow1 * hC1) % hModul;
                pow2 = (pow2 * hC2) % hModul;
            }

            hf1 %= hSize;
            while(hf1 < 0) hf1 += hSize;
            if(table[hf1] != null)
                for(HashE el = table[hf1]; el != null; el = el.next)
                    if(el.hf1 == hf1 && el.hf2 == hf2) return true;
            return false;
        }
        
    }
    
    private class depCont
    {
        
        public ArrayList<depend> data = null;
        
        public depCont()
        {
            data = new ArrayList<depend>();
        }
        
        public boolean haveCases()
        {
            for(int i = 0; i < data.size(); i++)
            {
                if(data.get(i).size == 0) return false;
            }
            return true && data.size() > 0;
        }
        
        public boolean delete(int x, int y)
        {
            boolean was_deleted = false;
            for(int i = 0; i < data.size(); i++)
            {
                if(data.get(i).contain(x, y))
                {
                    data.remove(i); break;
                }
            }
            return was_deleted;
        }
        
    }
    
    private TBox t_box = null;
    private Random rand = new Random();
    private depend dep = new depend();
    
    private SchChecker one_more = null;
    
    int DSize = 16384;
    int RSize = 8;
    private depCont[][] d = new depCont[2][DSize];
    
    int[] clash = new int[DSize];
    int cSize = 0;
    
    int[] fsize = new int[RSize];
    int[] exsize = new int[RSize];
    int[][] for_all = new int[RSize][DSize];
    int[][] exist = new int[RSize][DSize];
    
    int[] ind_x = new int[DSize];
    int[] ind_y = new int[DSize];
    int ind_size = 0;
        
    int[] ar = new int[DSize];
    int ar_size = 0;
    
    public final void clear()
    {
        cSize = 0;
        dep.size = 0;
        for(int i = 0; i < RSize; i++)
        {
            fsize[i] = exsize[i] = 0;
        }
        for(int i = 0; i < DSize; i++)
        {
            d[0][i].data.clear();
            d[1][i].data.clear();
        }        
    }
    
    public SchChecker(TBox t)
    {
        t_box = t;
        for(int i = 0; i < DSize; i++)
        {
            d[0][i] = new depCont();
            d[1][i] = new depCont();
        }        
        clear();
    }
    
    private void randomSelect(int x, int size)
    {
        int sign = 0;
        if(x < 0) sign = -1; else sign = 1;
        x = UF.ABS(x);
        
        if( t_box.getRuleGraph().getNode(x).getNodeType() == NodeType.ntAND && sign < 0 ||
            t_box.getRuleGraph().getNode(x).getNodeType() == NodeType.ntOR && sign > 0)
        {
            int child = rand.nextInt(t_box.getRuleGraph().getNode(x).getChildren().size());
            child = t_box.getRuleGraph().getNode(x).getChildren().get(child);
            //add increase please!!!
            dep.x[size] = x;
            dep.y[size] = child;
            randomSelect(child * sign, size + 1);
        } else
        if( t_box.getRuleGraph().getNode(x).getNodeType() == NodeType.ntAND && sign > 0 ||
            t_box.getRuleGraph().getNode(x).getNodeType() == NodeType.ntOR && sign < 0)
        {
            for(int i = 0; i < t_box.getRuleGraph().getNode(x).getChildren().size(); i++)
            {
                int child = t_box.getRuleGraph().getNode(x).getChildren().get(i);
                randomSelect(child * sign, size);
            }
        } else
        {
            dep.size = size;
            depend D = new depend(dep);
            if(sign > 0)
            {
                if(t_box.getRuleGraph().getNode(x).getNodeType() == NodeType.ntSOME)
                {
                    int t = t_box.getRuleGraph().getNode(x).getRoleType();
                    exist[t][exsize[t]++] = x * sign;
                } else
                if(t_box.getRuleGraph().getNode(x).getNodeType() == NodeType.ntALL)
                {
                    int t = t_box.getRuleGraph().getNode(x).getRoleType();
                    for_all[t][fsize[t]++] = x * sign;
                }
                //if there -x added and x wasn't added then new clash found!
                if(d[1][x].data.size() > 0 && d[0][x].data.size() == 0)
                {
                    clash[cSize++] = x;
                }
                d[0][x].data.add(D);
            } else
            {
                if(t_box.getRuleGraph().getNode(x).getNodeType() == NodeType.ntALL)
                {
                    int t = t_box.getRuleGraph().getNode(x).getRoleType();
                    exist[t][exsize[t]++] = x * sign;
                } else
                if(t_box.getRuleGraph().getNode(x).getNodeType() == NodeType.ntSOME)
                {
                    int t = t_box.getRuleGraph().getNode(x).getRoleType();
                    for_all[t][fsize[t]++] = x * sign;
                }
                //if there x added and -x wasn't added then new clash found!
                if(d[0][x].data.size() > 0 && d[1][x].data.size() == 0)
                {
                    clash[cSize++] = x;
                }
                d[1][x].data.add(D);
            }
        }
    }
    
    public void deleteFromClash(int x)
    {
        for(int i = 0; i < cSize; i++)
        {
            if(clash[i] == x)
            {
                for(int j = i; j < cSize - 1; j++)
                    clash[j] = clash[j + 1];
                cSize--;
                break;
            }
        }
    }
    
    public void deleteFromExist(int r, int x)
    {
        for(int i = 0; i < exsize[r]; i++)
        {
            if(exist[r][i] == x)
            {
                for(int j = i; j < exsize[r] - 1; j++)
                {
                    exist[r][j] = exist[r][j + 1];
                }
                exsize[r]--;
                break;
            }
        }
    }
    
    public void deleteFromForAll(int r, int x)
    {
        for(int i = 0; i < fsize[r]; i++)
        {
            if(for_all[r][i] == x)
            {
                for(int j = i; j < fsize[r] - 1; j++)
                {
                    for_all[r][j] = for_all[r][j + 1];
                }
                fsize[r]--;
                break;
            }
        }
    }
    
    public void delete()
    {
        for(int i = 0; i < DSize; i++)
            for(int b = 0; b < 2; b++)
            {
                for(int j = 0; j < ind_size; j++)
                {
                    if(d[b][i].delete(ind_x[j], ind_y[j]))
                    {
                        if(t_box.getRuleGraph().getNode(i).getNodeType() == NodeType.ntSOME && b == 0 ||
                           t_box.getRuleGraph().getNode(i).getNodeType() == NodeType.ntALL && b == 1)
                        {
                            int sn = 1;
                            if(b == 1) sn = -1;
                            deleteFromExist(t_box.getRuleGraph().getNode(i).getRoleType(), i * sn);
                        }
                        if(t_box.getRuleGraph().getNode(i).getNodeType() == NodeType.ntSOME && b == 1 ||
                           t_box.getRuleGraph().getNode(i).getNodeType() == NodeType.ntALL && b == 0)
                        {
                            int sn = 1;
                            if(b == 1) sn = -1;
                            deleteFromForAll(t_box.getRuleGraph().getNode(i).getRoleType(), i * sn);
                        }
                    }
                }
                if(d[b][i].data.size() == 0 && d[1 - b][i].data.size() > 0) deleteFromClash(i);
            }
    }

    int SGN(int x)
    {
        if(x < 0) return -1;
        return 1;
    }
    
    private boolean isOk()
    {
        for(int i = 0; i < RSize; i++)
        {
            for(int j = 0; j < exsize[i]; j++)
            {
                ar_size = 0;
                ar[ar_size++] = t_box.getRuleGraph().getNode(UF.ABS(exist[i][j])).getChildren().get(0) * SGN(exist[i][j]);
                for(int k = 0; k < fsize[i]; k++)
                    ar[ar_size++] = t_box.getRuleGraph().getNode(UF.ABS(for_all[i][k])).getChildren().get(0) * SGN(for_all[i][k]);
                
                if(one_more == null)
                {
                    one_more = new SchChecker(t_box);
                }
                if(!one_more.check(ar, ar_size)) return false;
            }
        }
        return true;
    }
    
    public boolean shuffle(int n)
    {
        for(int step = 0; step < 3 * n; step++)
        {
            if(cSize == 0)
            {
                return isOk();
            }

            ind_size = 0;
            for(int j = 0; j < cSize; j++)
            {
                int x = clash[j];
                int br = rand.nextInt(2);

                if(!d[0][x].haveCases() && !d[1][x].haveCases()) return false;
                if(!d[br][x].haveCases())
                {
                    br = 1 - br;
                }

                for(int i = 0; i < d[br][x].data.size(); i++)
                {
                    int rn = rand.nextInt(d[br][x].data.get(i).size);
                    ind_x[ind_size] = d[br][x].data.get(i).x[rn];
                    ind_y[ind_size] = d[br][x].data.get(i).y[rn];
                    ind_size++;
                }
            }
            
            delete();
            for(int i = 0; i < ind_size; i++)
            {
                int sn = 1;
                if(t_box.getRuleGraph().getNode(ind_x[i]).getNodeType() == NodeType.ntAND) sn =-1;
                randomSelect(ind_x[i] * sn, 0);
            }
        }
        
        return false;
    }

    private HashS pos = new HashS();
    private HashS neg = new HashS();
    int[] save = null;
            
    public boolean check(int a[], int size)
    {
        /*if(neg.contains(save))
        {
            save = null;
            return false;
        }*/
        
        for(int step = 0; step < 10; step++)
        {
            //System.out.print("Step #: ");
            //System.out.println(step);
            clear();
            for(int i = 0; i < size; i++)
                randomSelect(a[i], 0);

            if(shuffle(t_box.getRuleGraph().getConcepts().size()))
            {
                return true;
            }
        }
        return false;
    }
}