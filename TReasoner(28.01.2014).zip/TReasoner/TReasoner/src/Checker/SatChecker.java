/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Checker;

import Enums.NodeType;
import Help.Automorphism;
import Help.Cache;
import Help.DSet;
import Help.Couple;
import Help.HashContainer;
import Help.IntArray;
import Help.Statistics;
import Help.TCache;
import Help.UF;
import Interpretation.Interpretation;
import Interpretation.InterpretationNode;
import KB.ABox;
import KB.RBox;
import KB.TBox;
import RuleGraph.RuleNode;
import KB.Query;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.vocab.OWL2Datatype;

/**
 *
 * @author 1
 */
public class SatChecker {
    
    private class Pair
    {
        public int st1, st2;
        
        public Pair(int x1, int x2)
        {
            st1 = x1;
            st2 = x2;
        }
    }
    
    private class BTState
    {
        public int IndividID = 0, toDoIndex = 0, queueSize = 0;
        public Object option = null;
        public Object lastOption = null;
        
        public boolean[] skips = null; //is skipped vertice
        public boolean[] isDV = null; //is datatype vertice
        public boolean[] toDoPerfs = null; //is reasoner perform toDoList or perform MQfdToDoList
        public int[] curToDo = null;
        public int[] curMQfd = null;
        public int[] curFAll = null;
        
        public int skipsSize = 0;
        
        public DSet context = null;
        public int curBNum = 0;
        
        public BTState()
        {
            
        }
        
        public void clear()
        {
            curBNum = 0;
            IndividID = 0;
            toDoIndex = 0;
            queueSize = 0;
            skipsSize = 0;

            curToDo = null;
            curMQfd = null;
            curFAll = null;
            isDV = null;
            skips = null;
            toDoPerfs = null;
            option = null;
            lastOption = null;
            context = null;
        }
        
        public BTState(int new_IndividID, int new_toDoIndex, Object new_option, Object last_option, int queSize, boolean[] new_perfs, boolean[] new_skips, int _skipsSize, int _curBNum, DSet ctx, int[] _cToDo, int[] _cMQfd, int[] _cFAll, boolean[] _isDV)
        {
            curBNum = _curBNum;
            IndividID = new_IndividID;
            toDoIndex = new_toDoIndex;
            option = new_option;
            lastOption = last_option;
            queueSize = queSize;
            skips = new_skips;
            toDoPerfs = new_perfs;
            context = new DSet();
            skipsSize = _skipsSize;
            curToDo = _cToDo;
            curMQfd = _cMQfd;
            curFAll = _cFAll;
            isDV = _isDV;
        }
        
        public void set(int new_IndividID, int new_toDoIndex, Object new_option, Object last_option, int queSize, boolean[] new_perfs, boolean[] new_skips, int _skipsSize, int _curBNum, DSet ctx, int[] _cToDo, int[] _cMQfd, int[] _cFAll, boolean[] _isDV)
        {
            curBNum = _curBNum;
            IndividID = new_IndividID;
            toDoIndex = new_toDoIndex;
            option = new_option;
            lastOption = last_option;
            queueSize = queSize;
            
            skips = null;
            toDoPerfs = null;
            
            skips = new_skips;
            toDoPerfs = new_perfs;
            context = new DSet();
            skipsSize = _skipsSize;
            curToDo = _cToDo;
            curMQfd = _cMQfd;
            curFAll = _cFAll;
            isDV = _isDV;
        }
        
        public boolean isLastOption()
        {
            if(option instanceof Integer)//this is OR-rule
            {
                return (int)((Integer) option) >= (int)((Integer) lastOption);
            }
            if(option instanceof Pair)//this is a <=-rule ?
            {
                return (((Pair) option).st1 >= ((Pair) option).st2) || 
                        (((Pair) option).st1 == ((Integer)lastOption - 1) && ((Pair) option).st2 == ((Pair) option).st1 + 1);
            }
            if(option instanceof ChooseState)//this is a CHOOSE-rule
            {
                return ((ChooseState)option).notC.isEmpty();
            }
            
            return false;
        }
    }
    
    private class ChooseState
    {
        public ArrayList<Integer> notC = new ArrayList<Integer>();
        public ArrayList<Integer> ai = new ArrayList<Integer>();
        
        public ChooseState(ArrayList<Integer> new_not_c, ArrayList<Integer> new_ai)
        {
            notC = new ArrayList<Integer>(new_not_c);
            ai = new ArrayList<Integer>(new_ai);
        }
    }
    
    private HashSet<InterpretationNode> flag = new HashSet<InterpretationNode>();
    public ArrayList<InterpretationNode> roots = new ArrayList<InterpretationNode>();

    //There is backTracking variables
    int MaxBTSize = 1 << 12;
    private BTState[] BTStack = new BTState[MaxBTSize];
    private int BTSize = 0;
    //End backTracking variables

    //sub[x] contains all super-concepts of x
    //sup[x] contains all sub-concepts of x
    private IntArray[] sub = null;
    private IntArray[] sup = null;
    private int concept_count = 0;
    
    private RBox r_box;
    private TBox t_box;
    private ABox a_box;
    private Interpretation graph;    
    private AChecker a_checker;
    private TCache pos_cache = new TCache(null);
    private TCache neg_cache = new TCache(null);
    Automorphism aut = null;
    
    boolean[] conc = null;
    boolean[] nperfs = null;
    boolean[] nskips = null;
    
    //There is queue variables
    int QMaxSize = 1 << 14;
    private InterpretationNode[] queue = new InterpretationNode[QMaxSize];
    private int[] whqueue = new int[QMaxSize];
    int QSize = 0;
    //End queue variables
    
    private Cache[][] cache = null;
    
    private DSet curDS = null;
    private int curOr = 0;
    private ChooseState curChoose = null;
    private ArrayList<Integer> ai = new ArrayList<Integer>();
    private int curLevel = 0;
    private int st1 = 0, st2 = 1;
    private int curBNum = 0;
    private int newIndividID = 0;
    
    private Statistics stats = new Statistics();
    private boolean use_a_checker = true;
    private boolean show_stats = false;
    private boolean use_back_jump = true;
    private boolean use_global_caching = false;
    private boolean use_caching = false;
    private boolean add_to_end = true;
    
    private boolean a_box_reuse = false;
    
    private long sec_millis = 100000;
    
    private SatChecker sub_checker = null;
    private DataChecker data_checker = null;
    
    private DSet conflictDSet = null;
    private int IndividID = 0, toDoIndex = 0;

    //classification nosubsum
    private HashContainer[] no_sub_sum = null;
    private int no_sub_sum_size = 0;
    
    private boolean class_mode = false;
    
    private String error_string = "";
    
    public SatChecker(SatChecker s_check, RBox new_r_box, TBox new_t_box, ABox new_a_box, boolean is_use_a_checker, boolean is_use_back_jump, boolean is_use_caching, boolean is_use_global_caching, boolean use_show_stats, long secs)
    {
        a_box_reuse = false;
        add_to_end = false;
        use_caching = is_use_caching;
        
        for(int i = 0; i < MaxBTSize; i++)
            BTStack[i] = new BTState();
        
        for(int i = 0; i < QMaxSize; i++)
            queue[i] = new InterpretationNode();
        
        int current_size = 131072;
        if(new_t_box != null) current_size = new_t_box.getRuleGraph().getConcepts().size();
        cache = new Cache[2][current_size];
        
        t_box = new_t_box;
        r_box = new_r_box;
        a_box = new_a_box;
        if(t_box == null)
            aut = new Automorphism(null); else
            aut = new Automorphism(t_box.getRuleGraph());
        sub_checker = s_check;
        if(t_box != null)
        {
            pos_cache.setRuleGraph(t_box.getRuleGraph());
            neg_cache.setRuleGraph(t_box.getRuleGraph());
        }
        
        graph = new Interpretation(new_r_box);
        a_checker = new AChecker(new_t_box, false /*PH Checker*/);
        use_a_checker = is_use_a_checker;
        use_back_jump = is_use_back_jump;
        use_global_caching = is_use_global_caching;
        show_stats = use_show_stats;
        sec_millis = secs;
        data_checker = new DataChecker(new_t_box);
    }
    
    public void clear()
    {
        data_checker.clear();
        error_string = "";
        IndividID = 0; toDoIndex = 0; conflictDSet = null;
        if(sub_checker != null) sub_checker.clear();
        stats.clear();
        if(ai != null) ai.clear(); 
        if(curChoose != null)
        {
            curChoose.ai.clear();
            curChoose.notC.clear();
        }
        
        for(int i = 0; i < 2; i++)
        {
            for(int j = 0; j < cache[0].length; j++)
            {
                cache[i][j] = null;
            }
        }
        
        curDS = null;
        queueClear();
        nperfs = null;
        nskips = null;

        flag.clear();
        roots.clear();

        if(sub != null)
        {
            for(int i = 0; i < concept_count; i++)
                sub[i] = null;
        }
        sub = null;
        
        if(sup != null)
        {
            for(int i = 0; i < concept_count; i++)
                sup[i] = null;
        }
        sup = null;
        
        if(no_sub_sum != null)
        {
            for(int i = 0; i < no_sub_sum_size; i++)
            {
                if(no_sub_sum[i] != null)
                {
                    no_sub_sum[i].clear();
                    no_sub_sum[i] = null;
                }
            }
        }
        
        for(int i = 0; i < BTSize; i++)
            BTStack[i].clear();
        
        for(int i = 0; i < QMaxSize; i++)
            queue[i].clear();
        
        a_checker.clear();
        
        pos_cache.clear();
        neg_cache.clear();
        
        //ph_checker.clear();
        
        conc = null;
    }
    
    private void queueClear()
    {
        QSize = 0;
        for(int i = 0; i < QMaxSize; i++)
            queue[i].clear();
    }
    
    private void increaseStack()
    {
        BTState[] oldStack = BTStack;
        MaxBTSize = (MaxBTSize * 3) / 2 + 1;
        
        BTStack = new BTState[MaxBTSize];
        for(int i = 0; i < BTSize; i++)
            BTStack[i] = oldStack[i];
        
        for(int i = BTSize; i < MaxBTSize; i++)
            BTStack[i] = new BTState();
    }
    
    private void increaseQueue()
    {
        InterpretationNode[] oldQueue = queue;
        int[] oldWhQueue = whqueue;
        
        QMaxSize = (QMaxSize * 3) / 2 + 1;
        
        queue = new InterpretationNode[QMaxSize];
        whqueue = new int[QMaxSize];
        
        for(int i = 0; i < QSize; i++)
        {
            queue[i] = oldQueue[i];
            whqueue[i] = oldWhQueue[i];
        }
        
        for(int i = QSize; i < QMaxSize; i++)
            queue[i] = new InterpretationNode();
        
        oldQueue = null;
        oldWhQueue = null;
    }
        
    private InterpretationNode addNewIndivid(InterpretationNode parent, int new_role, int todo, DSet D, int pos, boolean isDataVertice)
    {
        if(t_box.getRuleGraph().isDataNode(UF.ABS(todo)))
        {
            isDataVertice = true;
        }
        if(add_to_end) pos = -1;
        InterpretationNode current_node = null;
        int wh = BTSize;
        if(pos == -1)
        {
            queue[QSize].clear();
            whqueue[QSize] = wh;
            current_node = graph.addNode(parent, queue[QSize], new_role, wh);
            current_node.indexInQueue = QSize;
        } else
        {
            queue[QSize].clear();
            whqueue[QSize] = wh;
            current_node = graph.addNode(parent, queue[QSize], new_role, wh);
            current_node.indexInQueue = QSize;
            for(int i = QSize; i > pos; i--)
            {
                
                int h = whqueue[i];
                whqueue[i] = whqueue[i - 1];
                whqueue[i - 1] = h;
                
                InterpretationNode nh = queue[i];
                queue[i] = queue[i - 1];
                queue[i - 1] = nh;
                
                queue[i].indexInQueue = i;
                queue[i - 1].indexInQueue = i - 1;
            }
        }
        
        if(QSize == QMaxSize - 1)
        {
            increaseQueue();
        }
        QSize++;

        if(new_role > 0)
        {
            addToDoRec(current_node, r_box.getRoleByIndex(new_role).getRange(), D, wh, null, -1);
        }
        
        DSet dd = null;
        if(D == null) dd = new DSet(); else dd = new DSet(D);
        if(todo != 0) //set to individ some rule
        {
            addToDoRec(current_node, todo, dd, wh, null, -1);
        }

        addToDoRec(current_node, t_box.getMetaConstraint(), new DSet(), wh, null, -1);

        current_node.isDataTypeVertice = isDataVertice;
        return current_node;
    }
    
    private boolean performAnd()
    {
        stats.andAdd();
        
        InterpretationNode current_node = queue[IndividID];
        int c_id = current_node.getToDo()[toDoIndex];

        for(int it: t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren())
        {
            for(int jt: t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren())
            {
                if(it == jt) continue;
                int z = 1;
                if(c_id < 0) z = -1;
                if(a_checker.isDisjoint(z * it, z * jt, current_node))
                {
                    DSet new_d_set = new DSet(current_node.getToDoDSet()[toDoIndex]);
                    getRecentLevel(new_d_set);
                    return false;                    
                }
            }        
        }        
        
        for(int it: t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren())
        {
            if(c_id < 0) 
            {
                if(current_node.isConflict(-it))
                {
                    DSet new_d_set = new DSet(current_node.getToDoDSet()[toDoIndex]);
                    new_d_set.mergeWith(current_node.getConflictDSet(-it));
                    getRecentLevel(new_d_set);
                    return false;
                }
            } else
            {
                if(current_node.isConflict(it))
                {
                    DSet new_d_set = new DSet(current_node.getToDoDSet()[toDoIndex]);
                    new_d_set.mergeWith(current_node.getConflictDSet(it));
                    getRecentLevel(new_d_set);
                    return false;
                }
            }
        }
        
        int cnt = 0;
        for(int i = 0; i < t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().size(); i++)
        {
            int it = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().get(i);
            if(c_id < 0)
            {
                DSet d = new DSet();
                d.mergeWith(current_node.getToDoDSet()[toDoIndex]);
                if(current_node.addToDoPos(-it, d, BTSize, toDoIndex + cnt + 1)) cnt++;
            } else
            {
                DSet d = new DSet();
                d.mergeWith(current_node.getToDoDSet()[toDoIndex]);
                if(current_node.addToDoPos( it, d, BTSize, toDoIndex + cnt + 1)) cnt++;
            }
        }
        return true;
    }
    
    private void cutOff(int concept_id, DSet D)
    {
        InterpretationNode crnd = queue[IndividID];
        for(int i = toDoIndex + 1; i < crnd.getToDoSize(); i++)
        {
            int c_id = crnd.getToDo()[i];
            if(t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().size() != 2) continue;
            if(t_box.getRuleGraph().getNode(UF.ABS(c_id)).getNodeType() == NodeType.ntOR && c_id > 0 || 
               t_box.getRuleGraph().getNode(UF.ABS(c_id)).getNodeType() == NodeType.ntAND && c_id < 0)
            {
                int it1 = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().get(0);
                int it2 = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().get(1);
                
                if(c_id < 0)
                {
                    it1 = -it1;
                    it2 = -it2;
                }
                DSet new_D = new DSet(D);
                
                if(use_a_checker && a_checker.isDisjoint(it1, concept_id, crnd))
                {
                    new_D.mergeWith(crnd.getToDoDSet()[i]);
                    crnd.addToDoPos(it2, new_D, BTSize, toDoIndex + 1);
                } else
                {
                    if(use_a_checker && a_checker.isDisjoint(it2, concept_id, crnd))
                    {
                        new_D.mergeWith(crnd.getToDoDSet()[i]);
                        crnd.addToDoPos(it1, new_D, BTSize, toDoIndex + 1);
                    }
                }
            }
        }
    }
    
    private boolean isOrContain(int c_id)
    {
        InterpretationNode current_node = queue[IndividID];
        int n = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().size();
        for(int j = 0; j < n; j++)
        {
            int it = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().get(j);
            if(c_id < 0) it = -it;
            if(current_node.isContain(it)) return true;
            if((t_box.getRuleGraph().getNode(UF.ABS(it)).getNodeType() == NodeType.ntOR  && it > 0) ||
               (t_box.getRuleGraph().getNode(UF.ABS(it)).getNodeType() == NodeType.ntAND && it < 0))
            {
                if(isOrContain(it)) return true;
            }
        }
        return false;
    }
    
    private boolean performOr()
    {
        stats.orAdd();
        
        InterpretationNode current_node = queue[IndividID];
        boolean justAdded = false;
        if(curOr == 0) justAdded = true;
        int c_id = current_node.getToDo()[toDoIndex];
        DSet d = new DSet(current_node.getToDoDSet()[toDoIndex]);
        if(!justAdded) d.mergeWith(curDS);
            
        int n = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().size();
    
        if(isOrContain(c_id)) return true;
        
        for(int j = 0; j < n; j++)
        {
            int it = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().get(j);
            if(c_id < 0) it = -it;
            if(current_node.isContain(it)) return true;
        }
        
        for(int j = curOr; j < n; j++)
        {
            int it = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getChildren().get(j);
            if(c_id < 0) it = -it;
            if(current_node.isConflict(it))
            {
                d.mergeWith(current_node.getConflictDSet(it));
                continue;
            }
            
            ////////////////////////CHECK DISJOINTNESS//////////////////////////
            if(use_a_checker)
            {
                boolean is_cont = false;

                for(int i = toDoIndex + 1; i < current_node.getToDoSize(); i++)
                    if(a_checker.isDisjoint(current_node.getToDo()[i], it, current_node))
                    {
                        d.mergeWith(current_node.getToDoDSet()[i]);
                        is_cont = true;
                        break;
                    }

                if(!is_cont)
                {
                    for(int i = 0; i < current_node.getFAllSize(); i++)
                    {
                        if(a_checker.isDisjoint(current_node.getFAll()[i], it, current_node))
                        {
                            d.mergeWith(current_node.getDSet(current_node.getFAll()[i]));
                            is_cont = true;
                            break;
                        }
                    }
                }

                if(!is_cont)
                {
                    for(int i = 0; i < current_node.getSomeSize(); i++)
                    {
                        if(a_checker.isDisjoint(current_node.getIncr()[i], it, current_node))
                        {
                            d.mergeWith(current_node.getDSet(current_node.getIncr()[i]));
                            is_cont = true;
                            break;
                        }
                    }
                }

                if(is_cont)
                {
                    continue;
                }
            }
            ////////////////////////////////////////////////////////////////////
            
            //Choose one alternative
            remember(j, n, justAdded, d);
            current_node.addToDoPos(it, d, BTSize, toDoIndex + 1);
            curOr = 0;
            return true;
        }
        remember(n, n, justAdded, d);
        getRecentLevel(d);
        return false;
    }
    
    private boolean performAddConcept()
    {
        stats.conceptAdd();
        
        InterpretationNode current_node = queue[IndividID];
        int c_id = current_node.getToDo()[toDoIndex];//current node id
        
        int c_ds = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getSubDescription();//current node description
        int n_ds = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getNegativeDescription();//current node description
        int eq_ds = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getDescription();
        
        if(current_node.isConflict(c_id)) //There is some clash!
        {            
            DSet new_d_set = new DSet(current_node.getToDoDSet()[toDoIndex]);
            new_d_set.mergeWith(current_node.getConflictDSet(c_id));
            getRecentLevel(new_d_set);
            return false;
        }

        DSet d = new DSet();
        //Positive lazy unfolding
        if(!current_node.isContain(c_ds))//This node haven't this concepts description
        {
            if(c_ds != 0 && c_id > 0)
            {
                d.mergeWith(current_node.getToDoDSet()[toDoIndex]);
                current_node.addToDo(c_ds, d, BTSize, t_box);
            }
        }

        //Negative lazy unfolding //WORKS TOO SLOW!
        /*if(!current_node.isContain(n_ds))//This node haven't this concepts negative description
        {
            if(n_ds != 0 && c_id < 0)
            {
                d.mergeWith(current_node.getToDoDSet()[toDoIndex]);
                current_node.addToDo(n_ds, d, BTSize, t_box);
            }
        }*/
        
        if(!current_node.isContain(eq_ds))//This node haven't this concepts description
        {
            if(eq_ds != 0)
            {
                if(c_id > 0) //if concept isn't complement - then add its description to ToDo List
                {
                    d.mergeWith(current_node.getToDoDSet()[toDoIndex]);
                    current_node.addToDo(eq_ds, d, BTSize, t_box);
                } else
                {
                    //if concept C is named concept and have negation then add description or negation of its description to TODO
                    if(t_box.getRuleGraph().getNode(UF.ABS(c_id)).isNamed())//this concept have equivalence
                    {
                        //if adding concept is negation concept - then we negate its equivalence
                        if(c_id < 0) eq_ds *= -1;
                        d.mergeWith(current_node.getToDoDSet()[toDoIndex]);
                        current_node.addToDo(eq_ds, d, BTSize, t_box);
                    }
                }
            }
        }
        
        return true;
    }
    
    //add SOME-ruels and >= - rules
    private boolean performIncrease()
    {
        int hlp = queue[IndividID].getToDo()[toDoIndex];
        RuleNode tmp_rn = t_box.getRuleGraph().getNode(UF.ABS(hlp));

        int td = 1;
        if(tmp_rn.getChildren().size() > 0)
            td = tmp_rn.getChildren().get(0);
        
        if(hlp < 0 && (tmp_rn.getNodeType() == NodeType.ntALL || tmp_rn.getNodeType() == NodeType.ntSOME)) td *= -1;
        if(td == -1) td = 1;
        int n = 1;
        if(tmp_rn.getNodeType() == NodeType.ntEXTCARD || tmp_rn.getNodeType() == NodeType.ntMINCARD || tmp_rn.getNodeType() == NodeType.ntMAXCARD)
        {
            n = tmp_rn.getNumberRestriction();
            if(hlp < 0) n++;
        }
        if(n == 0)
        {
            return true;
        }
        
        int dom = r_box.getRoleByIndex(t_box.getRuleGraph().getNode(UF.ABS(queue[IndividID].getToDo()[toDoIndex])).getRoleType()).getDomain();
        int rng = r_box.getRoleByIndex(t_box.getRuleGraph().getNode(UF.ABS(queue[IndividID].getToDo()[toDoIndex])).getRoleType()).getRange();
        if(dom > 1)
        {
            DSet d = new DSet(queue[IndividID].getToDoDSet()[toDoIndex]);
            queue[IndividID].addToDo(dom, d, BTSize, t_box);
        }

        boolean idv = false;
        boolean add_nv = true;
        if(r_box.getRoleByIndex(tmp_rn.getRoleType()).isDataRole())
            idv = true;
        
        if( t_box.getRuleGraph().getNode(UF.ABS(td)).getDatatype() != null || 
            t_box.getRuleGraph().getNode(UF.ABS(td)).getFacet() != null || 
            t_box.getRuleGraph().getNode(UF.ABS(td)).getLiter() != null)
        {
            idv = true;
        }
        
        if(r_box.getRoleByIndex(tmp_rn.getRoleType()).isFunctional())
        {
            if(n > 1)
            {
                DSet new_d_set = new DSet(queue[IndividID].getToDoDSet()[toDoIndex]);
                getRecentLevel(new_d_set);
                return false;
            }
            else
            {
                for(int i = 0; i < queue[IndividID].getChildSize(); i++)
                {
                    boolean bl = r_box.hasCommonFuncAllRoles(queue[IndividID].getChildren()[i].getRoles(), tmp_rn.getRoleType());
                    for(int j = 0; j < queue[IndividID].getChildren()[i].getRoles().size(); j++)
                    {
                        int rit = queue[IndividID].getChildren()[i].getRoles().get(j);
                        if(r_box.isSubOrEqual(rit, tmp_rn.getRoleType()) || bl)
                        {
                            add_nv = false;
                            queue[IndividID].getChildren()[i].getNode().addToDo(td, new DSet(queue[IndividID].getToDoDSet()[toDoIndex]), BTSize, t_box);
                            if(!queue[IndividID].getChildren()[i].getRoles().contains(tmp_rn.getRoleType()))
                                queue[IndividID].getChildren()[i].getRoles().add(tmp_rn.getRoleType());
                            break;
                        }
                    }
                    if(!add_nv)
                        break;
                }
            }
        }
        
        if(add_nv)
        {
            if(n == 1) //check if we have child with same concept
            {
                boolean has_same_child = false;
                for(int i = 0; i < queue[IndividID].getChildSize(); i++)
                {
                    boolean is_subrole = false;
                    for(int j = 0; j < queue[IndividID].getChildren()[i].getRoles().size(); j++)
                    {
                        if(r_box.isSubOrEqual(tmp_rn.getRoleType(), queue[IndividID].getChildren()[i].getRoles().get(j))) //if role of some child is sub role of current role
                        {
                            is_subrole = true; break;
                        }                        
                    }
                    if(is_subrole)
                    {
                        if(queue[IndividID].getChildren()[i].getNode().isContain(td))
                        {
                            has_same_child = true;
                            break;
                        }
                    }
                }
                for(int i = 0; i < queue[IndividID].getParentSize(); i++)
                {
                    boolean is_subrole = false;
                    for(int j = 0; j < queue[IndividID].getParents()[i].getRoles().size(); j++)
                    {
                        if(r_box.isReverseSubOrEqual(tmp_rn.getRoleType(), queue[IndividID].getParents()[i].getRoles().get(j))) 
                        //if role of some child is sub role of current role inverse
                        {
                            is_subrole = true; break;
                        }                        
                    }
                    if(is_subrole)
                    {
                        if(queue[IndividID].getParents()[i].getNode().isContain(td))
                        {
                            has_same_child = true;
                            break;
                        }
                    }
                }
                if(!has_same_child)
                {
                    stats.someAdd();
                    InterpretationNode new_child = addNewIndivid(queue[IndividID], tmp_rn.getRoleType(), td, new DSet(queue[IndividID].getToDoDSet()[toDoIndex]), IndividID + 1, idv);
                    
                    if(new_child != null)
                        new_child.addToDo(rng, new DSet(queue[IndividID].getToDoDSet()[toDoIndex]), BTSize, t_box);
                    
                    queue[IndividID].addIncr(queue[IndividID].getToDo()[toDoIndex], BTSize);
                }
            } else
            {
                for(int i = 0; i < n; i++)
                {
                    stats.someAdd();
                    InterpretationNode new_child = addNewIndivid(queue[IndividID], tmp_rn.getRoleType(), td, new DSet(queue[IndividID].getToDoDSet()[toDoIndex]), IndividID + 1, idv);
                    new_child.addToDo(rng, new DSet(queue[IndividID].getToDoDSet()[toDoIndex]), BTSize, t_box);
                }
                queue[IndividID].addIncr(queue[IndividID].getToDo()[toDoIndex], BTSize);
            }
        }
        return true;
    }
    
    //add FORALL rules
    private boolean performAll()
    {
        queue[IndividID].addFAll(queue[IndividID].getToDo()[toDoIndex], BTSize);
        return true;
    }
    
    //add <= - rules
    private boolean performDecrease()
    {
        queue[IndividID].addMQfd(queue[IndividID].getToDo()[toDoIndex], new DSet(queue[IndividID].getToDoDSet()[toDoIndex]), BTSize);
        return true;
    }
    
    //get next choose state
    private void nextChoose()
    {
        int el = 1;
        if(curChoose.notC.size() > 0)
        {
            el = curChoose.notC.get(curChoose.notC.size() - 1);
            curChoose.notC.remove(curChoose.notC.size() - 1);
        }
        for(int i = 0; i < ai.size(); i++)
            if(ai.get(i) > el)
                curChoose.notC.add(ai.get(i));
    }
    
    //check whether we can marge two interpretation nodes
    private boolean canMerge(InterpretationNode anc, InterpretationNode n1, InterpretationNode n2, DSet D)
    {
        if(n1.indexInQueue == n2.indexInQueue)
        {
            return false;
        }
        if(n1.isDataTypeVertice && !n2.isDataTypeVertice || !n1.isDataTypeVertice && n2.isDataTypeVertice)
        {
            D.addValue(whqueue[n1.indexInQueue]);
            D.addValue(whqueue[n2.indexInQueue]);
            return false;
        }
        //проверка на то что ToDoList не пересекается
        for(int i = 0; i < n1.getToDoSize(); i++)
            for(int j = 0; j < n2.getToDoSize(); j++)
            {
                if(n1.getToDo()[i] == -n2.getToDo()[j])
                {
                    D.mergeWith(n1.getToDoDSet()[i]);
                    D.mergeWith(n2.getToDoDSet()[j]);
                    return false;
                }
                //моя проверка на непересекаемость
                if(use_a_checker && a_checker.isDisjoint(n1.getToDo()[i], n2.getToDo()[j], queue[IndividID]))
                {
                    D.mergeWith(n1.getToDoDSet()[i]);
                    D.mergeWith(n2.getToDoDSet()[j]);
                    return false;
                }
            }

        //проверка на то что предки не могут быть объединены, так как у них один и тот же предок и от него идут не пересекающиеся роли
        for(int i = 0; i < n1.getParentSize(); i++)
            for(int j = 0; j < n2.getParentSize(); j++)
                if(n1.getParents()[i].getNode() == n2.getParents()[j].getNode())
                    if(r_box.haveDisjoint(n1.getParents()[i].getRoles(), n2.getParents()[j].getRoles()))
                    {
                        //Make something with DSet
                        return false;
                    }

        //проверка на то что выполнено >= правило
        for(int i = 0; i < anc.getToDoSize(); i++) //очень медленно работает
        {
            if( t_box.getRuleGraph().getNode(UF.ABS(anc.getToDo()[i])).getNodeType() == NodeType.ntMINCARD && anc.getToDo()[i] > 0 ||
                t_box.getRuleGraph().getNode(UF.ABS(anc.getToDo()[i])).getNodeType() == NodeType.ntMAXCARD && anc.getToDo()[i] < 0)
            {
                if(r_box.isSubOrEqual(t_box.getRuleGraph().getNode(UF.ABS(anc.getToDo()[i])).getRoleType(), 
                                      t_box.getRuleGraph().getNode(UF.ABS(queue[IndividID].getMQfd()[queue[IndividID].currentMQfd])).getRoleType()))
                {
                    int n = t_box.getRuleGraph().getNode(UF.ABS(anc.getToDo()[i])).getNumberRestriction();
                    if(anc.getToDo()[i] < 0) n++;

                    //
                    int card_concept = 1;
                    if(!t_box.getRuleGraph().getNode(UF.ABS(anc.getToDo()[i])).getChildren().isEmpty())
                        card_concept = t_box.getRuleGraph().getNode(UF.ABS(anc.getToDo()[i])).getChildren().get(0);
                    
                    if(anc.getNeighboursCount(t_box.getRuleGraph().getNode(UF.ABS(anc.getToDo()[i])).getRoleType(), 
                            card_concept, r_box, n1, n2) <= n - 1)
                    {
                        n2.setSkip(false);
                        D.mergeWith(anc.getToDoDSet()[i]);
                        return false;
                    }
                    n2.setSkip(false);
                }
            }
        }
        return true;
    }
    
    private void merge(InterpretationNode n1, InterpretationNode n2, DSet d)
    {
        if(n1.indexInQueue == n2.indexInQueue) //need not to merge same individs
        {
            return;
        }
        if(n1.getIndsSize() < n2.getIndsSize())
        {
            merge(n2, n1, d);
            return;
        }
        //merge ancestors
        for(int i = 0; i < n2.getParentSize(); i++)
        {
            for(int j = 0; j < n2.getParents()[i].getRoles().size(); j++)
            {
                n1.addParent(n2.getParents()[i].getNode(), n2.getParents()[i].getRoles().get(j), BTSize, r_box);
                n2.getParents()[i].getNode().addChild(n1, n2.getParents()[i].getRoles().get(j), BTSize);
                n1.updateParents(n2.getParents()[i].getRoles().get(j), BTSize, r_box);
            }
        }

        //merge children
        for(int i = 0; i < n2.getChildSize(); i++)
        {
            for(int j = 0; j < n2.getChildren()[i].getRoles().size(); j++)
            {
                n1.addChild(n2.getChildren()[i].getNode(), n2.getChildren()[i].getRoles().get(j), BTSize);
            }
        }

        //merge ToDo
        if( newIndividID > n1.indexInQueue)
        {
            newIndividID = n1.indexInQueue;
        }
        
        for(int i = 0; i < n2.getToDoSize(); i++)
        {
            if(n1.isContain(n2.getToDo()[i])) continue;
            DSet q = new DSet(n2.getToDoDSet()[i]);
            q.mergeWith(d);
            n1.addToDo(n2.getToDo()[i], q, BTSize, t_box);
        }
        
        //all will be added on todo processing
        
        //merge individs
        for(int i = 0; i < n2.getIndsSize(); i++)
        {
            n1.addIndivid(n2.getInds()[i], BTSize);
            a_box.setNode(a_box.find(n2.getInds()[i]), n1);
        }
        //merge forall
        for(int i = 0; i < n2.getFAllSize(); i++)
        {
            n1.addFAll(n2.getFAll()[i], BTSize);
        }
        //merge some
        for(int i = 0; i < n2.getSomeSize(); i++)
        {
            n1.addIncr(n2.getIncr()[i], BTSize);
        }
        //merge mqfd
        for(int i = 0; i < n2.getMQfdSize(); i++)
        {
            n1.addMQfd(n2.getMQfd()[i], n2.getMxQfDSet()[i], BTSize);
        }
        
        //this node need not to process, it merged with n1 - skip it
        n2.setSkip(true);
    }
    
    private boolean makeDecrease()
    {
        InterpretationNode current_node = queue[IndividID];
        RuleNode rn = t_box.getRuleGraph().getNode(UF.ABS(current_node.getMQfd()[queue[IndividID].currentMQfd]));
        ArrayList<InterpretationNode> ain = current_node.getNeighboursByRole(rn.getRoleType(), r_box); //"ain" contain all R-neighbours
        DSet D = new DSet(current_node.getMxQfDSet()[queue[IndividID].currentMQfd]);
        
        int n = rn.getNumberRestriction();
        for(int i = 0; i < ain.size(); i++)
        {
            if(ain.get(i).isSkipped()) n++;
        }
        if(current_node.getMQfd()[queue[IndividID].currentMQfd] < 0) n--;
        
        int C = 1;
        if(!rn.getChildren().isEmpty())
            C = rn.getChildren().get(0);
        if(t_box.getRuleGraph().getNode(C).getDatatype() != null)
        {
            if(t_box.getRuleGraph().getNode(C).getDatatype().isBuiltIn()) if(t_box.getRuleGraph().getNode(C).getDatatype().getBuiltInDatatype() == OWL2Datatype.RDFS_LITERAL)
            {
                C = 1;
            }
        }

        if(C != 1)
        {
            //System.out.println("Q LETTER!");
        }
        boolean justAdded = (curChoose == null);

        if(C != 1) //there is a Qualified number restriction!
        {
            if(st1 == 0 && st2 == 1) //somewhere was a clash in choose rule or it is a first choose rule step: не нужно проводить choose если у нас клэш оказался при слиянии каких-то вершин
            {
                //"ai" contains all numbers of all R-neighbours - ещё нужно запоминать и ai так как он хранит разные числа для <= правил 
                ai.clear();
                for(int i = 0; i < ain.size(); i++)
                    if(!ain.get(i).isContain(C))
                        ai.add(i);

                //make CHOICE - add C and -C concepts to all neighbours
                if(curChoose != null)
                {
                    nextChoose(); //делаем следующий выбор в который подставим -C
                } else
                {
                    curChoose = new ChooseState(new ArrayList<Integer>(), ai);
                    for(int i = 0; i < ai.size(); i++)
                        curChoose.notC.add(ai.get(i)); //если первый раз вызываем <= правило, тогда всем назначаем -C
                }

                DSet new_d_set = new DSet(D);
                remember(new ChooseState(curChoose.notC, curChoose.ai), 0, justAdded, new_d_set);

                for(int i = 0; i < curChoose.notC.size(); i++) //в этом цикле делаем choose и добавляем везде -C где это выбрано
                    ain.get(ai.get(i)).addToDo(-C, new_d_set, BTSize, t_box);

                for(int i = 0; i < ai.size(); i++) //а в этом цикле добавляем C везде где это выбрано
                {
                    if(!curChoose.notC.contains(ai.get(i)))
                        ain.get(ai.get(i)).addToDo(C, new_d_set, BTSize, t_box);
                }
                //WE MADE THIS CHOICE!!
            } else
            {
                ai = new ArrayList<Integer>(curChoose.ai);
            }
        }
        
        //merge C-neighbours while there are >= n of its
        int count = ain.size(); //если появляется UNqualified number restriction, то в слиянии участвуют все потомки
        if(C != 1) count = ai.size() - curChoose.notC.size(); //count of R-neighbours with concept C
        
        boolean justAddedLE = false;
        if(st1 == 0 && st2 == 1) justAddedLE = true;
        if(count <= n) //если у нас теперь нужное количество R последователей, то выходим из циклов
        {
            if(current_node.currentMQfd >= current_node.getMQfdSize())
                IndividID = newIndividID;
            return true;
        }

        for(int i = st1; i < ain.size(); i++, st1++, st2 = st1 + 1)
        {
            if(ain.get(i).isSkipped()) continue; //if this vertice is blocked or if this vertice is merged to another - skip it!
            if(C != 1) if(curChoose.notC.contains(i)) continue; //if i-th neighbour contains "-C" skip it!
            for(int j = st2; j < ain.size(); j++)
            {
                if(ain.get(j).isSkipped()) continue; //if this vertice is blocked or if this vertice is merged to another - skip it!
                if(C != 1) if(curChoose.notC.contains(j)) continue; //if j-th neighbour contains "-C" skip it!

                if(canMerge(current_node, ain.get(i), ain.get(j), D)) //если можно слить вершины - сливаем их! - добавить сюда ещё проверку на >= правило!!!
                {
                    DSet new_d_set = new DSet(D); //от чего зависит этот maxQfD (<= n) правило + текущий размер стека
                    //D.addValue(BTSize);
                    remember(new Pair(i, j), ain.size(), justAddedLE, new_d_set); //запоминаем текущее состояние

                    merge(ain.get(i), ain.get(j), new_d_set); //сливаем обе вершины
                    
                    count--; //так как вершины слиты, значит у нас R последователей стало на 1 меньше
                    if(count <= n) //если у нас теперь нужное количество R последователей, то выходим из циклов
                    {
                        st1 = 0; st2 = 1; //устанавливаем st1 = 0, st2 = 1 для новых ограничений кардинальности
                        return true;
                    }
                }
            }
            //st2 = i + 2; //если второй цикл весь обратился, то st2 надо начинать на 1 больше чем i, поэтому для текущего надо поставить +2
        }

        DSet mqd = new DSet(D);
        for(int i = 0; i < ain.size(); i++)
        {
            if(ain.get(i).isSkipped())
            {
                if(whqueue[ain.get(i).indexInQueue] > 0)
                {
                    mqd.addValue(whqueue[ain.get(i).indexInQueue]);
                }
            }
        }
        mqd.mergeWith(current_node.getMxQfDSet()[queue[IndividID].currentMQfd]);
        getRecentLevel(mqd);
        ain = current_node.getNeighboursByRole(rn.getRoleType(), r_box);
        return false;
    }
    
    //add successors from AND node
    private void addToDoRec(InterpretationNode node, int toDoEntry, DSet D, int when, InterpretationNode par, int role)
    {
        /*if(t_box.getRuleGraph().getNode(UF.ABS(toDoEntry)).getNodeType() == NodeType.ntAND && toDoEntry > 0 || 
           t_box.getRuleGraph().getNode(UF.ABS(toDoEntry)).getNodeType() == NodeType.ntOR && toDoEntry < 0)
        {
            for(int i = 0; i < t_box.getRuleGraph().getNode(UF.ABS(toDoEntry)).getChildren().size(); i++)
            {
                int it = t_box.getRuleGraph().getNode(UF.ABS(toDoEntry)).getChildren().get(i);
                if(toDoEntry < 0) it = -it;
                addToDoRec(node, it, new DSet(D), when, par, role);
            }
        } else*/
        {
            if(par != null)
            {
                node.addParent(par, role, when, r_box);
                node.updateParents(role, when, r_box);
            }
            node.addToDo(toDoEntry, new DSet(D), when, t_box);
            //if( newIndividID > node.indexInQueue) //если что-то было добавлено в очередь ранее чем текущая рассматриваемая вершина, то указатель переставляется на неё
            //    newIndividID = node.indexInQueue;
        }
    }
    
    private void makeIncrease() //после того как были добавлены все потомки, выполняем for all правила //add hierarchy of roles
    {
        InterpretationNode current_node = queue[IndividID];
        boolean cycle_just_added = false;
        for(; current_node.currentFAll < current_node.getFAllSize(); current_node.currentFAll++)
        {
            int i = current_node.currentFAll;
            int it = current_node.getFAll()[i];
            for(int j = 0; j < current_node.getChildSize(); j++)
            {
                Couple jt = current_node.getChildren()[j];
                RuleNode t = t_box.getRuleGraph().getNode(UF.ABS(it));

                if(!r_box.isSubOrEqualAll(jt.getRoles(), t.getRoleType())) continue;
                
                DSet D = new DSet(current_node.getToDoDSet()[current_node.findInToDo(it)]);
                
                int td = t.getChildren().get(0);
                if(it < 0) td *= -1;
                
                stats.allAdd();
                addToDoRec(jt.getNode(), td, new DSet(D), BTSize, current_node, t.getRoleType()); //and вершина раскрывается сразу

                if(r_box.getRoleByIndex(t.getRoleType()).isTransitive()) //если роль транзитивна, то необходимо добавить тоже самое FORALL-rule
                {
                    for(int k = 0; k < jt.getRoles().size(); k++)
                    {
                        if(r_box.isEqual(jt.getRoles().get(k), t.getRoleType()))
                        {
                            if(jt.getNode().isContain(it) && !cycle_just_added)
                            {
                                //System.out.println("CYCLE FOUND ON ROLE: " + r_box.getRoleByIndex(t_box.getRuleGraph().getNode(UF.ABS(it)).getRoleType()).getName());
                                //System.out.println(queue[IndividID].getInds()[0] + " " + jt.getNode().getInds()[0]);
                            }
                            cycle_just_added = true;
                            addToDoRec(jt.getNode(), it, new DSet(D), BTSize, current_node, jt.getRoles().get(k));                            
                        } else if(r_box.isSub(jt.getRoles().get(k), t.getRoleType()))
                        {
                            addToDoRec(jt.getNode(), t.getTransByRole(t_box, jt.getRoles().get(k)), new DSet(D), BTSize, current_node, jt.getRoles().get(k));
                        }
                    }
                }
                graph.unBlock(jt.getNode());
                graph.makeBlocked(jt.getNode(), queue, IndividID);
                
                if( newIndividID > jt.getNode().indexInQueue) //если что-то было добавлено в очередь ранее чем текущая рассматриваемая вершина, то указатель переставляется на неё
                {
                    newIndividID = jt.getNode().indexInQueue;
                }
            }

            //inverse roles
            for(int j = 0; j < current_node.getParentSize(); j++)
            {
                Couple jt = current_node.getParents()[j];
                RuleNode t = t_box.getRuleGraph().getNode(UF.ABS(it));

                if(!r_box.isReverseSubOrEqualAll(jt.getRoles(), t.getRoleType())) continue;
                
                DSet D = new DSet(current_node.getToDoDSet()[current_node.findInToDo(it)]);
                
                int td = t.getChildren().get(0);
                if(it < 0) td *= -1;
                
                stats.allAdd();
                addToDoRec(jt.getNode(), td, new DSet(D), BTSize, current_node, t.getRoleType()); //and вершина раскрывается сразу
                if(r_box.getRoleByIndex(t.getRoleType()).isTransitive()) //если роль транзитивна, то необходимо добавить тоже самое FORALL-rule
                {
                    for(int k = 0; k < jt.getRoles().size(); k++)
                    {
                        if(r_box.isEqual(jt.getRoles().get(k), t.getRoleType()))
                        {
                            addToDoRec(jt.getNode(), it, new DSet(D), BTSize, current_node, jt.getRoles().get(k));                            
                        } else
                        if(r_box.isSub(jt.getRoles().get(k), t.getRoleType()))
                        {
                            addToDoRec(jt.getNode(), t.getTransByRole(t_box, jt.getRoles().get(k)), new DSet(D), BTSize, current_node, jt.getRoles().get(k));
                        }
                    }
                }
                graph.unBlock(jt.getNode());
                graph.makeBlocked(jt.getNode(), queue, IndividID);
                
                if( newIndividID > jt.getNode().indexInQueue) //если что-то было добавлено в очередь ранее чем текущая рассматриваемая вершина, то указатель переставляется на неё
                {
                    newIndividID = jt.getNode().indexInQueue;
                }
            }
        }
    }
    
    public void printInterpretation(int c_id)
    {
        for(int i = 0; i < QSize; i++)
        {
            if(queue[i].isContain(c_id))
            {
                queue[i].show(r_box, t_box);
            }
        }
    }
    
    private boolean performAddIndivid()
    {
        int c_id = queue[IndividID].getToDo()[toDoIndex];
        RuleNode rn = t_box.getRuleGraph().getNode(UF.ABS(queue[IndividID].getToDo()[toDoIndex]));
    
        if(c_id > 0)
        {
            stats.individAdd();
            if(a_box.findNode(rn.getName()) == null && c_id > 0)
            {
                ArrayList<String> als = a_box.getExpandedNodes(rn.getName());
                for(int i = 0; i < als.size(); i++)
                {
                    InterpretationNode cur_node = addNewIndivid(null, -1, 0, new DSet(queue[IndividID].getToDoDSet()[toDoIndex]), IndividID + 1, false);
                    a_box.createNode(als.get(i), new DSet(queue[IndividID].getToDoDSet()[toDoIndex]), cur_node, t_box);
                }
                a_box.realizeRelations(r_box, BTSize);
            }
            //create an individ that from rule Class = OneOfIndivid(i1, i2, ..., in) and merge this individ to current
            merge(queue[IndividID], a_box.findNode(rn.getName()), new DSet(queue[IndividID].getToDoDSet()[toDoIndex]));
        }
        return true;
    }
    
    private boolean performAddSelf()
    {
        //TODO
        return true;
    }

    private boolean updateToDo()
    {
        int c_id = queue[IndividID].getToDo()[toDoIndex];
        NodeType c_nt = t_box.getRuleGraph().getNode(UF.ABS(c_id)).getNodeType();

        cutOff(c_id, queue[IndividID].getToDoDSet()[toDoIndex]);

        if(queue[IndividID].isConflict(c_id))
        {
            DSet new_d_set = new DSet(queue[IndividID].getToDoDSet()[toDoIndex]);
            new_d_set.mergeWith(queue[IndividID].getConflictDSet(c_id));
            getRecentLevel(new_d_set);
            return false;
        }
        ///////////////////////////OTHER DESCRIPTION////////////////////////////
        ////////////////////////////SOME HEURISTIC//////////////////////////////
        if(c_nt != NodeType.ntCONCEPT)
        {
            if(t_box.getRuleGraph().getNode(UF.ABS(c_id)).getDescription() != 0)
            {
                DSet d = new DSet();
                d.mergeWith(queue[IndividID].getToDoDSet()[toDoIndex]);
                int sign = 1;
                if(c_id < 0) sign = -1;
                queue[IndividID].addToDo(sign * t_box.getRuleGraph().getNode(UF.ABS(c_id)).getDescription(), d, BTSize, t_box);
            }
            if(c_id > 0 && t_box.getRuleGraph().getNode(c_id).getSubDescription() != 0)
            {
                DSet d = new DSet();
                d.mergeWith(queue[IndividID].getToDoDSet()[toDoIndex]);
                queue[IndividID].addToDo(t_box.getRuleGraph().getNode(c_id).getSubDescription(), d, BTSize, t_box);
            }
        }
        ////////////////////////////////////////////////////////////////////////
        //AND
        if((c_nt == NodeType.ntAND && c_id > 0) || (c_nt == NodeType.ntOR && c_id < 0))
        {
            if(!performAnd()) return false;
        } else
        //OR
        if((c_nt == NodeType.ntOR && c_id > 0) || (c_nt == NodeType.ntAND && c_id < 0))
        {
            if(!performOr()) return false;
        } else
        //SOME
        if((c_nt == NodeType.ntSOME && c_id > 0) || (c_nt == NodeType.ntALL && c_id < 0))
        {
            if(!performIncrease()) return false;
        } else
        //ALL
        if((c_nt == NodeType.ntALL && c_id > 0) || (c_nt == NodeType.ntSOME && c_id < 0))
        {
            if(!performAll()) return false;
        } else
        //MINCARD
        if((c_nt == NodeType.ntMINCARD && c_id > 0) || (c_nt == NodeType.ntMAXCARD && c_id < 0))
        {
            if(!performIncrease()) return false;
        } else
        //MAXCARD
        if((c_nt == NodeType.ntMAXCARD && c_id > 0) || (c_nt == NodeType.ntMINCARD && c_id < 0))
        {
            if(!performDecrease()) return false;
        } else
        //EXTCARD
        if(c_nt == NodeType.ntEXTCARD && c_id > 0)
        {
            System.out.println("WHAT? THERE IS EXACT AXIOM FOUNDED");
        } else
        //CONCEPT
        if(c_nt == NodeType.ntCONCEPT)
        {
            if (!performAddConcept()) return false;
        } else
        //INDIVID
        if(c_nt == NodeType.ntINDIVID)
        {
            if(!performAddIndivid()) return false;
        } else
        //SELF
        if(c_nt == NodeType.ntHASSELF && c_id > 0)
        {
            ////////////////////TODO////////////////////
            if(!performAddSelf()) return false;
        } else
        //THING
        if((c_nt == NodeType.ntTHING && c_id > 0) || (c_nt == NodeType.ntNOTHING && c_id < 0))
        {
        } else
        //NOTHING
        if((c_nt == NodeType.ntNOTHING && c_id > 0) || (c_nt == NodeType.ntTHING && c_id < 0))
        {
            getRecentLevel(queue[IndividID].getToDoDSet()[toDoIndex]);
            return false;
        } else
        //oops!
        {
            System.out.println("THIS IS UNTYPED NODE! (or NOT node...)" + c_nt);
            //что-то пошло' не так...
        }
        queue[IndividID].currentToDo++;
        toDoIndex++;
        return true;
    }
        
    private void remember(Object option, Object lastOption, boolean justAdded, DSet d)
    {
        if(option instanceof ChooseState)
        {
            st1 = 0; st2 = 1; curOr = 0;
        }
        if(option instanceof Pair)
        {
            curOr = 0;
        }
        if(option instanceof Integer)
        {
            st1 = 0; st2 = 1; curChoose = null;
        }
        
        nperfs = new boolean[QSize];
        nskips = new boolean[QSize];
        boolean[] iDV = new boolean[QSize];

        int skpSize = 0;
        for(int i = 0; i < QSize; i++)
        {
            nperfs[skpSize] = queue[i].toDoPerform;
            nskips[skpSize] = queue[i].isSkipped();
            iDV[skpSize] = queue[i].isDataTypeVertice;
            skpSize++;
        }
        
        int[] cToDo = new int[QSize];
        int[] cMQfd = new int[QSize];
        int[] cFAll = new int[QSize];
        for(int i = 0; i < QSize; i++)
        {
            cToDo[i] = queue[i].currentToDo;
            cMQfd[i] = queue[i].currentMQfd;
            cFAll[i] = queue[i].currentFAll;
        }
                
        if(justAdded)
        {
            if(BTSize == MaxBTSize - 1)
                increaseStack();

            DSet D = new DSet(d);
            BTStack[BTSize].set(IndividID, toDoIndex, option, lastOption, QSize, nperfs, nskips, skpSize, curBNum, D, cToDo, cMQfd, cFAll, iDV);
            BTSize++;
            d.addValue(BTSize);
        } else
        {
            DSet D = new DSet(d);
            BTStack[BTSize].set(IndividID, toDoIndex, option, lastOption, QSize, nperfs, nskips, skpSize, curBNum, D, cToDo, cMQfd, cFAll, iDV);
            d.addValue(BTSize);
        }
        curBNum++;
    }
    
    InterpretationNode[] tmp1 = new InterpretationNode[32 * QMaxSize];
    InterpretationNode[] tmp = new InterpretationNode[32 * QMaxSize];
    int[] tmp_wh = new int[32 * QMaxSize];
    private boolean restore(int level, boolean to_start)
    {
        //to_start = false;
        //if(use_global_caching)
        {
            //neg_cache.neg_add(queue[IndividID]);
        }
        stats.restoreCountAdd();
        int count = 0;
        int last_individ_id = IndividID;
        
        BTSize = level;
        
        for(int i = BTSize - 1; i >= 0; i--)
        {
            if(!BTStack[i].isLastOption() || to_start)
            {
                BTSize -= count;
                level = BTSize;
                
                //set individID and toDoIndex of this individ
                IndividID = BTStack[i].IndividID; newIndividID = IndividID + 1;
                toDoIndex = BTStack[i].toDoIndex;
                curBNum = BTStack[i].curBNum;
                //set current or alternative
                if(!to_start)
                {
                    if(BTStack[i].option instanceof Integer)
                    {
                        curOr = ((Integer) BTStack[i].option) + 1;
                        BTStack[i].option = curOr;
                        BTStack[i].context.mergeWith(conflictDSet);
                        curDS = BTStack[i].context;
                    } else
                    if(BTStack[i].option instanceof Pair)
                    {
                        st1 = ((Pair)BTStack[i].option).st1;
                        st2 = ((Pair)BTStack[i].option).st2 + 1;
                        if(st2 >= (Integer)BTStack[i].lastOption)
                        {
                            st1++;
                            st2 = st1 + 1;
                        }
                        ((Pair)BTStack[i].option).st1 = st1;
                        ((Pair)BTStack[i].option).st2 = st2;
                        BTStack[i].context.mergeWith(conflictDSet);
                        curDS = BTStack[i].context;
                    }
                    if(BTStack[i].option instanceof ChooseState)
                    {
                        st1 = 0;
                        st2 = 1;
                        curChoose = new ChooseState(((ChooseState)BTStack[i].option).notC, ((ChooseState)BTStack[i].option).ai);
                    }
                }

                int old_queue_size = QSize;
                int tmp_cnt = 0, tmp_cnt1 = 0;

                int OQSize = QSize - (old_queue_size - BTStack[i].queueSize);
                
                //кроме текущего рассматриваемого индивида будут добавлены все его предки с минимальный набором ToDo
                /*while(last_individ_id > OQSize)
                {
                    neg_cache.neg_add(queue[last_individ_id]);
                    if(queue[last_individ_id].getParents()[0] == null) break;
                    last_individ_id = queue[last_individ_id].getParents()[0].getNode().indexInQueue; //индекс предка в очереди, движемся только по первым предкам
                }*/
                
                for(int j = 0; j < old_queue_size; j++)
                {
                    if(whqueue[j] < level)
                    {
                        tmp_wh[tmp_cnt] = whqueue[j];
                        tmp[tmp_cnt++] = queue[j];
                    } else
                    {
                        tmp1[tmp_cnt1++] = queue[j];
                        //if(!queue[j].isSkipped()) ???
                        {
                            for(int k = 0; k < queue[j].getIndsSize(); k++)
                            {
                                a_box.clearIndivid(queue[j].getInds()[k]);
                            }
                        }
                    }
                }

                for(int j = 0; j < tmp_cnt; j++)
                {
                    whqueue[j] = tmp_wh[j];
                    queue[j] = tmp[j];
                    queue[j].indexInQueue = j;
                }
                for(int j = 0; j < tmp_cnt1; j++)
                {
                    queue[tmp_cnt + j] = tmp1[j];
                    queue[tmp_cnt + j].indexInQueue = tmp_cnt + j;
                }

                QSize -= (old_queue_size - BTStack[i].queueSize);
                for(int j = 0; j < QSize; j++)
                {
                    queue[j].restore(BTStack[i].toDoPerfs[j], level, BTStack[i].curToDo[j], BTStack[i].curMQfd[j], BTStack[i].curFAll[j], BTStack[i].isDV[j]);
                    queue[j].setSkip(BTStack[i].skips[j]);
                    for(int h = 0; h < queue[j].getIndsSize(); h++)
                    {
                        a_box.setNode(a_box.find(queue[j].getInds()[h]), queue[j]);
                    }
                    queue[j].setBlock(-1);
                }
                return true;
            }
            count++;
        }
        return false;
    }
    
    private void getRecentLevel(DSet d)
    {
        conflictDSet = new DSet(d);
        
        if(conflictDSet.size() > 0)
            while(BTStack[conflictDSet.getValues()[conflictDSet.size() - 1] - 1].isLastOption())
            {
                conflictDSet.pop();
                if(conflictDSet.size() == 0) break;
            }
        
        int[] a = d.getValues();
        curLevel = BTSize;
        
        if(a.length == 0)
        {
            curLevel = 0; return;
        }
        
        if(!use_back_jump)
        {
            for(int i = BTSize - 1; i >= 0; i--)
            {
                if(!BTStack[i].isLastOption())
                {
                    curLevel = i + 1;
                    return;
                }
            }
        } else
        {
            curLevel = a[a.length - 1];
            for(int i = a.length - 1; i >= 0; i--)
            {
                if(!BTStack[a[i] - 1].isLastOption())
                {
                    curLevel = a[i];
                    return;
                }
            }
            curLevel = 0;
            return;
        }
        
        curLevel = BTSize - 1;
        if(curLevel < 0) curLevel = 0;
    }
    
    
    private boolean isCorrectData(InterpretationNode data_node)
    {
        boolean res = true;
        IntArray toDoCopy = new IntArray();
        toDoCopy.clear();
        for(int i = 0; i < data_node.getToDoSize(); i++)
            toDoCopy.add(data_node.getToDo()[i]);

        res = data_checker.getDataCheck(toDoCopy);
        
        if(!res)
        {
            DSet D = new DSet();
            for(int i = 0; i < data_node.getToDoSize(); i++)
                D.mergeWith(data_node.getToDoDSet()[i]);
            getRecentLevel(D);
        }
        return res;
    }
    
    private boolean backTrack(int IndID)
    {
        IndividID = IndID;
        if(!a_box_reuse)
            BTSize = 0;
        curOr = 0;
        curChoose = null;
        curLevel = 0;
        newIndividID = 1;
        st1 = 0;
        st2 = 1;
        boolean neg_skip = false;
        long sat_time = System.currentTimeMillis();
        while(true)
        {
            //System.out.println(QSize + " " + BTSize + " " + IndividID);
            if(neg_cache.getSize() >= (1 << 7)) neg_cache.clear();            
            toDoIndex = queue[IndividID].currentToDo; //для каждой вершины интерпретации определена переменная currentToDo в которой хранится номер текущего обрабатываемого toDo
            neg_skip = false;
            if(System.currentTimeMillis() - sat_time >= sec_millis) //если таймлимит вышел - все конец
            {
                if(show_stats) stats.printStats();
                return false;
            }
            if(QSize <= IndividID) //если в очереди обработаны все индивиды, значит построена корректная интерпретация
            {
                for(int it = 0; it < QSize; it++)
                {
                    if(class_mode)
                    {
                        for(int j = 0; j < queue[it].getToDoSize(); j++)
                        {
                            RuleNode rn1 = t_box.getRuleGraph().getNode(UF.ABS(queue[it].getToDo()[j]));
                            if(rn1.getNodeType() != NodeType.ntCONCEPT) continue;
                            for(int k = j + 1; k < queue[it].getToDoSize(); k++)
                            {
                                RuleNode rn2 = t_box.getRuleGraph().getNode(UF.ABS(queue[it].getToDo()[k]));
                                if(rn2.getNodeType() != NodeType.ntCONCEPT) continue;
                                if(queue[it].getToDo()[j] > 0 && queue[it].getToDo()[k] < 0)
                                {                                
                                    int cid1 = t_box.getRuleGraph().getConceptID(rn1.getName());
                                    int cid2 = t_box.getRuleGraph().getConceptID(rn2.getName());
                                    no_sub_sum[cid1].add(cid2);
                                } else
                                if(queue[it].getToDo()[j] < 0 && queue[it].getToDo()[k] > 0)
                                {
                                    int cid1 = t_box.getRuleGraph().getConceptID(rn1.getName());
                                    int cid2 = t_box.getRuleGraph().getConceptID(rn2.getName());
                                    no_sub_sum[cid2].add(cid1);
                                }
                            }
                        }
                    }
                    
                    if(use_global_caching) pos_cache.add(queue[it]); //добавим всю интерпретацию в кэш
                }
                return true;
            } 

            if(queue[IndividID].isDataTypeVertice)
            {
                if(!isCorrectData(queue[IndividID])) //написать обработчик DataVertice
                {
                    if(!restore(curLevel, false))
                    {
                        break;
                    } else
                    {
                        continue;
                    }
                }
                queue[IndividID].currentToDo = queue[IndividID].getToDoSize();
                IndividID = newIndividID; //переходим к нужной вершине в очереди
                newIndividID = IndividID + 1; //увеличиваем указатель на вершину на 1
                continue;
            }            
            
            if(queue[IndividID].currentToDo == 0 && queue[IndividID].toDoPerform) //кэшируем ветку только тогда когда она СРАЗУ ЖЕ только что закончилась
                if(IndividID > 0 && queue[IndividID - 1].getChildSize() == 0) //если мы обработали полностью одну из ветвей интерпретации и она satisfiable то её можно cache
                {
                    //если у предыдущего индивида нет потомков тогда нужно обработать всех его предков, 
                    //у которых нет потомков дальше чем рассматриваемый узел в интерпретации
                    //Arrays.fill(dfs_f, 0);
                    if(use_global_caching) posCacheUpdate(queue[IndividID - 1], IndividID, 0); 
                }

            if(queue[IndividID].currentToDo == 0 && queue[IndividID].toDoPerform) //проверяем есть ли данная вершина в положительном кэше тогда и только тогда когда начинается её обработка
                if(use_global_caching && IndividID != 0) if(pos_cache.find(queue[IndividID])) //если в global caching есть вершина с таким же набором toDo значит мы уже обрабатывали её и она sat значит эту ветвь можно пропустить
                {
                    queue[IndividID].currentToDo = queue[IndividID].getToDoSize();
                    IndividID = newIndividID; //переходим к нужной вершине в очереди
                    newIndividID = IndividID + 1; //увеличиваем указатель на вершину на 1
                    continue;
                }
            if(queue[IndividID].currentToDo == 0 && queue[IndividID].toDoPerform) //вспомогательный if, который срабатывает только тогда когда вершина интерпретации только начинает обрабатываться
            {
                if(graph.makeBlocked(queue[IndividID], queue, IndividID)) //if this node is blocked - not add children
                {
                    queue[IndividID].currentToDo = queue[IndividID].getToDoSize();
                    IndividID = newIndividID; //переходим к нужной вершине в очереди
                    newIndividID = IndividID + 1; //увеличиваем указатель на вершину на 1
                    continue;
                }
                //System.out.println(IndividID + " " + QSize + " " + BTSize + " " + queue[IndividID].getToDo()[0] + " " + pos_cache.getSize() + " " + neg_cache.getSize());
                queue[IndividID].origToDoWhen = 0;
                for(int i = 0; i < queue[IndividID].getToDoSize(); i++)
                {
                    if( queue[IndividID].origToDoWhen < queue[IndividID].getToDoWhen()[i])
                        queue[IndividID].origToDoWhen = queue[IndividID].getToDoWhen()[i];
                }
            }
            //if(queue[IndividID].currentToDo == 0 && queue[IndividID].toDoPerform) //проверяем есть ли данная вершина в отрицательном кэше тогда и только тогда когда начинается её обработка // а верно ли это ?
                if(use_global_caching) 
                    if(neg_skip || neg_cache.neg_find(queue[IndividID])) //если в neg cache содержит вершину с таким же toDoList то можно делать jump назад
                    {
                        DSet new_d_set = new DSet();
                        for(int i = 0; i < queue[IndividID].getToDoSize(); i++)
                        {
                            new_d_set.mergeWith(queue[IndividID].getToDoDSet()[i]);
                        }
                        getRecentLevel(new_d_set);
                        if(!restore(curLevel, false))
                        {
                            break;
                        } else
                        {
                            continue;
                        }
                    }
            if(queue[IndividID].isSkipped()) //vertice can be skipped when it merged with another one or when it blocked
            {
                queue[IndividID].currentToDo = queue[IndividID].getToDoSize();
                IndividID = newIndividID; //goto needed vertice in queue
                newIndividID = IndividID + 1; //increase iterator by 1
                continue;
            }
            
            if(!queue[IndividID].toDoPerform) //если не выполняем toDo, тогда выполянем MQFd
            {
                if(queue[IndividID].getMQfdSize() > queue[IndividID].currentMQfd) //если в MQfdToDo что-то содержится
                {
                    if(!makeDecrease())
                        if(!restore(curLevel, false))
                        {
                            break;
                        } else
                        {
                            continue;
                        }
                    
                    queue[IndividID].currentMQfd++;
                    continue;
                } else 
                {
                    queue[IndividID].currentToDo = queue[IndividID].getToDoSize();
                    IndividID = newIndividID; //переходим к нужной вершине в очереди
                    newIndividID = IndividID + 1; //увеличиваем указатель на вершину на 1
                    continue;
                }
            } else
            if(queue[IndividID].getToDoSize() <= queue[IndividID].currentToDo) //если выполнены все toDo для текущей вершины
            {
                if(graph.makeBlocked(queue[IndividID], queue, IndividID)) //if this node is blocked - not add children
                {
                    queue[IndividID].currentToDo = queue[IndividID].getToDoSize();
                    IndividID = newIndividID; //переходим к нужной вершине в очереди
                    newIndividID = IndividID + 1; //увеличиваем указатель на вершину на 1
                    continue;
                } else
                {
                    queue[IndividID].toDoPerform = false;
                    makeIncrease(); //if node isn't blocked then add all children
                    continue;
                }
            }

            if(!updateToDo()) //perform ToDoEntry in toDoIndex
            {
                if(!restore(curLevel, false))
                {
                    break;
                }
            }
        }
        
        //обновление neg_cahce только тогда когда концепт вообще не выполним
        //if(use_global_caching) //neg_cache можно использовать всегда
        if(false)
        {
            InterpretationNode node = queue[IndividID];
            while(true)
            {
                node.indexInQueue = -1;
                neg_cache.neg_add(node); //должен быть добавлен минимальный набор концептов из ToDoList, который влечет UNSAT
                if(node.getParentSize() > 0)
                {
                    node = node.getParents()[0].getNode();
                    if(node.indexInQueue < 0) break;
                } else break;
            }
        }
        
        return false;
    }

    ////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////
    
    public AChecker getAChecker()
    {
        return a_checker;
    }
        
    public boolean isSat(int rtn)
    {
        QSize = 0;
        BTSize = 0;
        InterpretationNode current_node = addNewIndivid(null, -1, rtn, null, -1, false);
        roots.add(current_node);
        return backTrack(QSize - 1);
    }

    public boolean checkSubsumption(int p, int q)
    {
        if(!a_box_reuse)
        {
            QSize = 0;
            BTSize = 0;
            a_box.clearNodes();
        }
        //System.out.println(QSize + " " + BTSize);
        InterpretationNode current_node = addNewIndivid(null, -1, p, null, QSize, false);
        if(q != 0)
            current_node.addToDo(-q, new DSet(), BTSize, t_box);

        roots.add(current_node);
        
        stats.clear();
        boolean reslt = backTrack(0);
        if(!reslt)
        {
            //System.out.println(QSize);
            //stats.printStats();
            
            //add concept(q) to description of concept(p)
            
            //t_box.getRuleGraph().addToSubDesciption(p, q);
            if(a_box_reuse)
                checkABoxSat(true);
            return true;
        } else
        {
            if(a_box_reuse)
                restore(1, true);
        }
        
        //System.out.println(QSize);
        //stats.printStats();
        //queue[0].show(r_box, t_box);
        return false;
    }
    
    public boolean checkSubsumption(String ps, String qs)
    {
        //System.out.println(ps + " " + qs);
        int p_ind = t_box.getRuleGraph().getConceptID(ps);
        int q_ind = t_box.getRuleGraph().getConceptID(qs);
        if(     ps.equals("http://cohse.semanticweb.org/ontologies/people#haulagetruckdriver") &&
                qs.equals("http://cohse.semanticweb.org/ontologies/people#driver"))
        {
            int kor = 124;
        }

        int p = t_box.getRuleGraph().findConcept(ps);
        int q = t_box.getRuleGraph().findConcept(qs);
        
        if(cache[0][p_ind] != null) if(cache[0][p_ind].getSize() == -1) return true;
        if(cache[1][q_ind] != null) if(cache[1][q_ind].getSize() == -1) return true;

        if(cache[0][p_ind] != null && cache[1][q_ind] != null)
        {
            if(cache[0][p_ind].canMerge(cache[1][q_ind], r_box, t_box, cache) && use_caching)
            {
                return false;
            }
        }

        if(no_sub_sum != null) if(no_sub_sum[p_ind] != null) if(no_sub_sum[p_ind].contain(q_ind)) return false;

        boolean ABL = true;
        if(use_a_checker)
        {
            a_checker.total_count++;
            ABL = a_checker.isDisjoint(p, -q, null);
            if(ABL)
            {
                a_checker.true_count++;
                return true;
            }
            //return false;
        }
        boolean res = checkSubsumption(p, q);
        if(!res)
        {
            //queue[0].show(r_box, t_box);
            if(no_sub_sum != null) if(no_sub_sum[p_ind] != null) no_sub_sum[p_ind].add(q_ind);
        } else
        {
            if(!ABL)
            {
                int kor = 123;
            }
        }
        return res;
    }
    
    public void checkQuery(Query q)
    {
        QSize = 0;
        for(int j = 0; j < a_box.getCount(); j++)
        {
            whqueue[QSize] = 0;
            a_box.createNode(a_box.getName(j), new DSet(), queue[QSize], t_box);
            queue[QSize].indexInQueue = QSize;
            QSize++;
        }
        int old_QS = QSize;
        a_box.realizeRelations(r_box, 0);
        //check individual instance
        for(int i = 0; i < q.getIndividualInstanceSize(); i++)
        {
            for(int j = 0; j < old_QS; j++)
            {
                queue[j].restore(true, 1, 0, 0, 0, false);
            }
            QSize = old_QS;
            
            a_box.getNode(q.getIndividualInstance(i).x).addToDo(-q.getIndividualInstance(i).y, new DSet(), 0, t_box);
            pos_cache.clear();
            neg_cache.clear();
            if(!backTrack(0))
            {
                System.out.println(a_box.getName(q.getIndividualInstance(i).x) + " is " + t_box.getRuleGraph().getNode(q.getIndividualInstance(i).y).getName());
            } else
            {
                System.out.println(a_box.getName(q.getIndividualInstance(i).x) + " is NOT " + t_box.getRuleGraph().getNode(q.getIndividualInstance(i).y).getName());
            }
            a_box.getNode(q.getIndividualInstance(i).x).popToDo();
        }
    }
        
    public boolean checkABoxSat(boolean all)
    {
        QSize = 0;
        BTSize = 0;
        a_box.clearNodes();
        if(all)
        {
            for(int i = 0; i < a_box.getCount(); i++)
            {
                InterpretationNode cur_node = addNewIndivid(null, -1, 0, new DSet(), -1, false);
                a_box.createNodeFast(i, cur_node);
            }
        }
        a_box.realizeRelations(r_box, 0);
        remember(0, 0, true, new DSet());
        if(!backTrack(0))
        {
            return false;
        } else
        {
        }
        restore(1, true);
        return true;
    }
    
    public boolean checkSat(String ps, boolean show_model, int negt, int conc_id)
    {
        if(ps.equals("http://modelosenegocios.goodglecode.com/svn/trunk/tp3/tp3.owl#TipoFilaAcuerdo"))
        {
            int kor = 123;
        }
        //if negt == 1 ps = NOT ps, else if negt = 0 ps = ps; else nothing to cache
        BTSize = 0;
        QSize = 0;
        a_box.clearNodes();        
        int c_id = t_box.getRuleGraph().findConcept(ps);
        if(negt == 1) c_id = -c_id;
        InterpretationNode current_node = addNewIndivid(null, -1, c_id, null, -1, false);
        roots.add(current_node);

        stats.clear();
        long sat_time = System.currentTimeMillis();
        if(!backTrack(0))
        {
            if(show_model) current_node.show(r_box, t_box);
            if(System.currentTimeMillis() - sat_time < sec_millis)
            {
                if(negt < 2)
                {
                    cache[negt][conc_id] = new Cache(); //empty cache
                    cache[negt][conc_id].setSize(-1);
                }
            } else
            {
                //nothing to cache
            }
            //stats.printStats();
            return false;
        } else
        {
            if(negt < 2)
                cache[negt][conc_id] = getCache(0); //non-empty cache
        }
        if(show_model)
        {
            //stats.printStats();
            current_node.show(r_box, t_box);
        }
        return true;
    }
    
    public boolean checkSat(int[] a, int size)
    {
        BTSize = 0;
        QSize = 0;
        a_box.clearNodes();
        InterpretationNode current_node = addNewIndivid(null, -1, a[0], null, -1, false);
        for(int i = 1; i < size; i++)
        {
            current_node.addToDo(a[i], new DSet(), 0, t_box);
        }
        roots.add(current_node);

        long sat_time = System.currentTimeMillis();
        if(!backTrack(0))
        {
            if(System.currentTimeMillis() - sat_time < sec_millis)
            {
            } else
            {
            }
            return false;
        } else
        {
        }
        return true;
    }
    
    public boolean checkALCTBoxSat(boolean showModel, boolean show_log)
    {
        int sats = 0, unsats = 0;
        System.out.println("TBOX CONSISTENT CHECKING...");
        flag.clear();
        conc = new boolean[1024 * 1024];
                
        for(int i = 0; i < 1024 * 1024; i++)
            conc[i] = false;
     
        for(int i1 = 0; i1 < t_box.getOrder().size(); i1++)
        {
            int i = t_box.getOrder().get(i1);
            if(!conc[i])
            {
                QSize = 0;
                int c_id = t_box.getRuleGraph().findConcept(t_box.getRuleGraph().getConcepts().get(i));
                BTSize = 0;
                InterpretationNode current_node = addNewIndivid(null, -1, c_id, null, -1, false);
                roots.add(current_node);
                stats.clear();
                pos_cache.clear();
                neg_cache.clear();
                long sat_time = System.currentTimeMillis();

                t_box.getRuleGraph().clearCacheClasses();
                if(t_box.getRuleGraph().getNode(UF.ABS(c_id)).getNodeType() == NodeType.ntCONCEPT)
                {
                    if(t_box.getRuleGraph().getNode(UF.ABS(c_id)).getDescription() != 0)
                        aut.labelTree(t_box.getRuleGraph().getNode(UF.ABS(c_id)).getDescription());
                } else
                {
                    aut.labelTree(c_id);
                }
                
                if(!backTrack(QSize - 1))
                {
                    if(System.currentTimeMillis() - sat_time < sec_millis)
                    {
                        if(show_log) System.out.print(t_box.getRuleGraph().getConcepts().get(i) + " is unsatisfiable\n");
                    } else
                    {
                        break;
                    }
                    if(t_box.getRuleGraph().getConcepts().get(i).startsWith("My"))
                        unsats++;
                } else
                {
                    if(t_box.getRuleGraph().getConcepts().get(i).startsWith("My")) if(show_log) System.out.print(t_box.getRuleGraph().getConcepts().get(i) + " is Satisfiable\n");
                    if(t_box.getRuleGraph().getConcepts().get(i).startsWith("My"))
                    {
                        sats++;
                    }
                }
                queueClear();
                if(showModel) current_node.show(r_box, t_box);
            }
        }
        System.out.println("SAT TOTAL:   " + sats);
        System.out.println("UNSAT TOTAL: " + unsats);
        return true;
    }
    
    int[] f = null;
    public void printTaxonomy(int x, String prefix, Set<OWLSubClassOfAxiom> tx)
    {
        if(f[x] == 1) return;
        f[x] = 1;
        if(x == t_box.getRuleGraph().getConcepts().size() + 1)
        {
            //System.out.println(prefix + t_box.getRuleGraph().getThingString());
        } else
        {
            //System.out.println(prefix + t_box.getRuleGraph().getConcepts().get(x));
        }
        if(sup[x] != null)
            for(int i = 0; i < sup[x].size(); i++)
            {
                OWLClass clsSUP = null;
                OWLClass clsSUB = null;
                if(sup[x].get(i) >= t_box.getRuleGraph().getConcepts().size() + 1) //this is BOTTOM concept
                {
                    continue; //it is not necessary to add BOTTOM [= X axiom
                } else
                {
                    clsSUB = df.getOWLClass(IRI.create(t_box.getRuleGraph().getConcepts().get(sup[x].get(i))));
                }
                if(x == t_box.getRuleGraph().getConcepts().size() + 1)
                {
                    clsSUP = df.getOWLThing();
                } else
                {
                    clsSUP = df.getOWLClass(IRI.create(t_box.getRuleGraph().getConcepts().get(x)));
                }
                
                if(cache[0][sup[x].get(i)] != null) if(cache[0][sup[x].get(i)].getSize() != -1)
                {
                    OWLSubClassOfAxiom ax = df.getOWLSubClassOfAxiom(clsSUB, clsSUP);
                    tx.add(ax);
                    //AddAxiom addAxiom = new AddAxiom(Ontology, ax);
                    //manager.applyChange(addAxiom);
                } else
                {
                    OWLSubClassOfAxiom ax = df.getOWLSubClassOfAxiom(clsSUB, df.getOWLNothing());
                    tx.add(ax);
                    //AddAxiom addAxiom = new AddAxiom(Ontology, ax);
                    //manager.applyChange(addAxiom);                    
                }
                
                printTaxonomy(sup[x].get(i), prefix + "  ", tx);
            }
    }
    
    OWLOntology Ontology = null;
    OWLDataFactory df = null;
    OWLOntologyManager manager = null;
        
    int[] mark = null;
    private boolean simpleTopSubs(int y, int c)
    {
        if(mark[y] == 1)
        {
            return true;
        } else
        if(mark[y] == -1)
        {
            return false;
        }
        
        if(y == t_box.getRuleGraph().getConcepts().size() + 2) return true; //y is BOTTOM
        if(y == t_box.getRuleGraph().getConcepts().size() + 1) return false; //y is TOP
        if(c == t_box.getRuleGraph().getConcepts().size() + 2) return false; //c is BOTTOM //return !checkSat(y)
        if(c == t_box.getRuleGraph().getConcepts().size() + 1) return true; //c is TOP
        
        //enhanced top search
        /*for(int i = 0; i < sub[y].size(); i++)
        {
            int z = sub[y].get(i);
            if(!simpleTopSubs(z, c))
            {
                mark[y] = -1;
                return false;
            }
        }*/
        
        if(checkSubsumption(
                t_box.getRuleGraph().getConcepts().get(c), 
                t_box.getRuleGraph().getConcepts().get(y)))
        {
            mark[y] = 1;
            return true;
        } else
        {
            mark[y] = -1;
            return false;
        }
    }
    
    private boolean simpleBottomSubs(int y, int c)
    {
        if(mark[y] == 1)
        {
            return true;
        } else
        if(mark[y] == -1)
        {
            return false;
        }
        
        if(c == t_box.getRuleGraph().getConcepts().size() + 2) return true; //y is BOTTOM
        if(c == t_box.getRuleGraph().getConcepts().size() + 1) return false; //y is TOP
        if(y == t_box.getRuleGraph().getConcepts().size() + 2) return false; //c is BOTTOM //return !checkSat(y)
        if(y == t_box.getRuleGraph().getConcepts().size() + 1) return true; //c is TOP

        /*for(int i = 0; i < sub[c].size(); i++)
        {
            int z = sub[c].get(i);
            if(!simpleBottomSubs(y, z))
            {
                mark[y] = -1;
                return false;
            }
        }*/
        
        if(checkSubsumption(
                t_box.getRuleGraph().getConcepts().get(y),
                t_box.getRuleGraph().getConcepts().get(c)))
        {
            mark[y] = 1;
            return true;
        } else
        {
            mark[y] = -1;
            return false;
        }
    }
    
    boolean[] visited = null;
    private IntArray topSearch(int c, int x)
    {
        visited[x] = true;
        IntArray ret = new IntArray();
        IntArray succ = new IntArray();
        //it is known that c [= x
        //check x [= c
        if(x != t_box.getRuleGraph().getConcepts().size() + 1)
            if(checkSubsumption(
                t_box.getRuleGraph().getConcepts().get(x),
                t_box.getRuleGraph().getConcepts().get(c))) //x equal to c
            {
                return new IntArray();
            }
        
        for(int i = 0; i < sup[x].size(); i++)
        {
            if(sup[x].get(i) == t_box.getRuleGraph().getConcepts().size() + 2) continue;
            if(simpleTopSubs(sup[x].get(i), c))
            {
                succ.addOnce(sup[x].get(i));
            }
        }
        if(succ.size() == 0)
        {
            ret.add(x);
            return ret;
        } else
        {
            for(int i = 0; i < succ.size(); i++)
            {
                if(!visited[succ.get(i)])
                {
                    IntArray res = topSearch(c, succ.get(i));                    
                    ret.addOnce(res);
                }
            }
            if(ret.size() == 0) ret.add(x);
            return ret;
        }
    }
    
    private IntArray bottomSearch(int c, int x)
    {
        visited[x] = true;
        IntArray ret = new IntArray();
        IntArray pred = new IntArray();
        //it is known that x [= c
        //check c [= x
        if(x != t_box.getRuleGraph().getConcepts().size() + 2)
            if(checkSubsumption(
                    t_box.getRuleGraph().getConcepts().get(c),
                    t_box.getRuleGraph().getConcepts().get(x))) //x equal to c
            {
                return sup[x];
            }
        for(int i = 0; i < sub[x].size(); i++)
        {
            if(sub[x].get(i) == t_box.getRuleGraph().getConcepts().size() + 1) continue;
            if(simpleBottomSubs(sub[x].get(i), c))
            {
                pred.addOnce(sub[x].get(i));
            }
        }
        if(pred.size() == 0)
        {
            ret.add(x);
            return ret;
        } else
        {
            for(int i = 0; i < pred.size(); i++)
            {
                if(!visited[pred.get(i)])
                {
                    ret.add(bottomSearch(c, pred.get(i)));
                }
            }
            return ret;
        }
    }
    
    int delete_mark[] = null;
    private boolean findPath(int x, int y)
    {
        if(delete_mark[x] == 1) return false;
        delete_mark[x] = 1;
        for(int i = 0; i < sup[x].size(); i++)
        {
            if(sup[x].get(i) == y) return true;
            if(findPath(sup[x].get(i), y)) return true;
        }
        return false;
    }
    IntArray toDelete = new IntArray();
    private void deleteUnsign(int c)
    {
        delete_mark = new int[t_box.getRuleGraph().getConcepts().size() + 4];
        toDelete.clear();
        for(int i = 0; i < sup[c].size(); i++)
        {
            int h = sup[c].get(i);
            for(int j = 0; j < sup[c].size(); j++)
            {
                Arrays.fill(delete_mark, 0);
                if(findPath(sup[c].get(j), h))
                {
                    toDelete.add(sup[c].get(i));
                }
            }
        }
        for(int i = 0; i < toDelete.size(); i++)
        {
            int z = toDelete.get(i);
            sup[c].delete(z);
            sub[z].delete(c);
        }
    }
    
    //Franz Baader, Bernhard Hollunder, Bernhard Nebel, Hans-Jurgen Profitlich. 
    //An empirical analysis of optimization techniques for terminological representation systems.
    private boolean traversalClassification(long beg_time, long timelimit)
    {
        //need to load all ABox to queue and reason it, then make traversal classification
        if(a_box_reuse)
            checkABoxSat(true);

        //sub[IT] contains all super concepts of IT
        //sup[IT] contains all sub concepts of IT
        int N = t_box.getOrder().size(); //count of all concepts
        visited = new boolean[N + 4];
        mark = new int[N + 4];
        
        //N + 1 is TOP concept
        //N + 2 is bottom concept
        sup[N + 1] = new IntArray();
        sup[N + 2] = new IntArray();
        sub[N + 1] = new IntArray();
        sub[N + 2] = new IntArray();

        for(int i = 0; i < N; i++)
        {
            //TOP is super concept for all concepts
            if(sup[i] == null) sup[i] = new IntArray();
            if(sub[i] == null) sub[i] = new IntArray();
            
            sup[N + 1].add(i);
            sub[i].add(N + 1);
            
            //BOTTOM is sub concept for all concepts
            sub[N + 2].add(i);
            sup[i].add(N + 2);
        }
        
        //System.out.println(N);
        for(int i = 0; i < N; i++)
        {
            //System.out.println(i + " " + t_box.getRuleGraph().getConcepts().get(i));
            if(System.currentTimeMillis() - beg_time > timelimit)
            {
                return false;
            }
            //there is taxonomy of all first i concepts
            //add concept with number i to taxonomy
            //Top Search Phase
            Arrays.fill(visited, false);
            Arrays.fill(mark, 0);
            long ttt = System.currentTimeMillis();
            IntArray res = topSearch(i, N + 1);
            //System.out.println(System.currentTimeMillis() - ttt);
            //res contains all super concepts for i-concept
            //очистка кэша только тогда когда его он заполнится 2^7 элементами
            if(use_global_caching) if(pos_cache.getSize() >= (1 << 7)) 
                pos_cache.clear();
            if(use_global_caching) //if(neg_cache.getSize() >= (1 << 8)) 
                neg_cache.clear();

            for(int j = 0; j < sub[i].size(); j++)
            {
                sup[sub[i].get(j)].delete(i);
            }
            sub[i].clear();
            
            for(int j = 0; j < res.size(); j++)
            {
                sub[i].addOnce(res.get(j));
                sup[res.get(j)].addOnce(i);
            }
        }
        for(int i = 0; i < N; i++)
        {
            //System.out.println(i + " " + t_box.getRuleGraph().getConcepts().get(i));
            if(System.currentTimeMillis() - beg_time > timelimit)
            {
                return false;
            }
            //there is taxonomy of all first i concepts
            //add concept with number i to taxonomy
            //Bottom Search Phase
            Arrays.fill(visited, false);
            Arrays.fill(mark, 0);
            IntArray res = bottomSearch(i, N + 2);
            //очистка кэша только тогда когда его он заполнится 2^7 элементами
            if(use_global_caching) if(pos_cache.getSize() >= (1 << 7)) 
                pos_cache.clear();
            if(use_global_caching) //if(neg_cache.getSize() >= (1 << 8)) 
                neg_cache.clear();

            for(int j = 0; j < sup[i].size(); j++)
            {
                sub[sup[i].get(j)].delete(i);
            }
            sup[i].clear();
            
            for(int j = 0; j < res.size(); j++)
            {
                sup[i].addOnce(res.get(j));
                sub[res.get(j)].addOnce(i);
            }
        }      
        return true;
    }
    
    public Set<OWLSubClassOfAxiom> classifyTBox(boolean showModel, IRI filename, long timelimit) throws FileNotFoundException, OWLOntologyCreationException, OWLOntologyStorageException
    {
        class_mode = true;

        concept_count = t_box.getRuleGraph().getConcepts().size();
        
        sub = new IntArray[concept_count + 4];
        sup = new IntArray[concept_count + 4];

        //check sat of each concept and its negation
        long beg_time = System.currentTimeMillis();
        
        no_sub_sum = new HashContainer[concept_count + 1];
        for(int i = 0; i < concept_count; i++)
        {
            no_sub_sum[i] = new HashContainer();
        }
        
        a_checker.true_count = 0;
        a_checker.total_count = 0;
        for(int i1 = 0; i1 < concept_count; i1++)
        {
            int i = t_box.getOrder().get(i1);
            boolean pos_res = checkSat(t_box.getRuleGraph().getConcepts().get(i), showModel, 0, i);
            boolean neg_res = checkSat(t_box.getRuleGraph().getConcepts().get(i), showModel, 1, i);
        }
        if(false)
        {
            System.out.println(System.currentTimeMillis() - beg_time);
            System.out.println(a_checker.true_count + " " + a_checker.total_count);
            return null;
        }
        if(System.currentTimeMillis() - beg_time > timelimit)
        {
            class_mode = false;
            return null;
        }
        
        a_checker.true_count = 0;
        a_checker.total_count = 0;
        if(!traversalClassification(beg_time, timelimit))
        {
            return null;
        }
        System.out.println("CLASSIFICATION TIME: " + (System.currentTimeMillis() - beg_time));
        
        f = new int[t_box.getRuleGraph().getConcepts().size() + 4];
        for(int i = 0; i < t_box.getRuleGraph().getConcepts().size(); i++)
        {
            if(i == t_box.getRuleGraph().getConcepts().size()) continue;
            deleteUnsign(i);
        }
        HashSet<OWLSubClassOfAxiom> tax = new HashSet<OWLSubClassOfAxiom>();
        df = OWLManager.getOWLDataFactory();
        printTaxonomy(t_box.getRuleGraph().getConcepts().size() + 1, "", tax);
        if(filename != null)
        {
            manager = OWLManager.createOWLOntologyManager();
            Ontology = manager.createOntology(filename);
            for(OWLSubClassOfAxiom sca: tax)
            {
                AddAxiom addAxiom = new AddAxiom(Ontology, sca);
                manager.applyChange(addAxiom);
            }
            manager.saveOntology(Ontology);
        }
        
        class_mode = false;
        return tax;
    }
    
    public Cache getCache(int x)
    {
        Cache ret = new Cache();
        for(int i = 0; i < queue[x].getToDoSize(); i++)
            ret.add(queue[x].getToDo()[i]);
        return ret;
    }
    
    private int dfs_f[] = new int[1 << 20];
    private boolean DFS(InterpretationNode in, int depth)
    {
        if(depth > 100) return false;
        //if(dfs_f[in.indexInQueue] == -1) return false;
        //if(dfs_f[in.indexInQueue] ==  1) return true;
        dfs_f[in.indexInQueue] = 2;

        if(in.currentToDo < in.getToDoSize())
        {
            dfs_f[in.indexInQueue] = -1;
            return false;
        }
        for(int i = 0; i < in.getChildSize(); i++)
        {
            //if(dfs_f[in.getChildren()[i].getNode().indexInQueue] != 0) continue;
            if(!DFS(in.getChildren()[i].getNode(), depth + 1))
            {
                dfs_f[in.indexInQueue] = -1;
                return false;
            }
            
        }
        dfs_f[in.indexInQueue] = 1;
        return true;
    }
    
    private void posCacheUpdate(InterpretationNode in, int ind_id, int dpth)
    {
        if(in.isSkipped()) return;
        if(!DFS(in, 0)) return;
        for(int i = 0; i < in.getChildSize(); i++)
        {
            if(in.getChildren()[i].getNode().indexInQueue >= ind_id)
            {
                return;
            } 
            if(in.getChildren()[i].getNode().getChildSize() > 0)
            {
                return;
            }
            //если какой-либо потомок данной вершины есть в очереди за рассматриваемым элементом или у него есть потомки тогда не рассматриваем его, 
            //то не рассматриваем его
        }
        for(int i = 0; i < in.getParentSize(); i++)
        {
            if(in.getParents()[i].getNode().indexInQueue >= ind_id)
            {
                return;
            }
            
        }
        pos_cache.add(in); //здесь добавляется что-то, что может быть не выполнимо
        for(int i = 0; i < in.getParentSize(); i++)
        {
            posCacheUpdate(in.getParents()[i].getNode(), ind_id, dpth + 1);
        }
    }
    
    public TCache getPosCache()
    {
        return pos_cache;
    }

    public TCache getNegCache()
    {
        return neg_cache;
    }

    public TBox getTBox()
    {
        return t_box;
    }
        
    public Interpretation getInterpretation()
    {
        return graph;
    }
    
    public int getQueueSize()
    {
        return QSize;
    }
    
    public InterpretationNode[] getInterpretationIndivids()
    {
        return queue;
    }
    
    public Statistics getStats()
    {
        return stats;
    }
    
    public void setTBox(TBox _t_box)
    {
        pos_cache.setRuleGraph(_t_box.getRuleGraph());
        neg_cache.setRuleGraph(_t_box.getRuleGraph());
        t_box = _t_box;
        if(aut != null)
            aut.setRuleGraph(t_box.getRuleGraph());
        if(a_checker != null)
            a_checker.setTBox(_t_box);
        if(sub_checker != null)
            sub_checker.setTBox(_t_box);
        if(data_checker != null)
            data_checker.setTBox(_t_box);
    }
    
    public void setRBox(RBox _r_box)
    {
        r_box = _r_box;
        if(sub_checker != null)
            sub_checker.setRBox(_r_box);
        if(graph != null)
            graph.setRBox(_r_box);
    }
    
    public void setABox(ABox _a_box)
    {
        a_box = _a_box;
        if(sub_checker != null)
            sub_checker.setABox(_a_box);
    }
    
    public String getErrorType()
    {
        return error_string;
    }
    
}