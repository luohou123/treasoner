/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RuleGraph;

import Enums.NodeType;
import KB.TBox;
import java.util.ArrayList;
import org.semanticweb.owlapi.model.OWLDatatype;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.vocab.OWLFacet;

/**
 *
 * @author 1
 */
public class RuleNode {
    
    private NodeType nodeType;
    private int roleType;
    private int numberRestriction;
    private String conceptName = null;
    private boolean isNamed = false;
    private int description = 0;
    private int sub_description = 0;
    private int neg_description = 0;
    private OWLLiteral liter = null;
    private OWLDatatype datatype = null;
    private OWLFacet facet = null;
    private int cache_class = 0;
    
    private ArrayList<Integer> children = new ArrayList<Integer>();
    private ArrayList<Integer> parents = new ArrayList<Integer>();
    private ArrayList<Integer> trans = null; //FORALL-правила имеют часть по транзитивным подролям. FORALL R.C при S [= R, влечет FORALL S.C. trans обозначает номер концепта FORALL S.C;
    
    public final void defaultCreate()
    {
        roleType = -1;
        nodeType = NodeType.ntUNDEF;
        numberRestriction = 0;
    }
        
    public RuleNode()
    {
        defaultCreate();
    }  
    
    public RuleNode(NodeType node_type)
    {
        defaultCreate();
        nodeType = node_type;
    }  
    
    public RuleNode(NodeType node_type, int role_type)
    {
        defaultCreate();
        roleType = role_type;
        nodeType = node_type;
    }
        
    public RuleNode(NodeType node_type, int role_type, int number_restriction)
    {
        defaultCreate();
        roleType = role_type;
        nodeType = node_type;
        numberRestriction = number_restriction;
    }  

    public RuleNode(int new_concept, String concept_name)
    {
        defaultCreate();
        nodeType = NodeType.ntCONCEPT;
        conceptName = concept_name;
    }
    
    public void setCacheClass(int cc)
    {
        cache_class = cc;
    }
    
    public int getCacheClass()
    {
        return cache_class;
    }
    
    public void setLiter(OWLLiteral l)
    {
        liter = l;
    }
    
    public void setDatatype(OWLDatatype d)
    {
        datatype = d;
    }
    
    public void setFacet(OWLFacet f)
    {
        facet = f;
    }
    
    public OWLFacet getFacet()
    {
        return facet;
    }
    
    public OWLDatatype getDatatype()
    {
        return datatype;
    }
    
    public OWLLiteral getLiter()
    {
        return liter;
    }

    public void setName(String new_name)
    {
        conceptName = new_name;
    }
    
    public String getName()
    {
        return conceptName;
    }
    
    public void setDescription(int new_desc)
    {
        description = new_desc;
    }
    
    public void setSubDescription(int new_sub_desc)
    {
        sub_description = new_sub_desc;
    }
    
    public void setNegativeDescription(int new_desc)
    {
        neg_description = new_desc;
    }
    
    public int getSubDescription()
    {
        return sub_description;
    }
    
    public int getDescription()
    {
        return description;
    }
    
    public int getNegativeDescription()
    {
        return neg_description;
    }
    
    public void setNamed(boolean nam)
    {
        isNamed = nam;
    }
    
    public boolean isNamed()
    {
        return isNamed;
    }
    
    public void negate()
    {
        switch (nodeType)
        {
            case ntAND: nodeType = NodeType.ntOR; break;
            case ntOR: nodeType = NodeType.ntAND; break;
            case ntSOME: nodeType = NodeType.ntALL; break;
            case ntALL: nodeType = NodeType.ntSOME; break;
            case ntTHING: nodeType = NodeType.ntNOTHING; break;
            case ntNOTHING: nodeType = NodeType.ntTHING; break;
        }
    }
    
    public ArrayList<Integer> getChildren()
    {
        return children;
    }
    
    public ArrayList<Integer> getParents()
    {
        return parents;
    }
    
    public void clearParent()
    {
        parents.clear();
    }
    
    public void addParent(int x)
    {
        parents.add(x); //x is a number from automorphism algorithm
    }
    
    public void addChild(ArrayList<Integer> child_array)
    {
        for(int it: child_array)
            addChild(it);
    }
    
    public void addChild(Integer new_child)
    {
        children.add(new_child);
    }
    
    public void setIndivid(OWLIndividual oi)
    {
        if(oi.isNamed())
        {
            conceptName = oi.asOWLNamedIndividual().toStringID();
        } else
        {
            conceptName = oi.asOWLAnonymousIndividual().toStringID();
        }
    }
    
    public void deleteChild(int indexOfChild)
    {
        children.remove(indexOfChild);
    }
    
    public NodeType getNodeType()
    {
        return nodeType;
    }
    
    public NodeType getReverseNodeType()
    {
        switch (nodeType)
        {
            case ntALL:
                return NodeType.ntSOME;
            case ntSOME:
                return NodeType.ntALL;
            case ntAND:
                return NodeType.ntOR;
            case ntOR:
                return NodeType.ntAND;
            case ntNOTHING:
                return NodeType.ntTHING;
            case ntTHING:
                return NodeType.ntNOTHING;
            case ntMAXCARD:
                return NodeType.ntMINCARD;
            case ntMINCARD:
                return NodeType.ntMAXCARD;
        }
        return nodeType;
    }
    
    public int getRoleType()
    {
        return roleType;
    }
    
    public int getNumberRestriction()
    {
        return numberRestriction;
    }
        
    public void setNodeType(NodeType NodeType)
    {
        nodeType = NodeType;
    }    
    
    public void addTrans(int concept_id)
    {
        if(trans == null)
        {
            trans = new ArrayList<Integer>();
        }
        trans.add(concept_id);
    }
    
    public int getTransByRole(TBox t_box, int role)
    {
        
        for(int i = 0; i < trans.size(); i++)
        {
            if(t_box.getRuleGraph().getNode(trans.get(i)).getRoleType() == role)
            {
                return trans.get(i);
            }
        }
        return 0;
    }
    
}