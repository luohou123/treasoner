/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RuleGraph;

import Enums.NodeType;
import Help.SHash;
import Help.UF;
import KB.RBox;
import KB.TBox;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.ClassExpressionType;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLClassExpressionVisitor;
import org.semanticweb.owlapi.model.OWLDataAllValuesFrom;
import org.semanticweb.owlapi.model.OWLDataComplementOf;
import org.semanticweb.owlapi.model.OWLDataExactCardinality;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataHasValue;
import org.semanticweb.owlapi.model.OWLDataIntersectionOf;
import org.semanticweb.owlapi.model.OWLDataMaxCardinality;
import org.semanticweb.owlapi.model.OWLDataMinCardinality;
import org.semanticweb.owlapi.model.OWLDataOneOf;
import org.semanticweb.owlapi.model.OWLDataRange;
import org.semanticweb.owlapi.model.OWLDataSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLDataUnionOf;
import org.semanticweb.owlapi.model.OWLDataVisitor;
import org.semanticweb.owlapi.model.OWLDatatype;
import org.semanticweb.owlapi.model.OWLDatatypeRestriction;
import org.semanticweb.owlapi.model.OWLFacetRestriction;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLObjectAllValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectComplementOf;
import org.semanticweb.owlapi.model.OWLObjectExactCardinality;
import org.semanticweb.owlapi.model.OWLObjectHasSelf;
import org.semanticweb.owlapi.model.OWLObjectHasValue;
import org.semanticweb.owlapi.model.OWLObjectIntersectionOf;
import org.semanticweb.owlapi.model.OWLObjectMaxCardinality;
import org.semanticweb.owlapi.model.OWLObjectMinCardinality;
import org.semanticweb.owlapi.model.OWLObjectOneOf;
import org.semanticweb.owlapi.model.OWLObjectSomeValuesFrom;
import org.semanticweb.owlapi.model.OWLObjectUnionOf;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.vocab.OWLFacet;

/**
 *
 * @author 1
 */
final public class RuleGraph {

    //RuleGraph is a structure where every node presents a only concept (atomic or complex)
    
    private String thing = "TOP";
    private String nothing = "BOTTOM";
    
    private ArrayList<RuleNode> nodes = new ArrayList<RuleNode>();
    private TBox t_box;
    private RBox r_box;
    
    private HashMap<String, Integer> concept2int = new HashMap<String, Integer>();
    private HashMap<String, Integer> c2int = new HashMap<String, Integer>();
    private ArrayList<String> concepts = new ArrayList<String>();

    private HashMap<String, Integer> individ2int = new HashMap<String, Integer>();

    private HashMap<String, Integer> liter2int = new HashMap<String, Integer>();
    private ArrayList<String> liters = new ArrayList<String>();
    
    private boolean bl_O = false;
    private boolean bl_Q = false;
    private boolean bl_N = false;
    private boolean bl_D = false;
    
    public RuleGraph()
    {
        nodes.add(new RuleNode(NodeType.ntUNDEF));
        nodes.add(new RuleNode(NodeType.ntTHING));
    }
    
    public int getNodesCount()
    {
        return nodes.size();
    }
    
    public int addGCI(int l, int r)
    {
        nodes.add(new RuleNode(NodeType.ntOR));
        nodes.get(nodes.size() - 1).addChild(-l);
        nodes.get(nodes.size() - 1).addChild(r);
        return nodes.size() - 1;
    }
    
    public RuleNode getNode(int x)
    {
        return nodes.get(x);
    }
    
    public int getRoot()
    {
        return root;
    }
    
    public boolean isDataNode(int nodeIndex)
    {
        if( nodes.get(nodeIndex).getNodeType() == NodeType.ntDATATYPE || 
            nodes.get(nodeIndex).getNodeType() == NodeType.ntLITER)
        {
            return true;
        }
        if(nodes.get(nodeIndex).getNodeType() == NodeType.ntAND || nodes.get(nodeIndex).getNodeType() == NodeType.ntOR)
        {
            for(int i = 0; i < nodes.get(nodeIndex).getChildren().size(); i++)
            {
                if(isDataNode(UF.ABS(nodes.get(nodeIndex).getChildren().get(i)))) return true;
            }
        }
        return false;
    }
    
    public int addExpr2Graph(OWLClassExpression expression)
    {
        return buildRuleTree(expression);
    }
    
    public int addExpr2Graph(String expression)
    {
        /*if(expression.charAt(0) == '(')
        {
            //System.out.println(expression);
            //System.out.println(expression.substring(1, expression.length() - 1));
            expression = expression.substring(1, expression.length() - 1);
        }*/
        return buildRuleTreeByStackHelp(expression);
        //return buildRuleTree(expression);
    }
    
    public int addDataExpr2Graph(OWLDataRange data_expression)
    {
        return buildDataRuleTree(data_expression);
    }
    
    public int getID(int id)
    {
        for(int i = 0; i < concepts.size(); i++)
        {
            if(findConcept(concepts.get(i)) == id) return i;
        }
        return -1;
    }
    
    public int findConcept(String concept_name)
    {
        if(concept_name == null)
        {
            return 0;
        }
        if(concept_name.equalsIgnoreCase("*BOTTOM*") || concept_name.equalsIgnoreCase("BOTTOM")) return -1;
        if(concept_name.equalsIgnoreCase("*TOP*") || concept_name.equalsIgnoreCase("TOP")) return 1;
        if(concept_name.equalsIgnoreCase("Thing") || concept_name.equalsIgnoreCase("Thing")) return 1;
        if(concept_name.equalsIgnoreCase("Nothing") || concept_name.equalsIgnoreCase("Nothing")) return -1;
        if(concept2int.containsKey(concept_name))
            return concept2int.get(concept_name);
        
        nodes.add(new RuleNode(nodes.size(), concept_name));
        concepts.add(concept_name);
        c2int.put(concept_name, concepts.size() - 1);
        
        concept2int.put(concept_name, nodes.size() - 1);
        
        return nodes.size() - 1;
    }
    
    public int findIndivid(OWLIndividual oi)
    {
        String nam = "";
        if(oi.isNamed())
        {
            nam = oi.asOWLNamedIndividual().toStringID();
        } else
        {
            nam = oi.asOWLAnonymousIndividual().toStringID();            
        }
        if(individ2int.containsKey(nam))
        {
            return individ2int.get(nam);
        }
        
        RuleNode help = new RuleNode(NodeType.ntINDIVID);
        help.setIndivid(oi);
        nodes.add(help);
        individ2int.put(nam, nodes.size() - 1);
            
        return nodes.size() - 1;
    }
    
    public int findLiter(OWLLiteral ol)
    {
        String nam = ol.getLiteral() + ol.getDatatype().toStringID();
        if(liter2int.containsKey(nam))
        {
            return liter2int.get(nam);
        } else
        {
            if(ol.getDatatype().isBoolean())
            {
                if(ol.getLiteral().equals("true"))
                    nam = "false" + ol.getDatatype().toStringID(); else
                    nam = "true" + ol.getDatatype().toStringID();                    
                
                if(liter2int.containsKey(nam))
                {
                    return -liter2int.get(nam);
                }
            }
        }
        
        RuleNode help = new RuleNode(NodeType.ntLITER);
        help.setLiter(ol);
        help.setDatatype(ol.getDatatype());
        nodes.add(help);
        liter2int.put(nam, nodes.size() - 1);
        
        return nodes.size() - 1;
    }
    
    public int getConceptID(String conc)
    {
        //findConcept(conc);
        if(!c2int.containsKey(conc))
        {
            return 0;
        }
        return c2int.get(conc);
    }
    
    public ArrayList<String> getConcepts()
    {
        return concepts;
    }
    
    public void setTBox(TBox new_t_box)
    {
        t_box = new_t_box;
    }
    
    public TBox getTBox()
    {
        return t_box;
    }
    
    public String getLogicString()
    {
        String ret = "";
        if(bl_O) ret += "O";
        if(bl_Q) ret += "Q"; else
            if(bl_N) ret += "N";
        if(bl_D) ret += "(D)";
        return ret;
    }
    
    public void setRBox(RBox new_r_box)
    {
        r_box = new_r_box;
    }
    
    public RBox getRBox()
    {
        return r_box;
    }

    
    private int[] flag = new int[1024 * 1024];
    public void showCD()
    {
        for(int i = 0; i < 1024 * 1024; i++)
            flag[i] = 0;
        
        /*System.out.print("CONCEPTS COUNT: ");
        System.out.println(concepts.size());
        System.out.print("NODES COUNT: ");
        System.out.println(nodes.size());*/
        
        for(int i = 0; i < t_box.getOrder().size(); i++)
        {
            System.out.println(concepts.get(t_box.getOrder().get(i)));
            showTree(getNode(concept2int.get(concepts.get(t_box.getOrder().get(i)))).getDescription(), "");
            System.out.println();
        }
    }
    
    public void showTree(int curn, String spaces)
    {
        int cur = curn; 
        if(cur < 0) cur = -cur;
        
        //-1 - nothing
        // 1 -   thing
        
        if(curn >= 1000) System.out.print(" "); else
            if(curn >= 100) System.out.print("  "); else
                if(curn >= 10) System.out.print("   "); else
                    if(curn >= 0) System.out.print("    "); else
                        if(curn < -100) System.out.print("   "); else
                            if(curn < -10) System.out.print("  "); else
                                if(curn < -0) System.out.print("   ");
        
        System.out.print(curn);
        System.out.print(" ");
        System.out.print(getNode(cur).getChildren().size());

        if(curn == 1) System.out.println(spaces + "THING");
        if(curn == -1) System.out.println(spaces + "NOTHING");
        
        if(cur == 1 || cur == 0) return;
        
        System.out.print(spaces);
        if(curn < 0)
        {
            System.out.print("NOT ");
        }
        
        if(flag[cur] > 0)
        {
            //System.out.println(curn);
            if(getNode(cur).getNodeType() == NodeType.ntCONCEPT)
            {
                if(curn < 0)
                {
                    System.out.println(getNode(cur).getName());
                    return;
                } else
                {
                    System.out.println(getNode(cur).getName());
                    return;
                }
            }
            System.out.println(getNode(cur).getNodeType());
            return;
        }
        flag[cur] = 1;
        if(cur >= nodes.size())
        {
            System.out.printf("WTF!? NODE IN RULE GRAPH ISN'T EXISTS\n");
            System.out.flush();
            return;            
        }
        RuleNode current_node = getNode(cur);
        
        if(current_node.getNodeType() == NodeType.ntTHING || current_node.getNodeType() == NodeType.ntNOTHING)
        {
            System.out.printf("%s\n", current_node.getNodeType().toString());
            System.out.flush();
        } else
        if(current_node.getNodeType() == NodeType.ntCONCEPT)
        {
            if(curn < 0)
            {
                System.out.printf("%s\n", current_node.getName());
            } else
            {
                System.out.printf("%s\n", current_node.getName());
            }
            System.out.flush();
        } else
        {
            int rt = current_node.getRoleType();
            if(rt != -1)
            {
                if(current_node.getNodeType() != NodeType.ntSOME && current_node.getNodeType() != NodeType.ntALL)
                {
                    System.out.printf("%s %d %s\n", current_node.getNodeType().toString(), current_node.getNumberRestriction(), r_box.getRoleByIndex(rt).getName());                    
                } else
                {
                    System.out.printf("%s %s\n", current_node.getNodeType().toString(), r_box.getRoleByIndex(rt).getName());
                }
            } else System.out.printf("%s\n", current_node.getNodeType().toString());
            System.out.flush();
        }

        for(int i = 0; i < getNode(cur).getChildren().size(); i++)
            showTree(getNode(cur).getChildren().get(i), spaces + "   ");
    }
        
    public int addNode2RuleTree(RuleNode current_node)
    {
        nodes.add(current_node);
        return nodes.size() - 1;
    }
    
    public void addToSubDesciption(int c_id, int desc)
    {
        if(nodes.get(c_id).getSubDescription() == 0)
        {
            nodes.get(c_id).setSubDescription(desc);
        } else
        {
            int s_d = nodes.get(c_id).getSubDescription();
            if(s_d > 0 && nodes.get(UF.ABS(s_d)).getNodeType() == NodeType.ntAND)
            {
                nodes.get(s_d).addChild(desc);
            } else
            {
                RuleNode rn = new RuleNode(NodeType.ntAND);
                int x = addNode2RuleTree(rn);
                rn.addChild(s_d);
                rn.addChild(desc);
                nodes.get(c_id).setSubDescription(x);
            }
        }
    }
        
    private void normalizeNode(int node_index)
    {
        if(f_nn[node_index] == 1) return;
        f_nn[node_index] = 1;
        
        Integer[] ar = new Integer[0];
        ar = nodes.get(node_index).getChildren().toArray(ar);
        ArrayList<Integer> temp = new ArrayList<Integer>();
        
        for(int i = 0; i < ar.length; i++)
        {
            if(ar[i] < 0) continue;
            if((nodes.get(ar[i]).getNodeType() == NodeType.ntAND) && (nodes.get(node_index).getNodeType() == NodeType.ntAND))
            {
                normalizeNode(ar[i]);
                for(int j = 0; j < nodes.get(ar[i]).getChildren().size(); j++)
                {
                    temp.add(nodes.get(ar[i]).getChildren().get(j));
                }
            }
            if((nodes.get(ar[i]).getNodeType() == NodeType.ntOR) && (nodes.get(node_index).getNodeType() == NodeType.ntOR))
            {
                normalizeNode(ar[i]);
                for(int j = 0; j < nodes.get(ar[i]).getChildren().size(); j++)
                {
                    temp.add(nodes.get(ar[i]).getChildren().get(j));
                }
            }
        }
        
        for(int i = 0; i < ar.length; i++)
        {
            if(ar[i] < 0) continue;
            if((nodes.get(ar[i]).getNodeType() == NodeType.ntAND) && (nodes.get(node_index).getNodeType() == NodeType.ntAND))
                if(nodes.get(node_index).getChildren().remove(ar[i]))
                {
                    i--; continue;
                }

            if((nodes.get(ar[i]).getNodeType() == NodeType.ntOR) && (nodes.get(node_index).getNodeType() == NodeType.ntOR))
                if(nodes.get(node_index).getChildren().remove(ar[i]))
                {
                    i--; continue;
                }
        }
        
        for(int i = 0; i < temp.size(); i++)
            nodes.get(node_index).getChildren().add(temp.get(i));
        
    }
    
    private int[] f_nn;
    public void normalizeGraph()
    {
        f_nn = new int[nodes.size() + 1];
        for(int i = 0; i < nodes.size() + 1; i++)
            f_nn[i] = 0;

        for(int i = 0; i < nodes.size(); i++)
        {
            normalizeNode(i);
        }
    }
    
    private SHash cache = new SHash();
    private int[] sortedVertices;
    private int[] heights;
    private Pair[] NWH; // nodes with heights
    private int NWHCount = 0;
    private int[] exchanges;
    
    private class Pair
    {
        public int x, y;
        public Pair(int a, int b)
        {
            x = a; y = b;
        }
    }
    
    private class PairComparor implements Comparator<Pair>
    {

        @Override
        public int compare(Pair o1, Pair o2) {
            if(o1.y == o2.y)
            {
                if(o1.x > o2.x) 
                    return 1; else
                if(o1.x < o2.x)
                    return -1;
                return 0;
            }
            if(o1.y > o2.y) 
                return 1; else
            if(o1.y < o2.y)
                return -1;
            return 0;
        }
        
    }
    
    private void sortVerticesDFS(int x)
    {
        if(heights[x] != 0) return;
        heights[x] = 1;
        for(int i = 0; i < nodes.get(x).getChildren().size(); i++)
        {
            sortVerticesDFS(UF.ABS(nodes.get(x).getChildren().get(i)));
            if( heights[x] < heights[UF.ABS(nodes.get(x).getChildren().get(i))] + 1)
                heights[x] = heights[UF.ABS(nodes.get(x).getChildren().get(i))] + 1;
        }
        NWH[NWHCount++] = new Pair(x, heights[x]);
    }

    private void del(int node_index)
    {
        Integer[] ar = new Integer[0];
        ar = nodes.get(UF.ABS(node_index)).getChildren().toArray(ar);
        ArrayList<Integer> temp = new ArrayList<Integer>();
        
        for(int i = 0; i < ar.length; i++)
        {
            del(ar[i]);
            if(((nodes.get(UF.ABS(ar[i])).getNodeType() == NodeType.ntAND) || (nodes.get(UF.ABS(ar[i])).getNodeType() == NodeType.ntOR)) && 
                (nodes.get(UF.ABS(ar[i])).getChildren().size() == 1))
            {
                for(int j = 0; j < nodes.get(ar[i]).getChildren().size(); j++)
                {
                    temp.add(nodes.get(ar[i]).getChildren().get(j));
                }
            }
        }

        for(int i = 0; i < ar.length; i++)
        {
            if(((nodes.get(UF.ABS(ar[i])).getNodeType() == NodeType.ntAND) || (nodes.get(UF.ABS(ar[i])).getNodeType() == NodeType.ntOR)) && 
                (nodes.get(UF.ABS(ar[i])).getChildren().size() == 1))
                if(nodes.get(UF.ABS(node_index)).getChildren().remove(ar[i]))
                {
                    i--; continue;
                }
            
        }
        for(int i = 0; i < temp.size(); i++)
            nodes.get(UF.ABS(node_index)).getChildren().add(temp.get(i));        

        Collections.sort(nodes.get(UF.ABS(node_index)).getChildren());
        for(int i = 1; i < nodes.get(UF.ABS(node_index)).getChildren().size(); i++)
        {
            if(nodes.get(UF.ABS(node_index)).getChildren().get(i - 1).intValue() == nodes.get(UF.ABS(node_index)).getChildren().get(i).intValue())
            {
                nodes.get(UF.ABS(node_index)).getChildren().remove(i);
                i--;
            }
        }
        
    }
    
    public void delOnes()
    {
        for(int i = 0; i < concepts.size(); i++)
        {
            del(nodes.get(concept2int.get(concepts.get(i))).getDescription());
            del(nodes.get(concept2int.get(concepts.get(i))).getSubDescription());
        }
    }
    
    public void EqvDescriptionProcess()
    {
        for(int i = 0; i < concepts.size(); i++)
        {
            if(concepts.get(i).equals("http://cohse.semanticweb.org/ontologies/people#Anonymous-1"))
            {
                int kor = 123;
            }
            int hlp = nodes.get(concept2int.get(concepts.get(i))).getDescription();
            if(hlp > 0)
            {
                if(nodes.get(hlp).getNodeType() == NodeType.ntOR)
                {
                    for(int j = 0; j < nodes.get(hlp).getChildren().size(); j++)
                    {
                        int h = nodes.get(hlp).getChildren().get(j);
                        addToSubDesciption(h, concept2int.get(concepts.get(i)));
                    }
                }
            }
        }
    }
    
    private ArrayList<Integer> verts = new ArrayList<Integer>();
    private ArrayList<Integer> index = new ArrayList<Integer>();
    private int[] f = new int[1024 * 128];
    private HashSet<Integer> con = new HashSet<Integer>();
    private ArrayList<Integer> deleted = new ArrayList<Integer>();
    OWLDataFactory df = null;
    OWLOntologyManager manager = null;
    OWLOntology Ontology = null;
    
    public void printToOWL(String file_name) throws OWLOntologyCreationException, OWLOntologyStorageException
    {
        df = OWLManager.getOWLDataFactory();
        manager = OWLManager.createOWLOntologyManager();
        Ontology = manager.createOntology(IRI.create(new File(file_name)));

        for(int i = 0; i < concepts.size(); i++)
        {
            if(nodes.get(concept2int.get(concepts.get(i))).getDescription() != 0)
            {
                OWLAxiom sca = null;
                if(nodes.get(concept2int.get(concepts.get(i))).isNamed())
                {
                    sca = df.getOWLEquivalentClassesAxiom(
                            df.getOWLClass(IRI.create(nodes.get(concept2int.get(concepts.get(i))).getName())), 
                            recOutToOWL(nodes.get(concept2int.get(concepts.get(i))).getDescription()));
                } else
                {
                    sca = df.getOWLSubClassOfAxiom(
                            df.getOWLClass(IRI.create(nodes.get(concept2int.get(concepts.get(i))).getName())), 
                            recOutToOWL(nodes.get(concept2int.get(concepts.get(i))).getDescription()));
                }
                AddAxiom addAxiom = new AddAxiom(Ontology, sca);
                manager.applyChange(addAxiom);
                manager.saveOntology(Ontology);
            }
        }
    }
    
    private OWLClassExpression recOutToOWL(int rut)
    {
        if(rut < 0)
        {
            return df.getOWLObjectComplementOf(recOutToOWL(-rut));
        }
        if(nodes.get(rut).getNodeType() == NodeType.ntAND)
        {
            HashSet<OWLClassExpression> sce = new HashSet<OWLClassExpression>();
            for(int i = 0; i < nodes.get(rut).getChildren().size(); i++)
            {
                sce.add(recOutToOWL(nodes.get(rut).getChildren().get(i)));
            }
            return df.getOWLObjectIntersectionOf(sce);
        }
        if(nodes.get(rut).getNodeType() == NodeType.ntOR)
        {
            HashSet<OWLClassExpression> sce = new HashSet<OWLClassExpression>();
            for(int i = 0; i < nodes.get(rut).getChildren().size(); i++)
            {
                sce.add(recOutToOWL(nodes.get(rut).getChildren().get(i)));
            }
            return df.getOWLObjectUnionOf(sce);
        }
        if(nodes.get(rut).getNodeType() == NodeType.ntSOME)
        {
            return df.getOWLObjectSomeValuesFrom(
                    df.getOWLObjectProperty(IRI.create(r_box.getRoleByIndex(nodes.get(rut).getRoleType()).getName())),
                    recOutToOWL(nodes.get(rut).getChildren().get(0)));
        }
        if(nodes.get(rut).getNodeType() == NodeType.ntALL)
        {
            return df.getOWLObjectAllValuesFrom(
                    df.getOWLObjectProperty(IRI.create(r_box.getRoleByIndex(nodes.get(rut).getRoleType()).getName())),
                    recOutToOWL(nodes.get(rut).getChildren().get(0)));
        }
        if(nodes.get(rut).getNodeType() == NodeType.ntTHING)
        {
            return df.getOWLThing();
        }
        if(nodes.get(rut).getNodeType() == NodeType.ntNOTHING)
        {
            return df.getOWLNothing();
        }
        return df.getOWLClass(IRI.create(nodes.get(rut).getName()));
    }
    
    public void takeOut(int prm)
    {
        verts.clear();
        NodeType nt = NodeType.ntUNDEF, dt = NodeType.ntUNDEF;
        int orCount = 0;
        for(int i = nodes.size() - 1; i >= 0; i--)
        {
            nt = NodeType.ntUNDEF;
            if(nodes.get(i).getNodeType() == NodeType.ntAND)
            {
                nt = NodeType.ntOR;
                dt = NodeType.ntAND;
            }
            if(nodes.get(i).getNodeType() == NodeType.ntOR)
            {
                nt = NodeType.ntAND;
                dt = NodeType.ntOR;
            }
            
            if(nt != NodeType.ntUNDEF)
            {
                orCount = 0;
                for(int j = 0; j < nodes.get(i).getChildren().size(); j++)
                {
                    int x = nodes.get(i).getChildren().get(j);
                    if((nodes.get(UF.ABS(x)).getNodeType() == nt && x > 0) || 
                       (nodes.get(UF.ABS(x)).getNodeType() == dt && x < 0)) orCount++;
                }
                if(orCount > 1)
                {
                    verts.add(i);
                }
            }
        }
        
        for(int i = 0; i < verts.size(); i++)
        {
            if(nodes.get(verts.get(i)).getNodeType() == NodeType.ntOR)
            {
                Arrays.fill(f, 0);
                index.clear();
                con.clear();
                for(int j = 0; j < nodes.get(verts.get(i)).getChildren().size(); j++)
                {
                    if(f[j] == 1) continue;
                    
                    int x = nodes.get(verts.get(i)).getChildren().get(j);
                    if(con.contains(x) || con.contains(-x)) continue;
                    
                    ////////////////////////////////////////////////////////////
                    for(int u = 0; u < nodes.get(UF.ABS(x)).getChildren().size(); u++)
                    {
                        int y = nodes.get(UF.ABS(x)).getChildren().get(u); //node to get out!
                        if(x < 0) y = -y;

                        RuleNode rn = new RuleNode(nodes.get(verts.get(i)).getNodeType());

                        int countOfOut = 0;

                        deleted.clear();
                        for(int k = 0; k < nodes.get(verts.get(i)).getChildren().size(); k++)
                        {
                            if(f[k] == 1) continue;
                            int z = nodes.get(verts.get(i)).getChildren().get(k);
                            int sn = 1; if(z < 0) sn = -1;
                            if(nodes.get(UF.ABS(z)).getChildren().contains(y * sn))
                            {
                                //nodes.get(UF.ABS(z)).getChildren().remove(new Integer(y * sn));
                                RuleNode rn1 = new RuleNode(nodes.get(UF.ABS(z)).getNodeType());
                                rn1.addChild(nodes.get(UF.ABS(z)).getChildren()); rn1.getChildren().remove(new Integer(y * sn));
                                rn.addChild(addNode2RuleTree(rn1));
                                con.add(z);
                                f[k] = 1;
                                deleted.add(k);
                                countOfOut++;
                            }
                        }

                        if(countOfOut >= prm)
                        {
                            if(nodes.get(verts.get(i)).getNodeType() == NodeType.ntAND) rn.addChild(-y);
                            int ind = addNode2RuleTree(rn);
                            if(nodes.get(verts.get(i)).getNodeType() == NodeType.ntAND) 
                                rn = new RuleNode(NodeType.ntOR); else
                                rn = new RuleNode(NodeType.ntAND);
                            rn.addChild(ind);
                            rn.addChild(y);
                            ind = addNode2RuleTree(rn);
                            index.add(ind);
                            break;
                        } else
                        {
                            for(int itr = 0; itr < deleted.size(); itr++)
                                f[deleted.get(itr)] = 0;

                            int sn = 1; if(x < 0) sn = -1;
                            //nodes.get(UF.ABS(x)).getChildren().add(y * sn);
                        }
                    }
                    ////////////////////////////////////////////////////////////
                }
                int countOfDeleted = 0;
                int siz = nodes.get(verts.get(i)).getChildren().size();
                for(int j = 0; j < siz; j++)
                {
                    if(f[j] == 1)
                    {
                        nodes.get(verts.get(i)).getChildren().remove(j - countOfDeleted);
                        countOfDeleted++;
                    }
                }
                for(int j = 0; j < index.size(); j++)
                {
                    nodes.get(verts.get(i)).addChild(index.get(j));
                }
            }
        }
    }
    
    public void makeDAG() //converts tree structure 
    {
        sortedVertices = new int[nodes.size() + 1];
        int[] roots = new int[nodes.size() + 1];
        exchanges = new int[nodes.size() + concepts.size()];
        heights = new int[nodes.size() + 1];
        NWH = new Pair[nodes.size() + 1];
        
        Arrays.fill(roots, 0);
        Arrays.fill(heights, 0);
        Arrays.fill(exchanges, 0);
        Arrays.fill(sortedVertices, 0);
        
        for(int i = 0; i < nodes.size(); i++)
            for(int j = 0; j < nodes.get(i).getChildren().size(); j++)
                roots[UF.ABS(nodes.get(i).getChildren().get(j))] = 1;

        for(int i = 0; i < nodes.size(); i++)
        {
            if(roots[i] == 1) continue;
            //System.out.println(i + " " + nodes.get(i).getNodeType() + " " + nodes.get(i).getName());
            sortVerticesDFS(i);
        }
        
        Arrays.sort(NWH, 0, NWHCount, new PairComparor());
        
        for(int i = 0; i < NWHCount; i++)
        {
            for(int j = 0; j < nodes.get(NWH[i].x).getChildren().size(); j++)
            {
                int x = nodes.get(NWH[i].x).getChildren().get(j);
                if(exchanges[UF.ABS(x)] != 0)
                {
                    int y = exchanges[UF.ABS(x)];
                    if(x < 0) y *= -1;
                    nodes.get(NWH[i].x).getChildren().set(j, y);
                }
            }
            
            int res = cache.add(nodes.get(NWH[i].x).getChildren(), NWH[i].x, nodes.get(NWH[i].x).getNodeType().ordinal(), nodes.get(NWH[i].x).getRoleType());
            if(res == 0) continue;
            
            if((nodes.get(NWH[i].x).getNodeType() == NodeType.ntAND) && 
               ((res < 0 && (nodes.get(UF.ABS(res)).getNodeType() == NodeType.ntOR)) || 
                (res > 0 && (nodes.get(UF.ABS(res)).getNodeType() == NodeType.ntAND))))
            {
                exchanges[NWH[i].x] = res;
            }

            if((nodes.get(NWH[i].x).getNodeType() == NodeType.ntOR) && 
               ((res < 0 && (nodes.get(UF.ABS(res)).getNodeType() == NodeType.ntAND)) || 
                (res > 0 && (nodes.get(UF.ABS(res)).getNodeType() == NodeType.ntOR))))
            {
                exchanges[NWH[i].x] = res;
            }

            if((nodes.get(NWH[i].x).getNodeType() == NodeType.ntSOME) && (nodes.get(NWH[i].x).getRoleType() == nodes.get(UF.ABS(res)).getRoleType()) &&
               ((res < 0 && (nodes.get(UF.ABS(res)).getNodeType() == NodeType.ntALL)) || 
                (res > 0 && (nodes.get(UF.ABS(res)).getNodeType() == NodeType.ntSOME))))
            {
                exchanges[NWH[i].x] = res;
            }

            if((nodes.get(NWH[i].x).getNodeType() == NodeType.ntALL) && (nodes.get(NWH[i].x).getRoleType() == nodes.get(UF.ABS(res)).getRoleType()) &&
               ((res < 0 && (nodes.get(UF.ABS(res)).getNodeType() == NodeType.ntSOME)) || 
                (res > 0 && (nodes.get(UF.ABS(res)).getNodeType() == NodeType.ntALL))))
            {
                exchanges[NWH[i].x] = res;
            }
        }
        for(int i = 0; i < NWHCount; i++)
        {
            int x = nodes.get(NWH[i].x).getDescription();
            if(x != 0)
            {
                int sign = 1; if(x < 0) sign = -1;
                if(exchanges[UF.ABS(x)] != 0)
                {
                    nodes.get(NWH[i].x).setDescription(sign * exchanges[UF.ABS(x)]);
                }
                if(sign > 0)
                {
                    int id = nodes.get(exchanges[x]).getDescription();
                    if(id == 0)
                    {
                        nodes.get(exchanges[x]).setDescription(NWH[i].x);
                    } else
                    if(getNode(id).getNodeType() != NodeType.ntAND)
                    {
                        int new_node = addNode2RuleTree(new RuleNode(NodeType.ntAND));
                        getNode(new_node).addChild(id);
                        getNode(new_node).addChild(NWH[i].x);
                        nodes.get(exchanges[x]).setDescription(new_node);                        
                    } else
                    {
                        getNode(id).addChild(NWH[i].x);
                    }
                }
            }

            x = nodes.get(NWH[i].x).getSubDescription();
            if(x != 0)
            {
                int sign = 1; if(x < 0) sign = -1;
                if(exchanges[UF.ABS(x)] != 0) nodes.get(NWH[i].x).setSubDescription(sign * exchanges[UF.ABS(x)]);
            }
        }
        
        for(int i = 0; i < NWHCount; i++) //Lazy unfolding preprocess - search cases when C = A1 and A2 and ... and AM and change it to -A1 [= C or -A2 or -A3 
        {
            if(nodes.get(NWH[i].x).getNodeType() == NodeType.ntCONCEPT && nodes.get(NWH[i].x).getDescription() != 0)
            {
                //if(nodes.get(NWH[i].x).getName() == "")
                int x = nodes.get(NWH[i].x).getDescription();
                if(x > 0) if(nodes.get(x).getNodeType() == NodeType.ntAND)
                {
                    for(int j = 0; j < nodes.get(x).getChildren().size(); j++)
                    {
                        int y = nodes.get(x).getChildren().get(j);
                        if(nodes.get(y).getNodeType() == NodeType.ntCONCEPT)
                        {
                            RuleNode rn = new RuleNode(NodeType.ntOR);
                            rn.addChild(NWH[i].x);
                            int ngd = nodes.get(y).getNegativeDescription();

                            for(int k = 0; k < nodes.get(x).getChildren().size(); k++)
                            {
                                if(k == j) continue;
                                rn.addChild(-nodes.get(x).getChildren().get(k));
                            }
                            if(rn.getChildren().size() > 1)
                            {
                                if(ngd == 0)
                                {
                                    nodes.get(y).setNegativeDescription(addNode2RuleTree(rn));
                                } else
                                {
                                    if(nodes.get(ngd).getNodeType() == NodeType.ntAND)
                                    {
                                        nodes.get(ngd).addChild(addNode2RuleTree(rn));
                                    } else
                                    {
                                        RuleNode new_rn = new RuleNode(NodeType.ntAND);
                                        new_rn.addChild(ngd);
                                        new_rn.addChild(addNode2RuleTree(rn));
                                        nodes.get(y).setNegativeDescription(addNode2RuleTree(new_rn));
                                    }
                                }
                            } else
                            {
                                if(ngd == 0)
                                {
                                    nodes.get(y).setNegativeDescription(rn.getChildren().get(0));                                
                                } else
                                {
                                    if(nodes.get(ngd).getNodeType() == NodeType.ntAND)
                                    {
                                        nodes.get(ngd).addChild(addNode2RuleTree(rn));
                                    } else
                                    {
                                        RuleNode new_rn = new RuleNode(NodeType.ntAND);
                                        new_rn.addChild(ngd);
                                        new_rn.addChild(rn.getChildren().get(0));
                                        nodes.get(y).setNegativeDescription(addNode2RuleTree(new_rn));
                                    }
                                }
                            }
                            if(nodes.get(NWH[i].x).getSubDescription() == 0)
                            {
                                nodes.get(NWH[i].x).setSubDescription(nodes.get(NWH[i].x).getDescription());
                            } else
                            {
                                RuleNode rn1 = new RuleNode(NodeType.ntAND);
                                rn1.addChild(nodes.get(NWH[i].x).getDescription());
                                rn1.addChild(nodes.get(NWH[i].x).getSubDescription());                                
                                nodes.get(NWH[i].x).setSubDescription(addNode2RuleTree(rn1));
                            }
                            //nodes.get(NWH[i].x).setDescription(0);
                            break;
                        }
                    }
                }
            }
        }
        //System.out.print("COUNT OF ELEMENTS IN HASH ");
        //System.out.println(cache.countOfElements());
    }
    
    public void clearCacheClasses()
    {
        for(int i = 0; i < nodes.size(); i++)
            nodes.get(i).setCacheClass(0);
    }
    
    private int buildRuleTree(OWLClassExpression classExpr)
    {
        RuleNode help = null;
        int cn = 0;

        ExpressionTransformer expr_transform = new ExpressionTransformer(t_box);
        classExpr.accept(expr_transform);
        bl_N |= expr_transform.bl_N; bl_O |= expr_transform.bl_O; bl_Q |= expr_transform.bl_Q; bl_D |= expr_transform.bl_D;
        switch (classExpr.getClassExpressionType())
        {
            case OBJECT_COMPLEMENT_OF:
            {
                return -buildRuleTree(expr_transform.getObjectFiller());            
            }
            case OBJECT_INTERSECTION_OF:
            {
                help = new RuleNode(NodeType.ntAND);
                for(OWLClassExpression current_class: expr_transform.getClassesList())
                    help.addChild(buildRuleTree(current_class));
                break;
            }
            case OBJECT_ONE_OF:
            {
                help = new RuleNode(NodeType.ntOR);
                for(OWLIndividual oi: expr_transform.getIndivids())
                    help.addChild(findIndivid(oi));
                break;
            }
            case OBJECT_HAS_VALUE:
            {
                help = new RuleNode(NodeType.ntSOME, expr_transform.getRoleType());
                help.addChild(findIndivid(expr_transform.getIndividual()));
                break;
            }
            case OBJECT_HAS_SELF:
            {
                help = new RuleNode(NodeType.ntHASSELF);
                break;
            }
            case OBJECT_UNION_OF:
            {
                help = new RuleNode(NodeType.ntOR);
                for(OWLClassExpression current_class: expr_transform.getClassesList())
                    help.addChild(buildRuleTree(current_class));
                break;
            }
            case OBJECT_ALL_VALUES_FROM:
            {
                help = new RuleNode(NodeType.ntALL, expr_transform.getRoleType());
                help.addChild(buildRuleTree(expr_transform.getObjectFiller()));
                break;
            }
            case OBJECT_SOME_VALUES_FROM:
            {
                help = new RuleNode(NodeType.ntSOME, expr_transform.getRoleType());
                help.addChild(buildRuleTree(expr_transform.getObjectFiller()));
                break;
            }
            case OBJECT_MAX_CARDINALITY:
            {
                help = new RuleNode(NodeType.ntMAXCARD, expr_transform.getRoleType(), expr_transform.getNumberR());
                help.addChild(buildRuleTree(expr_transform.getObjectFiller()));
                break;
            }
            case OBJECT_MIN_CARDINALITY:
            {
                help = new RuleNode(NodeType.ntMINCARD, expr_transform.getRoleType(), expr_transform.getNumberR());
                help.addChild(buildRuleTree(expr_transform.getObjectFiller()));
                break;
            }
            case OBJECT_EXACT_CARDINALITY:
            {
                if(expr_transform.getNumberR() == 0)
                {
                    help = new RuleNode(NodeType.ntALL, expr_transform.getRoleType());
                    help.addChild(-buildRuleTree(expr_transform.getObjectFiller()));
                    break;
                }
                help = new RuleNode(NodeType.ntAND);
                cn = buildRuleTree(expr_transform.getObjectFiller());
                RuleNode r1 = new RuleNode(
                        NodeType.ntMAXCARD, 
                        expr_transform.getRoleType(), 
                        expr_transform.getNumberR());

                RuleNode r2 = new RuleNode(
                        NodeType.ntMINCARD, 
                        expr_transform.getRoleType(), 
                        expr_transform.getNumberR());
                r1.addChild(cn); r2.addChild(cn);
                help.addChild(addNode2RuleTree(r1));
                help.addChild(addNode2RuleTree(r2));
                break;
            }
            case OWL_CLASS:
            {
                if(classExpr.isOWLThing())
                {
                    thing = classExpr.asOWLClass().toStringID();
                    return  1;
                }
                if(classExpr.isOWLNothing())
                {
                    nothing = classExpr.asOWLClass().toStringID();
                    return -1;
                }
                if(!classExpr.isAnonymous())
                {
                    //return findConcept(classExpr.asOWLClass().getIRI().getFragment());
                    return findConcept(classExpr.asOWLClass().getIRI().toString());
                } else
                {
                    System.out.println("ERROR: anonymus class founded");
                    return -1;
                }
            }
            
            case DATA_ALL_VALUES_FROM:
            {
                help = new RuleNode(NodeType.ntALL, expr_transform.getRoleType());
                help.addChild(buildDataRuleTree(expr_transform.getDataFiller()));
                break;
            }
            case DATA_SOME_VALUES_FROM:
            {
                help = new RuleNode(NodeType.ntALL, expr_transform.getRoleType());
                help.addChild(buildDataRuleTree(expr_transform.getDataFiller()));
                break;
            }
            case DATA_MAX_CARDINALITY:
            {
                help = new RuleNode(NodeType.ntMAXCARD, expr_transform.getRoleType(), expr_transform.getNumberR());
                help.addChild(buildDataRuleTree(expr_transform.getDataFiller()));
                break;
            }
            case DATA_MIN_CARDINALITY:
            {
                help = new RuleNode(NodeType.ntMINCARD, expr_transform.getRoleType(), expr_transform.getNumberR());
                help.addChild(buildDataRuleTree(expr_transform.getDataFiller()));
                break;
            }
            case DATA_EXACT_CARDINALITY:
            {
                help = new RuleNode(NodeType.ntAND);
                cn = buildDataRuleTree(expr_transform.getDataFiller());
                RuleNode r1 = new RuleNode(
                        NodeType.ntMAXCARD, 
                        expr_transform.getRoleType(), 
                        expr_transform.getNumberR());

                RuleNode r2 = new RuleNode(
                        NodeType.ntMINCARD, 
                        expr_transform.getRoleType(), 
                        expr_transform.getNumberR());
                r1.addChild(cn); r2.addChild(cn);
                help.addChild(addNode2RuleTree(r1));
                help.addChild(addNode2RuleTree(r2));
                break;
            }
            case DATA_HAS_VALUE:
            {
                help = new RuleNode(NodeType.ntSOME, expr_transform.getRoleType());
                help.addChild(findLiter(expr_transform.getDataValue()));
                break;
            }
        }
        
        cn = addNode2RuleTree(help);
        return cn;
    }
    
    ////////////////////////////////////////////////////////////////////////
    //Fast synthetic analysis with own stack for *.alc files and *.tkb files
    int[] stak;
    RuleNode[] f_op;
    int stak_size = 0;
    int root = 0;
    
    private void addVertice(String[] tokens, int tokens_count)
    {
        int k = 1;
        if(tokens_count > 0)
        {
            if(tokens[0].equalsIgnoreCase("NOT"))
            {
                f_op[stak_size - k] = new RuleNode(NodeType.ntNOT);
                if(stak_size > 0 && tokens_count > 1)
                {
                    int mult = 1, l = 1;
                    while(stak_size - l >= 0)
                    {
                        if(f_op[stak_size - l].getNodeType() == NodeType.ntNOT)  mult = mult * -1; else
                        {
                            f_op[stak_size - l].addChild(mult * findConcept(tokens[1])); //it must be only one token after NOT
                            break;
                        }
                        l++;
                    }
                    if(stak_size - l <= 0)
                    {
                        root = mult * findConcept(tokens[1]); //it must be only one token after NOT
                    }
                } else
                {
                    if(tokens_count > 1) root = -findConcept(tokens[1]);
                }
            } else
            if(tokens[0].equalsIgnoreCase("AND"))
            {
                f_op[stak_size - k] = new RuleNode(NodeType.ntAND);
                for(int j = 1; j < tokens_count; j++)
                    f_op[stak_size - k].addChild(findConcept(tokens[j]));
            } else
            if(tokens[0].equalsIgnoreCase("OR"))
            {
                f_op[stak_size - k] = new RuleNode(NodeType.ntOR);
                for(int j = 1; j < tokens_count; j++)
                    f_op[stak_size - k].addChild(findConcept(tokens[j]));
            } else
            if(tokens[0].equalsIgnoreCase("SOME"))
            {
                f_op[stak_size - k] = new RuleNode(NodeType.ntSOME, r_box.findRole(tokens[1]));
                for(int j = 2; j < tokens_count; j++)
                    f_op[stak_size - k].addChild(findConcept(tokens[j]));
            } else
            if(tokens[0].equalsIgnoreCase("ALL"))
            {
                f_op[stak_size - k] = new RuleNode(NodeType.ntALL, r_box.findRole(tokens[1]));
                for(int j = 2; j < tokens_count; j++)
                    f_op[stak_size - k].addChild(findConcept(tokens[j]));
            } else
            if(tokens[0].equalsIgnoreCase("at-most"))
            {
                bl_N = true;
                if(tokens_count >= 3) bl_Q = true;
                f_op[stak_size - k] = new RuleNode(NodeType.ntMAXCARD, r_box.findRole(tokens[2]), Integer.parseInt(tokens[1]));
                for(int j = 3; j < tokens_count; j++)
                    f_op[stak_size - k].addChild(findConcept(tokens[j]));
            } else
            if(tokens[0].equalsIgnoreCase("at-least"))
            {
                bl_N = true;
                if(tokens_count >= 3) bl_Q = true;
                f_op[stak_size - k] = new RuleNode(NodeType.ntMINCARD, r_box.findRole(tokens[2]), Integer.parseInt(tokens[1]));
                for(int j = 3; j < tokens_count; j++)
                    f_op[stak_size - k].addChild(findConcept(tokens[j]));
            } else
            if(tokens[0].equalsIgnoreCase("exactly"))
            {
                bl_N = true;
                if(tokens_count >= 3) bl_Q = true;
                f_op[stak_size - k] = new RuleNode(NodeType.ntEXTCARD, r_box.findRole(tokens[2]), Integer.parseInt(tokens[1]));
                for(int j = 3; j < tokens_count; j++)
                    f_op[stak_size - k].addChild(findConcept(tokens[j]));
            } else
            {
                //System.out.println(tokens[0]);
                if(stak_size > 0)
                {
                    int mult = 1, l = 1;
                    while(stak_size - l >= 0)
                    {
                        if(f_op[stak_size - l].getNodeType() == NodeType.ntNOT)  mult = mult * -1; else
                        {
                            f_op[stak_size - l].addChild(mult * findConcept(tokens[0])); //it must be only one token after NOT
                            break;
                        }
                        l++;
                    }
                    if(stak_size - l == 0)
                    {
                        root = mult * findConcept(tokens[0]); //it must be only one token after NOT
                    }
                } else root = -findConcept(tokens[0]);
            }
        } else
        {
        }
    }
    
    private int buildRuleTreeByStackHelp(String expr)
    {
        stak = new int[expr.length()];
        f_op = new RuleNode[expr.length()];
        for(int i = 0; i < expr.length(); i++)
            f_op[i] = null;
        
        String cur_token = "";
        String[] tokens = new String[1024];
        int tokens_count = 0;
        
        for(int i = 0; i < expr.length(); i++)
        {
            if(expr.charAt(i) == '(')
            {
                if(cur_token.length() > 0) tokens[tokens_count++] = UF.skipDels(cur_token);
                addVertice(tokens, tokens_count);
                stak[stak_size++] = i;

                cur_token = "";
                tokens_count = 0;
            } else
            if(expr.charAt(i) == ')')
            {
                if(cur_token.length() > 0) tokens[tokens_count++] = UF.skipDels(cur_token);
                addVertice(tokens, tokens_count);
                stak_size--;
                if(f_op[stak_size].getNodeType() == NodeType.ntNOT)
                {
                    cur_token = "";
                    tokens_count = 0;
                    continue;
                }
                int cn = addNode2RuleTree(f_op[stak_size]);
                if(stak_size > 0)
                {
                    int mult = 1, l = 1;
                    while(stak_size - l >= 0) //there was the bug where NOT in the begin wasn't added
                    {
                        if(f_op[stak_size - l].getNodeType() == NodeType.ntNOT)  mult = mult * -1; else
                        {
                            f_op[stak_size - l].addChild(mult * cn);
                            break;
                        }
                        l++;
                    }
                    if(stak_size - l < 0)
                    {
                        root = mult * cn;
                    } else
                    {
                        root = cn;
                    }
                } else root = cn;
                
                cur_token = "";
                tokens_count = 0;
            } else
            if(UF.isSkippedSymbol(expr.charAt(i)))
            {
                if(cur_token.length() > 0) tokens[tokens_count++] = UF.skipDels(cur_token);
                cur_token = "";
            } else
            {
                cur_token += expr.charAt(i);
            }
        }
        if(cur_token.length() > 0) return findConcept(cur_token);
        if(tokens_count > 0) return findConcept(tokens[0]);
        return root;
    }
    ////////////////////////////////////////////////////////////////////////
    
    private int buildDataRuleTree(OWLDataRange data_expr)
    {
        RuleNode help = null;
        DataExpressionTransformer data_trans = new DataExpressionTransformer();
        data_expr.accept(data_trans);
        switch (data_expr.getDataRangeType())
        {
            case DATA_COMPLEMENT_OF:
            {
                help = new RuleNode(NodeType.ntNOT);
                help.addChild(addDataExpr2Graph(data_trans.getDataFiller()));
                break;
            }
            case DATA_INTERSECTION_OF:
            {
                help = new RuleNode(NodeType.ntAND);
                for(OWLDataRange iterator: data_trans.getDataFillerSet())
                    help.addChild(buildDataRuleTree(iterator));
                break;
            }
            case DATA_UNION_OF:
            {
                help = new RuleNode(NodeType.ntOR);
                for(OWLDataRange iterator: data_trans.getDataFillerSet())
                    help.addChild(buildDataRuleTree(iterator));
                break;
            }
            case DATA_ONE_OF:
            {
                help = new RuleNode(NodeType.ntOR);
                for(OWLLiteral iterator: data_trans.getLiters())
                    help.addChild(findLiter(iterator));
                break;
            }
            case DATATYPE:
            {
                help = new RuleNode(NodeType.ntDATATYPE);
                help.setDatatype(data_trans.getDatatype());
                break;
            }
            case DATATYPE_RESTRICTION:
            {
                help = new RuleNode(NodeType.ntAND);
                for(OWLFacet of: data_trans.getFacetSet())
                {
                    RuleNode help1 = new RuleNode(NodeType.ntDATATYPE);
                    help1.setFacet(of);
                    help.addChild(addNode2RuleTree(help1));
                }
                break;
            }
        }
        return addNode2RuleTree(help);
    }
    
    public String getThingString()
    {
        return thing;
    }
    
    public String getNothingString()
    {
        return nothing;
    }
        
    private class ExpressionTransformer implements OWLClassExpressionVisitor
    {
     
        private OWLClassExpression object_filler;
        private OWLDataRange data_filler;
        private OWLIndividual object_value;
        private OWLLiteral data_value;
        
        private List<OWLClassExpression> classes;
        private Set<OWLIndividual> individs;
        private TBox t_box;
        private RBox r_box;
        
        private int role_type;
        private int number_r;
        
        public boolean bl_N = false;
        public boolean bl_Q = false;
        public boolean bl_O = false;
        public boolean bl_D = false;
        
        public ExpressionTransformer(TBox new_t_box)
        {
            t_box = new_t_box;
            r_box = t_box.getRBox();
            individs = null;
            classes = null;
            object_filler = null;
            data_filler = null;
            object_value = null;
            data_value = null;
        }
        
        public List<OWLClassExpression> getClassesList()
        {
            return classes;
        }
        
        public int getRoleType()
        {
            return role_type;
        }
        
        public int getNumberR()
        {
            return number_r;
        }
        
        public OWLLiteral getDataValue()
        {
            return data_value;
        }
        
        public OWLIndividual getIndividual()
        {
            return object_value;
        }
        
        public OWLClassExpression getObjectFiller()
        {
            return object_filler;
        }
        
        public OWLDataRange getDataFiller()
        {
            return data_filler;
        }
        
        public Set<OWLIndividual> getIndivids()
        {
            return individs;
        }
        
        @Override
        public void visit(OWLClass owlc) {
            //WTF?!
        }

        @Override
        public void visit(OWLObjectIntersectionOf owloio) {
            classes = owloio.getOperandsAsList();
        }

        @Override
        public void visit(OWLObjectUnionOf owlouo) {
            classes = owlouo.getOperandsAsList();
        }

        @Override
        public void visit(OWLObjectComplementOf owloco) {
            object_filler = owloco.getOperand();
        }

        @Override
        public void visit(OWLObjectSomeValuesFrom owlsvf) {
            role_type = r_box.findRole(owlsvf.getProperty());
            object_filler = owlsvf.getFiller();
        }

        @Override
        public void visit(OWLObjectAllValuesFrom owlvf) {
            role_type = r_box.findRole(owlvf.getProperty());
            object_filler = owlvf.getFiller();
        }

        @Override
        public void visit(OWLObjectHasValue owlohv) {
            role_type = r_box.findRole(owlohv.getProperty());
            object_value = owlohv.getValue();
            bl_O = true;
        }

        @Override
        public void visit(OWLObjectMinCardinality owlomc) {
            role_type = r_box.findRole(owlomc.getProperty());
            number_r = owlomc.getCardinality();
            object_filler = owlomc.getFiller();
            bl_N = true;
        }

        @Override
        public void visit(OWLObjectExactCardinality owloec) {
            role_type = r_box.findRole(owloec.getProperty());
            number_r = owloec.getCardinality();
            object_filler = owloec.getFiller();
            bl_N = true;
        }

        @Override
        public void visit(OWLObjectMaxCardinality owlomc) {
            role_type = r_box.findRole(owlomc.getProperty());
            number_r = owlomc.getCardinality();
            object_filler = owlomc.getFiller();
            bl_N = true;
        }

        @Override
        public void visit(OWLObjectHasSelf owlohs) {
            role_type = r_box.findRole(owlohs.getProperty());
        }

        @Override
        public void visit(OWLObjectOneOf owlooo) {
            individs = owlooo.getIndividuals();
        }

        @Override
        public void visit(OWLDataSomeValuesFrom o) {
            role_type = r_box.findRole(o.getProperty());
            data_filler = o.getFiller();
            bl_D = true;
        }

        @Override
        public void visit(OWLDataAllValuesFrom owldvf) {
            role_type = r_box.findRole(owldvf.getProperty());
            data_filler = owldvf.getFiller();
            bl_D = true;
        }

        @Override
        public void visit(OWLDataHasValue owldhv) {
            role_type = r_box.findRole(owldhv.getProperty());
            data_value = owldhv.getValue();
            bl_D = true;
        }

        @Override
        public void visit(OWLDataMinCardinality owldmc) {
            role_type = r_box.findRole(owldmc.getProperty());
            number_r = owldmc.getCardinality();
            data_filler = owldmc.getFiller();
            bl_D = true;
        }

        @Override
        public void visit(OWLDataExactCardinality owldec) {
            role_type = r_box.findRole(owldec.getProperty());
            number_r = owldec.getCardinality();
            data_filler = owldec.getFiller();
            bl_D = true;
        }

        @Override
        public void visit(OWLDataMaxCardinality owldmc) {
            role_type = r_box.findRole(owldmc.getProperty());
            number_r = owldmc.getCardinality();
            data_filler = owldmc.getFiller();
            bl_D = true;
        }
    }
    
    private class DataExpressionTransformer implements OWLDataVisitor
    {
        
        private Set<OWLLiteral> liters;
        private OWLLiteral liter;
        private OWLDataRange data_filler;
        private Set<OWLDataRange> data_filler_set;
        private OWLDatatype data_type;
        private OWLFacet facet;
        private ArrayList<OWLFacet> facet_set;
        
        public DataExpressionTransformer()
        {
            data_type = null;
            data_filler_set = null;
            data_filler = null;
            liter = null;
            liters = null;
            
            facet = null;
            facet_set= null;
        }
        
        public OWLDatatype getDatatype()
        {
            return data_type;
        }
        
        public OWLDataRange getDataFiller()
        {
            return data_filler;
        }

        public Set<OWLDataRange> getDataFillerSet()
        {
            return data_filler_set;
        }

        public Set<OWLLiteral> getLiters()
        {
            return liters;
        }
        
        public OWLLiteral getLiter()
        {
            return liter;
        }
        
        public OWLFacet getFacet()
        {
            return facet;
        }
        
        public ArrayList<OWLFacet> getFacetSet()
        {
            return facet_set;
        }

        @Override
        public void visit(OWLLiteral owll) {
            data_type = owll.getDatatype();
            liter = owll;
        }

        @Override
        public void visit(OWLFacetRestriction owlfr) {
            System.out.println(owlfr.getFacet().getSymbolicForm() + ":" + owlfr.getFacetValue().getLiteral());
            facet = owlfr.getFacet();
        }

        @Override
        public void visit(OWLDatatype owld) {
            data_type = owld;
        }

        @Override
        public void visit(OWLDataOneOf owldoo) {
            liters = owldoo.getValues();
        }

        @Override
        public void visit(OWLDataComplementOf owldco) {
            data_filler = owldco.getDataRange();
        }

        @Override
        public void visit(OWLDataIntersectionOf owldio) {
            data_filler_set = owldio.getOperands();
        }

        @Override
        public void visit(OWLDataUnionOf owlduo) {
            data_filler_set = owlduo.getOperands();
        }

        @Override
        public void visit(OWLDatatypeRestriction owldr) {
            facet_set = new ArrayList<OWLFacet>();
            data_type = owldr.getDatatype();
            for(OWLFacetRestriction ofr: owldr.getFacetRestrictions())
                facet_set.add(ofr.getFacet());
        }
    }
}