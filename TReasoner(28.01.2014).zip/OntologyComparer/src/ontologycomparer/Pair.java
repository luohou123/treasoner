/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ontologycomparer;

/**
 *
 * @author 1
 */
public class Pair {
    public int l, r;
    
    public Pair(int _l, int _r)
    {
        l = _l;
        r = _r;
    }
    
    @Override
    public int hashCode()
    {
        return l * 107 + r;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pair other = (Pair) obj;
        if (this.l != other.l) {
            return false;
        }
        if (this.r != other.r) {
            return false;
        }
        return true;
    }
    
}
