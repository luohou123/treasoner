/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ontologycomparer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 *
 * @author 1
 */
public class Taxonomy {

    ArrayList<String> al = new ArrayList<String>();
    HashMap<String, Integer> hm = new HashMap<String, Integer>();
    
    HashSet<Pair> axs = new HashSet<Pair>();
    
    private int find(String s)
    {
        if(hm.containsKey(s)) return hm.get(s);
        hm.put(s, al.size());
        al.add(s);
        return al.size() - 1;
    }
    
    public void addSubClass(String sub, String sup)
    {
        int sb = find(sub);
        int sp = find(sup);
        Pair p = new Pair(sb, sp);
        axs.add(p);
    }
    
    public boolean isExists(String sub, String sup)
    {
        int sb = find(sub);
        int sp = find(sup);
        return axs.contains(new Pair(sb, sp));
    }
    
    public ArrayList<StringPair> getAllAxioms()
    {
        ArrayList<StringPair> ret = new ArrayList<StringPair>();
        for(Pair p: axs)
        {
            StringPair tmp = new StringPair(al.get(p.l), al.get(p.r));
            ret.add(tmp);
        }
        return ret;
    }
    
    public void compareTo(Taxonomy t)
    {
        System.out.println(t.getAllAxioms().size() + " " + getAllAxioms().size());
        ArrayList<StringPair> a = t.getAllAxioms();
        for(int i = 0; i < a.size(); i++)
        {
            //System.out.println(a.get(i).left + " [= " + a.get(i).right);
            if(!axs.contains(new Pair(find(a.get(i).left), find(a.get(i).right))))
            {
                System.out.println("ERROR: can't find " + a.get(i).left + " [= " + a.get(i).right + " in reference taxonomy");
            }
        }
        
        a = getAllAxioms();
        System.out.println("");
        for(int i = 0; i < a.size(); i++)
        {
            //System.out.println(a.get(i).left + " [= " + a.get(i).right);
            if(!t.isExists(a.get(i).left, a.get(i).right))
            {
                System.out.println("ERROR: can't find " + a.get(i).left + " [= " + a.get(i).right + " in my taxonomy");
            }
        }
    }
}
