/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ontologycomparer;

import java.io.File;
import java.util.ArrayList;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLLogicalAxiom;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;

/**
 *
 * @author 1
 */
public class OntologyComparer {

    /**
     * @param args the command line arguments
     */
    public static OWLOntologyManager m;
    
    public static void main(String[] args) throws OWLOntologyCreationException {
        args = new String[4];
        String prefix1 = "D:\\ORE 2013\\ans\\";
        String prefix2 = "D:\\ORE 2013\\ans\\";
        
        //String prefix1 = "C:/Users/Boris/Documents/NetBeansProjects/TReasoner/TReasoner/";
        //String prefix2 = "C:/Users/Boris/Downloads/ORE 2012/classification/OWL DL/reference/";
        
        ArrayList<String> totest_files = new ArrayList<String>();
        //totest_files.add("http___protege.stanford.edu_plugins_owl_owl-library_not-galen.owl.txt");
        //totest_files.add("http___www.cs.man.ac.uk_~horrocks_OWL_Ontologies_galen.owl.txt");
            totest_files.add("http___www.w3.org_TR_2003_CR-owl-guide-20030818_food");
            totest_files.add("dictyostelium_discoideum_anatomy.owl");
            totest_files.add("http___ebiquity.umbc.edu_ontology_conference.owl");
            totest_files.add("http___ebiquity.umbc.edu_ontology_person.owl");
            totest_files.add("http___ebiquity.umbc.edu_ontology_project.owl");
            totest_files.add("http___ebiquity.umbc.edu_ontology_publication.owl");
            totest_files.add("http___ebiquity.umbc.edu_ontology_research.owl");
            totest_files.add("http___mr.teknowledge.com_DAML_ArtOntology.daml.txt");
            totest_files.add("http___mr.teknowledge.com_DAML_pptOntology.daml.txt");
            totest_files.add("http___protege.stanford.edu_plugins_owl_owl-library_camera.owl.txt");
            totest_files.add("http___protege.stanford.edu_plugins_owl_owl-library_generations.owl.txt");
            totest_files.add("http___protege.stanford.edu_plugins_owl_owl-library_koala.owl.txt");
            totest_files.add("http___protege.stanford.edu_plugins_owl_owl-library_MGEDOntology.owl.txt");
            totest_files.add("http___protege.stanford.edu_plugins_owl_owl-library_travel.owl.txt");
            totest_files.add("http___rhizomik.net_ontologies_2006_01_copyrightonto.owl");
            totest_files.add("http___semwebcentral.org_owl-gforge_site.txt");
            totest_files.add("http___sweet.jpl.nasa.gov_ontology_data_center.owl.txt");
            totest_files.add("http___www.co-ode.org_ontologies_pizza_pizza_20041007.owl.txt");
            totest_files.add("http___www.cs.man.ac.uk_~horrocks_OWL_Ontologies_ka.owl.txt");
            totest_files.add("http___www.cs.man.ac.uk_~horrocks_OWL_Ontologies_mad_cows.owl.txt");
            totest_files.add("http___www.daml.org_services_owl-s_1.1_Service.owl");
            totest_files.add("http___www.loa-cnr.it_Files_DLPOnts_DOLCE-Lite_397.owl.txt");
            totest_files.add("http___www.loa-cnr.it_Files_DLPOnts_Information_397.owl.txt");
            totest_files.add("http___www.loa-cnr.it_Files_DLPOnts_Plans_397.owl.txt");
            totest_files.add("http___www.mindswap.org_2003_owl_geo_geoCoordinateSystems20040307.owl");
            totest_files.add("http___www.mindswap.org_2004_owl_mindswappers.txt");
            totest_files.add("mouse_pathology.owl");
            totest_files.add("obi.owl");
            totest_files.add("pathway.owl");
            totest_files.add("plant_environment.owl");
            totest_files.add("plant_trait.owl");
            totest_files.add("plasmodium_life_cycle.owl");
            totest_files.add("po_temporal.owl");
            totest_files.add("protein.owl");
            totest_files.add("psi-ms.owl");
            totest_files.add("quality.owl");
            totest_files.add("quality_bfo_bridge.imports-local.owl");
            totest_files.add("quality_prerelease.owl");
            totest_files.add("rex.owl");
            totest_files.add("sequence.owl");
            totest_files.add("spatial.owl");
            totest_files.add("spider_anatomy.owl");
            totest_files.add("systems_biology.owl");
            totest_files.add("temporal_gramene.owl");
            totest_files.add("tick_anatomy.owl");
            totest_files.add("transmission.owl");
            totest_files.add("worm_development.owl");
            totest_files.add("worm_phenotype.owl");
            totest_files.add("xenopus_anatomy.owl");
            totest_files.add("yeast_phenotype.owl");

        totest_files.clear();
        totest_files.add("0cd30725-3ae5-4c41-820f-c6a16240e802_-OKB_2.owl");
        totest_files.add("71134246-639b-4ed8-aff8-2261cb41cd4e_tp3.owl");
        totest_files.add("8f298886-1bb7-41b6-810b-ec036ad75fee_2Fchemical");
        totest_files.add("2f4b30e8-2c85-4028-a1d4-1dfb08067dcc_l%2Ffalcon");
        totest_files.add("5657edcf-cec9-4492-a8dd-cfe2d4f5f0d9_owl%2Fcoma");
        totest_files.add("51e460e9-619a-4683-b9ad-ec261e4bf06d_7-0342.owl");
        totest_files.add("8a74f1e5-2162-435f-a7a5-4258d2571681_ndPets.owl");
        totest_files.add("578811f0-41fd-4e88-a580-0cd6fe989d6c_1615.owl");
        totest_files.add("60fb4605-bf17-45a4-9d3f-8e70a871c013_dation.owl");
        totest_files.add("fa1ae516-9f0b-42f1-a66a-708d5a9cf9a0_ets-v1.owl");
        totest_files.add("844f7541-1f1f-4004-ae32-42e5cae21f4a_people.owl");
        totest_files.add("b815b896-e04c-4571-8ce8-e4b25aedcbec_e+petsA.n3");
        totest_files.add("fc156d3b-a0e6-4a8b-9424-79aa5025bed7_people.owl");
        totest_files.add("777a6585-c41f-44bb-b6ca-079c83c1bde3_BpetsA.owl");
        totest_files.add("b7b018d1-0a8b-493e-b506-652630277b51_people.owl");
        totest_files.add("240a6af0-3a59-41b6-afe6-b00648b43315__inst1.owl");
        totest_files.add("00118.owl");
        totest_files.add("1a068e20-c239-47a1-b9dc-40ddbf73b6ec_iesAmI.rdf");
        totest_files.add("a5ac64cb-3d75-48e2-8106-b05277c9e16e_lscale.owl");
        totest_files.add("72db2148-edfc-4c63-a142-52d2a0eb0b9b_inst15.owl");
        totest_files.add("bc1af316-cb50-42ff-9e9d-ea8f309ea42c_people");
        totest_files.add("ca3f25c3-c60d-4bf3-b691-3282c541bf39_people.owl");
        totest_files.add("6126d1bf-ffc8-4a6f-ad9d-b8173f4d99db_ePizza.owl");
        totest_files.add("2182c976-12bd-41ef-9665-0a471049e6f7_e+pets.rdf");
        totest_files.add("00a1118a-5420-46f0-b4b2-a2585165b28a_ePizza.owl");
        totest_files.add("ed702658-c8e0-48bb-af79-34c625fb8039_tology.owl");
        totest_files.add("7dacb73c-7366-4099-aba0-16dac9dda108_pizza.owl");
        totest_files.add("ca9585af-418b-4bdd-9432-2a3aaf49678b_Pizza.owl");
        totest_files.add("95a2df41-085b-41ef-998e-9dc32bd75a30_pizza.owl");
        totest_files.add("26ffd334-3398-4054-993b-f8e22411435c_pizza.owl");
        totest_files.add("bleeding-history-phenotype.1116.owl.xml");
        totest_files.add("6a2afaf6-ea7f-4ce2-936b-62b283e589a8_lscale.owl");
        totest_files.add("2edc955f-295c-4b59-9554-c8ac744c4a54_p-core.owl");

        for(int i = 0; i < totest_files.size(); i++)
        {
            args[0] = prefix1 + totest_files.get(i) + "_ans.owl";
            args[1] = prefix2 + totest_files.get(i) + "herm_ans.owl";
            
            File f1 = new File(args[0]);
            File f2 = new File(args[1]);
            if(!f1.exists() || !f2.exists())
            {
                continue;
            }

            m = OWLManager.createOWLOntologyManager();
            System.out.println(args[0]);
            System.out.println(args[1]);
            IRI file_iri1 = IRI.create(new File(args[0]));
            IRI file_iri2 = IRI.create(new File(args[1]));
            OWLOntology owl1 = m.loadOntologyFromOntologyDocument(file_iri1);
            OWLOntology owl2 = m.loadOntologyFromOntologyDocument(file_iri2);

            AxiomVisitor av = new AxiomVisitor();

            Taxonomy t1 = new Taxonomy();
            for(OWLLogicalAxiom ax: owl1.getLogicalAxioms())
            {
                av.subClass = false;
                ax.accept(av);
                if(av.subClass) t1.addSubClass(av.SUB, av.SUP);
            }

            Taxonomy t2 = new Taxonomy();
            for(OWLLogicalAxiom ax: owl2.getLogicalAxioms())
            {
                av.subClass = false;
                ax.accept(av);
                if(av.subClass) t2.addSubClass(av.SUB, av.SUP);
            }

            t2.compareTo(t1);
        }
        
        /*String[] list = new File(prefix2).list();
        String[] owl_files = new String[list.length];
        for(int i = 0; i < list.length; i++)
        {
            int j = 0;
            int count = 0;
            for(j = 0; j < list[i].length(); j++)
            {
                if(list[i].charAt(j) == '_') count++;
                if(count == 1)
                {
                    owl_files[i] = list[i].substring(j + 2, list[i].length());
                }
            }
            System.out.println("totest_files.add(\"" + owl_files[i] + "\");");
        }*/
    }
}
