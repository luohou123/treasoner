/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hermittest;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import org.semanticweb.HermiT.Reasoner;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;

/**
 *
 * @author Boris
 */
public class HermiTTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws OWLOntologyCreationException, FileNotFoundException {
        OWLOntologyManager m = OWLManager.createOWLOntologyManager();

        ArrayList<String> totest_files = new ArrayList<String>();
        totest_files.add("ff3927b5-a83e-4c7d-b4bf-d727eecf48cc_Time.owl");
        totest_files.add("2c1df502-e8e2-4f17-a266-6ce3ff0561a0_v1.owl");
        totest_files.add("cc1502c1-3ff2-4e51-b219-0837de828b26_v0.1.1.owl");
        totest_files.add("77de15c6-cc39-4960-a38a-e35e487d52b0_owl%2Fcoma");
        totest_files.add("b20d6bb4-c2d3-4d63-8ea3-2693cbdbe89d_-09-07.rdf");
        totest_files.add("3a391724-b8c0-43db-a504-5876d9a878fd_gy%2Fpo%2F");
        totest_files.add("6785a156-f582-4a75-823d-65102e344a45_tology.owl");
        totest_files.add("bb3945c9-a7fb-476b-87dc-1ce8e69a28eb_dbpedia.owl");

        
        totest_files.add("00c21813-4923-4e1a-9c0e-b6163accae5f_t8.rdf.owl"); //time out
        totest_files.clear();

        totest_files.add("0cd30725-3ae5-4c41-820f-c6a16240e802_-OKB_2.owl");
        totest_files.add("71134246-639b-4ed8-aff8-2261cb41cd4e_tp3.owl");
        totest_files.add("8f298886-1bb7-41b6-810b-ec036ad75fee_2Fchemical");
        totest_files.add("2f4b30e8-2c85-4028-a1d4-1dfb08067dcc_l%2Ffalcon");
        totest_files.add("5657edcf-cec9-4492-a8dd-cfe2d4f5f0d9_owl%2Fcoma");
        totest_files.add("51e460e9-619a-4683-b9ad-ec261e4bf06d_7-0342.owl");
        totest_files.add("8a74f1e5-2162-435f-a7a5-4258d2571681_ndPets.owl");
        totest_files.add("578811f0-41fd-4e88-a580-0cd6fe989d6c_1615.owl");
        totest_files.add("60fb4605-bf17-45a4-9d3f-8e70a871c013_dation.owl");
        totest_files.add("fa1ae516-9f0b-42f1-a66a-708d5a9cf9a0_ets-v1.owl");
        totest_files.add("844f7541-1f1f-4004-ae32-42e5cae21f4a_people.owl");
        totest_files.add("b815b896-e04c-4571-8ce8-e4b25aedcbec_e+petsA.n3");
        totest_files.add("fc156d3b-a0e6-4a8b-9424-79aa5025bed7_people.owl");
        totest_files.add("777a6585-c41f-44bb-b6ca-079c83c1bde3_BpetsA.owl");
        totest_files.add("b7b018d1-0a8b-493e-b506-652630277b51_people.owl");
        totest_files.add("240a6af0-3a59-41b6-afe6-b00648b43315__inst1.owl");
        totest_files.add("00118.owl");
        totest_files.add("1a068e20-c239-47a1-b9dc-40ddbf73b6ec_iesAmI.rdf");
        totest_files.add("a5ac64cb-3d75-48e2-8106-b05277c9e16e_lscale.owl");
        totest_files.add("72db2148-edfc-4c63-a142-52d2a0eb0b9b_inst15.owl");
        totest_files.add("bc1af316-cb50-42ff-9e9d-ea8f309ea42c_people");
        totest_files.add("ca3f25c3-c60d-4bf3-b691-3282c541bf39_people.owl");
        totest_files.add("6126d1bf-ffc8-4a6f-ad9d-b8173f4d99db_ePizza.owl");
        totest_files.add("2182c976-12bd-41ef-9665-0a471049e6f7_e+pets.rdf");
        totest_files.add("00a1118a-5420-46f0-b4b2-a2585165b28a_ePizza.owl");
        totest_files.add("ed702658-c8e0-48bb-af79-34c625fb8039_tology.owl");
        totest_files.add("7dacb73c-7366-4099-aba0-16dac9dda108_pizza.owl");
        totest_files.add("ca9585af-418b-4bdd-9432-2a3aaf49678b_Pizza.owl");
        totest_files.add("95a2df41-085b-41ef-998e-9dc32bd75a30_pizza.owl");
        totest_files.add("26ffd334-3398-4054-993b-f8e22411435c_pizza.owl");
        totest_files.add("bleeding-history-phenotype.1116.owl.xml");
        totest_files.add("6a2afaf6-ea7f-4ce2-936b-62b283e589a8_lscale.owl");
        totest_files.add("2edc955f-295c-4b59-9554-c8ac744c4a54_p-core.owl");

        
        for(int i = 0; i < totest_files.size(); i++)
        {
            String onname = totest_files.get(i);
            System.out.println(onname);
            OWLOntology o = m.loadOntologyFromOntologyDocument(new File("D:\\ORE 2013\\ore2013-ontologies-offline\\owlxml\\dl\\" + onname));
            Reasoner hermit = new Reasoner(o);
            PrintWriter pw = new PrintWriter(new File("D:\\ORE 2013\\ans\\" + onname + "herm_ans.owl"));
            hermit.printHierarchies(pw, true, false, false);
        }
    }
}
